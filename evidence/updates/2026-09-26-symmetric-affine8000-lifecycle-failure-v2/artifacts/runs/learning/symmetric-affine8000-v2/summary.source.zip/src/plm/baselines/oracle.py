"""Deterministic full-graph oracle scorer."""

from __future__ import annotations

from collections.abc import Iterable, Mapping

from plm.corpus.compiler import CorpusRecord

__all__ = ["OracleScorer"]


class OracleScorer:
    def __init__(
        self,
        records: Iterable[CorpusRecord] | None = None,
        *,
        targets: Mapping[tuple[str, str], Iterable[str]] | None = None,
    ) -> None:
        mapping: dict[tuple[str, str], frozenset[str]] = {
            key: frozenset(values) for key, values in (targets or {}).items()
        }
        for record in records or ():
            mapping[(record.subject, record.dimension)] = frozenset(record.targets)
        self.targets = mapping

    def score(self, query: CorpusRecord, candidate: str) -> float:
        return (
            1.0
            if candidate
            in self.targets.get((query.subject, query.dimension), frozenset(query.targets))
            else 0.0
        )

    __call__ = score
