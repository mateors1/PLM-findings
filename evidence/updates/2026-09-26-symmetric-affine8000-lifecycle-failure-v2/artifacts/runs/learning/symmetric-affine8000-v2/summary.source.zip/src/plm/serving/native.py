"""Bounded native inference over a validated model and a dedicated graph snapshot."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import tempfile
import threading
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from plm.config import EvalConfig, RootConfig
from plm.configuration import config_hash
from plm.experimentation.provenance import capture_runtime_provenance
from plm.serving.generation import GenerationResult, generate_response
from plm.serving.guidance import guidance_decoding_suffix
from plm.serving.hydration import HydrationIndex
from plm.serving.parser import ProtocolParseError, ProtocolResponse, parse_generated
from plm.serving.postprocess import postprocess_response
from plm.serving.runtime import InferenceRuntime, load_inference_runtime
from plm.serving.set_composition import SetCompositionResult, generate_set_compositions

__all__ = [
    "GenerationFailure",
    "InvalidRequestError",
    "NativePredictor",
    "PredictRequest",
    "ServiceBusyError",
    "SetCompositionDisabled",
    "SetCompositionFailure",
]


class PredictRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    subject: str
    dimension: Literal["TYPE", "COLOR"]
    mode: Literal["SAME"] = "SAME"
    ignore: list[str] = Field(default_factory=list)
    limit: int | None = Field(default=None, ge=0)


class ServiceBusyError(RuntimeError):
    """Admission limit reached; the request was not executed."""


class InvalidRequestError(ValueError):
    """Request references entities absent from this deployment."""


class GenerationFailure(RuntimeError):
    """Retain raw evidence when no complete valid answer can be returned."""

    def __init__(self, raw: GenerationResult) -> None:
        super().__init__(raw.error or "model did not produce a complete protocol response")
        self.raw = raw


class SetCompositionDisabled(RuntimeError):
    """This deployment has not enabled the separate set-composition interface."""


class SetCompositionFailure(RuntimeError):
    """Retain source evidence when no eligible composed answer exists."""

    def __init__(self, composition: SetCompositionResult) -> None:
        super().__init__("no valid terminated source path is available for set composition")
        self.composition = composition


class NativePredictor:
    """One model, serial execution, bounded in-flight requests, frozen hydration."""

    def __init__(self, runtime: InferenceRuntime, snapshot: Path, *, max_pending: int = 8) -> None:
        EvalConfig.model_validate(runtime.config.eval.model_dump())
        if isinstance(max_pending, bool) or not isinstance(max_pending, int) or max_pending < 1:
            raise ValueError("max_pending must be a positive integer")
        if runtime.config.eval.max_new_tokens + 5 > runtime.config.model.max_seq_len:
            raise ValueError("serving generation bound exceeds the model context")
        if runtime.config.eval.generation_batch_size != 1:
            raise ValueError("generation_batch_size is offline-only; native serving requires 1")
        if (
            runtime.config.eval.first_target_guidance_alpha > 0
            and runtime.config.model.symmetric_relation_loss_weight <= 0
        ):
            raise ValueError("first-target guidance requires a trained symmetric relation head")
        self.runtime = runtime
        if (
            runtime.config.eval.symmetric_set_reranking
            and runtime.config.model.symmetric_relation_loss_weight <= 0
        ):
            raise ValueError("symmetric set reranking requires a trained symmetric relation head")
        self.snapshot = snapshot
        self.catalog = HydrationIndex.from_snapshot(snapshot)
        self._entities = frozenset(
            runtime.vocabulary.token_of(i) for i in runtime.vocabulary.entity_ids()
        )
        if self._entities != self.catalog.products.keys():
            raise ValueError("serving vocabulary and active hydration catalog differ")
        self.max_pending = max_pending
        self._admission = threading.BoundedSemaphore(max_pending)
        self._execution = threading.Lock()
        self.deployment: dict[str, Any] = {
            "checkpoint_hash": runtime.checkpoint_hash,
            "corpus_identity": runtime.corpus_identity,
            "split_hash": runtime.split.split_hash,
            "inference_config_hash": config_hash(runtime.config),
            "snapshot_sha256": hashlib.sha256(snapshot.read_bytes()).hexdigest(),
            "device": runtime.device,
            "use_kv_cache": runtime.config.eval.use_kv_cache,
            "constrained_decoding": runtime.config.eval.constrained_decoding,
            "prevent_repeated_targets": runtime.config.eval.prevent_repeated_targets,
            "first_target_guidance_alpha": runtime.config.eval.first_target_guidance_alpha,
            "symmetric_set_reranking": runtime.config.eval.symmetric_set_reranking,
            "pair_set_composition": runtime.config.eval.pair_set_composition,
            "set_composition_policy": (
                "greedy-protocol-mask-v1+unique-v1+kv-v1+batch-v1"
                + guidance_decoding_suffix(runtime.config.eval.first_target_guidance_alpha)
                + "+first4-pair6-symmetric-set-logit-sum-v1"
                if runtime.config.eval.pair_set_composition
                else None
            ),
            "generation_batch_size": 1,
            "decoding": (
                "greedy-protocol-mask-v1"
                if runtime.config.eval.constrained_decoding
                else "greedy-unconstrained-v1"
            )
            + ("+unique-v1" if runtime.config.eval.prevent_repeated_targets else "")
            + ("+kv-v1" if runtime.config.eval.use_kv_cache else "")
            + ("+batch-v1" if runtime.config.eval.symmetric_set_reranking else "")
            + guidance_decoding_suffix(runtime.config.eval.first_target_guidance_alpha)
            + (
                "+first4-symmetric-set-logit-sum-v1"
                if runtime.config.eval.symmetric_set_reranking
                else ""
            ),
            "max_new_tokens": runtime.config.eval.max_new_tokens,
            "max_pending": max_pending,
            "scheduling": "serial model execution with bounded admission; not continuous batching",
        }

    @classmethod
    def from_checkpoint(
        cls,
        config: RootConfig,
        checkpoint: str | Path,
        *,
        runtime_dir: str | Path,
        corpus: str | Path | None = None,
        graph_db: str | Path | None = None,
        max_pending: int = 8,
    ) -> NativePredictor:
        """Back up and validate the graph before accepting any requests."""
        source_graph = Path(graph_db if graph_db is not None else config.data.graph_db).resolve()
        root = Path(runtime_dir).resolve()
        root.mkdir(parents=True, exist_ok=True)
        directory = Path(tempfile.mkdtemp(prefix="native-", dir=root))
        snapshot = directory / "graph.snapshot.db"
        source = sqlite3.connect(source_graph.as_uri() + "?mode=ro", uri=True)
        try:
            destination = sqlite3.connect(snapshot)
            try:
                source.backup(destination)
            finally:
                destination.close()
        finally:
            source.close()
        runtime = load_inference_runtime(config, checkpoint, corpus=corpus, graph_db=snapshot)
        instance = cls(runtime, snapshot, max_pending=max_pending)
        revision, environment = capture_runtime_provenance(source_archive=directory / "source.zip")
        instance.deployment.update({"source_commit": revision, "environment": environment})
        receipt = {
            **instance.deployment,
            "training_identity": runtime.training_identity,
            "checkpoint": str(Path(checkpoint).resolve()),
            "source_graph": str(source_graph),
            "snapshot": str(snapshot),
            "config": runtime.config.model_dump(mode="json"),
        }
        (directory / "serving.json").write_text(
            json.dumps(receipt, sort_keys=True, indent=2) + "\n", encoding="utf-8"
        )
        return instance

    def predict(self, request: PredictRequest) -> dict[str, Any]:
        """Generate raw IDs; post-filter only completed output, then hydrate labels."""
        started = time.perf_counter()
        if request.subject not in self._entities:
            raise InvalidRequestError(
                "subject must be an active product in the deployed vocabulary"
            )
        if any(key not in self._entities for key in request.ignore):
            raise InvalidRequestError(
                "IGNORE keys must be active products in the deployed vocabulary"
            )
        if not self._admission.acquire(blocking=False):
            raise ServiceBusyError("in-flight request limit reached; retry later")
        queued_at = time.perf_counter()
        try:
            with self._execution:
                generation_started = time.perf_counter()
                raw = generate_response(
                    self.runtime.model,
                    self.runtime.vocabulary,
                    request.subject,
                    request.dimension,
                    max_new_tokens=self.runtime.config.eval.max_new_tokens,
                    device=self.runtime.device,
                    constrained=self.runtime.config.eval.constrained_decoding,
                    use_cache=self.runtime.config.eval.use_kv_cache,
                    prevent_repeated_targets=self.runtime.config.eval.prevent_repeated_targets,
                    first_target_guidance_alpha=self.runtime.config.eval.first_target_guidance_alpha,
                    symmetric_set_reranking=self.runtime.config.eval.symmetric_set_reranking,
                )
                generation_seconds = time.perf_counter() - generation_started
            if not raw.terminated or not raw.protocol_valid:
                raise GenerationFailure(raw)
            try:
                parsed = parse_generated(raw.token_ids, self.runtime.vocabulary)
            except (ProtocolParseError, KeyError) as exc:
                raise GenerationFailure(raw) from exc
            if (parsed.subject, parsed.dimension, parsed.mode) != (
                request.subject,
                request.dimension,
                request.mode,
            ) or parsed.targets != raw.targets:
                raise GenerationFailure(raw)
            processed = postprocess_response(parsed, ignore=request.ignore, limit=request.limit)
            hydrated = self.catalog.hydrate(processed.response)
            return {
                "result": asdict(hydrated),
                "raw": asdict(raw),
                "postprocess": {
                    field: getattr(processed, field)
                    for field in (
                        "removed_subject",
                        "removed_ignored",
                        "removed_duplicates",
                        "removed_by_limit",
                    )
                },
                "checkpoint_hash": self.runtime.checkpoint_hash,
                "graph_hash": self.runtime.corpus_identity["graph_hash"],
                "timing": {
                    "queue_seconds": generation_started - queued_at,
                    "generation_seconds": generation_seconds,
                    "total_seconds": time.perf_counter() - started,
                },
            }
        finally:
            self._admission.release()

    def predict_set(self, request: PredictRequest) -> dict[str, Any]:
        """Select a canonical set, then apply metadata and hydrate; retain all source paths."""
        started = time.perf_counter()
        if not self.runtime.config.eval.pair_set_composition:
            raise SetCompositionDisabled("set composition is disabled in this deployment")
        if request.subject not in self._entities:
            raise InvalidRequestError(
                "subject must be an active product in the deployed vocabulary"
            )
        if any(key not in self._entities for key in request.ignore):
            raise InvalidRequestError(
                "IGNORE keys must be active products in the deployed vocabulary"
            )
        if not self._admission.acquire(blocking=False):
            raise ServiceBusyError("in-flight request limit reached; retry later")
        queued_at = time.perf_counter()
        try:
            with self._execution:
                generation_started = time.perf_counter()
                (composition,) = generate_set_compositions(
                    self.runtime.model,
                    self.runtime.vocabulary,
                    ((request.subject, request.dimension),),
                    max_new_tokens=self.runtime.config.eval.max_new_tokens,
                    device=self.runtime.device,
                    first_target_guidance_alpha=self.runtime.config.eval.first_target_guidance_alpha,
                )
                generation_seconds = time.perf_counter() - generation_started
            if composition.fallback_no_valid_source or not composition.selected_source_eligible:
                raise SetCompositionFailure(composition)
            # This is a set response for hydration, never a fabricated generated sequence.
            response = ProtocolResponse(
                request.subject,
                request.dimension,
                request.mode,
                tuple(
                    self.runtime.vocabulary.token_of(token)
                    for token in composition.selected_set_ids
                ),
            )
            processed = postprocess_response(response, ignore=request.ignore, limit=request.limit)
            return {
                "result": asdict(self.catalog.hydrate(processed.response)),
                **asdict(composition),
                "postprocess": {
                    field: getattr(processed, field)
                    for field in (
                        "removed_subject",
                        "removed_ignored",
                        "removed_duplicates",
                        "removed_by_limit",
                    )
                },
                "checkpoint_hash": self.runtime.checkpoint_hash,
                "graph_hash": self.runtime.corpus_identity["graph_hash"],
                "corpus_identity": self.runtime.corpus_identity,
                "split_hash": self.runtime.split.split_hash,
                "inference_config_hash": self.deployment["inference_config_hash"],
                "timing": {
                    "queue_seconds": generation_started - queued_at,
                    "generation_seconds": generation_seconds,
                    "total_seconds": time.perf_counter() - started,
                },
            }
        finally:
            self._admission.release()
