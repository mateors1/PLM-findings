"""Reference CPU/CUDA training loop used before any optimization search."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from plm.config import TrainConfig
from plm.corpus.compiler import CorpusRecord
from plm.experimentation.identity import ExperimentIdentity
from plm.model.interfaces import ModelOutput
from plm.reproducibility import seed_everything, seed_worker
from plm.training.checkpoint import (
    CheckpointState,
    load_checkpoint,
    save_checkpoint,
    validate_checkpoint_identity,
)
from plm.training.data import CorpusDataset, collate_records
from plm.training.optim import create_optimizer, create_scheduler

__all__ = ["TrainResult", "Trainer"]


def _identity_batch(rows: list[CorpusRecord]) -> list[CorpusRecord]:
    """Keep records as a list for the trainer's explicit tensor collation."""

    return rows


@dataclass(frozen=True)
class TrainResult:
    global_step: int
    train_loss: float
    validation_loss: float | None
    history: tuple[dict[str, float], ...] = ()
    checkpoint: CheckpointState | None = None


class Trainer:
    """Small deterministic trainer with explicit evaluation/checkpoint cadence."""

    def __init__(
        self,
        model: Any,
        records: tuple[CorpusRecord, ...] | list[CorpusRecord],
        *,
        config: TrainConfig,
        seed: int = 1729,
        pad_id: int = 0,
        validation_records: tuple[CorpusRecord, ...] | list[CorpusRecord] = (),
        run_dir: str | Path | None = None,
        identity: ExperimentIdentity | None = None,
        corpus_identity: dict[str, str] | None = None,
        split_hash: str | None = None,
        deterministic: bool = False,
    ) -> None:
        import torch

        if config.max_steps < 1:
            raise ValueError("max_steps must be positive")
        if config.batch_size < 1:
            raise ValueError("batch_size must be positive")
        if config.seq_len < 1:
            raise ValueError("seq_len must be positive")
        if config.grad_accum_steps < 1:
            raise ValueError("grad_accum_steps must be positive")
        if config.eval_every < 1:
            raise ValueError("eval_every must be positive")
        if config.checkpoint_every < 0:
            raise ValueError("checkpoint_every must be non-negative")
        if config.num_workers < 0:
            raise ValueError("num_workers must be non-negative")
        if config.grad_clip_norm is not None and config.grad_clip_norm < 0.0:
            raise ValueError("grad_clip_norm must be non-negative")
        if config.compile:
            raise NotImplementedError(
                "train.compile is deferred until compiled-checkpoint compatibility is implemented"
            )
        if config.ema_decay is not None:
            raise NotImplementedError("train.ema_decay is not implemented by the reference trainer")
        if config.precision == "fp16":
            raise NotImplementedError("fp16 training is deferred; use bf16 or fp32")
        if not isinstance(deterministic, bool):
            raise TypeError("deterministic must be a boolean")
        seed_everything(seed, deterministic=deterministic)
        self.torch = torch
        self.seed = seed
        self.model = model
        self.config = config
        self.pad_id = pad_id
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.autocast_dtype = torch.bfloat16 if config.precision == "bf16" else None
        self.train_dataset = CorpusDataset(records, max_seq_len=config.seq_len)
        self.validation_dataset = CorpusDataset(validation_records, max_seq_len=config.seq_len)
        if not self.train_dataset:
            raise ValueError("training corpus must not be empty")
        self.run_dir = None if run_dir is None else Path(run_dir)
        self.identity = identity
        self.corpus_identity = dict(corpus_identity or {})
        self.split_hash = split_hash
        self.validation_metrics: dict[str, float] = {}

    def _batch(self, record_batch: list[CorpusRecord]) -> tuple[Any, Any, Any]:
        batch = collate_records(record_batch, pad_id=self.pad_id)
        return (
            batch.input_ids.to(self.device),
            batch.labels.to(self.device) if batch.labels is not None else None,
            batch.attention_mask.to(self.device) if batch.attention_mask is not None else None,
        )

    def _validation_loss(self, loader: Any) -> float | None:
        self.validation_metrics = {}
        if not self.validation_dataset:
            return None
        self.model.eval()
        loss_sum = 0.0
        token_count = 0
        query_count = 0
        first_loss_sum = 0.0
        set_loss_sum = 0.0
        symmetric_loss_sum = 0.0
        continuation_loss_sum = 0.0
        continuation_query_count = 0
        with self.torch.no_grad():
            for record_batch in loader:
                input_ids, labels, attention_mask = self._batch(record_batch)
                output = self._forward(input_ids, labels, attention_mask)
                query_count += len(record_batch)
                if output.first_target_loss is not None:
                    first_loss_sum += float(output.first_target_loss.detach().cpu()) * len(
                        record_batch
                    )
                if output.prompt_set_loss is not None:
                    set_loss_sum += float(output.prompt_set_loss.detach().cpu()) * len(record_batch)
                if output.symmetric_relation_loss is not None:
                    symmetric_loss_sum += float(
                        output.symmetric_relation_loss.detach().cpu()
                    ) * len(record_batch)
                if output.continuation_set_loss is not None:
                    continuation_query_count += output.continuation_set_query_count
                    continuation_loss_sum += (
                        float(output.continuation_set_loss.detach().cpu())
                        * output.continuation_set_query_count
                    )
                if output.task_loss is not None:
                    count = int((labels[:, 1:] != -100).sum().item())
                    loss_sum += float(output.task_loss.detach().cpu()) * count
                    token_count += count
        self.model.train()
        if query_count:
            self.validation_metrics["validation_first_target_loss"] = first_loss_sum / query_count
            if self.model.config.prompt_set_loss_weight:
                self.validation_metrics["validation_prompt_set_loss"] = set_loss_sum / query_count
            if self.model.config.symmetric_relation_loss_weight:
                self.validation_metrics["validation_symmetric_relation_loss"] = (
                    symmetric_loss_sum / query_count
                )
            if self.model.config.continuation_set_loss_weight:
                self.validation_metrics["validation_continuation_set_loss"] = (
                    continuation_loss_sum / continuation_query_count
                    if continuation_query_count
                    else 0.0
                )
                self.validation_metrics["validation_continuation_set_query_count"] = (
                    continuation_query_count
                )
        return loss_sum / token_count if token_count else None

    def _forward(self, input_ids: Any, labels: Any, attention_mask: Any) -> ModelOutput:
        if self.autocast_dtype is None:
            return cast(
                ModelOutput,
                self.model(input_ids, labels=labels, attention_mask=attention_mask),
            )
        with self.torch.autocast(device_type=self.device.type, dtype=self.autocast_dtype):
            return cast(
                ModelOutput,
                self.model(input_ids, labels=labels, attention_mask=attention_mask),
            )

    def train(
        self,
        *,
        checkpoint_path: str | Path | None = None,
        resume_checkpoint: str | Path | None = None,
    ) -> TrainResult:
        # Iterator creation draws a worker base seed, even with zero workers.
        # Keep that draw separate from the model's checkpointed dropout RNG.
        loader_generator = self.torch.Generator().manual_seed(self.seed)
        loader: Any = self.torch.utils.data.DataLoader(
            cast(Any, self.train_dataset),
            batch_size=self.config.batch_size,
            # Stable order is intentional: checkpoints do not need to carry a
            # partially-consumed shuffle generator to make resume exact.
            shuffle=False,
            num_workers=self.config.num_workers,
            pin_memory=self.config.pin_memory and self.device.type == "cuda",
            collate_fn=_identity_batch,
            worker_init_fn=seed_worker,
            generator=loader_generator,
        )
        validation_loader: Any = self.torch.utils.data.DataLoader(
            cast(Any, self.validation_dataset),
            batch_size=self.config.batch_size,
            shuffle=False,
            num_workers=0,
            collate_fn=_identity_batch,
            generator=self.torch.Generator().manual_seed(self.seed),
        )
        optimizer = create_optimizer(self.model, self.config.optimizer)
        scheduler = create_scheduler(
            optimizer, self.config.scheduler, total_steps=self.config.max_steps
        )
        self.model.train()
        optimizer.zero_grad(set_to_none=True)
        start_step = 0
        training_contract = {
            "objective": "causal-next-token-v1",
            "data_order": "sequential-v1",
            "record_count": len(self.train_dataset),
            "batch_size": self.config.batch_size,
            "grad_accum_steps": self.config.grad_accum_steps,
            "model_config": self.model.config.model_dump(mode="json"),
        }
        if resume_checkpoint is not None:
            restored = load_checkpoint(
                resume_checkpoint,
                self.model,
                optimizer=optimizer,
                scheduler=scheduler,
                map_location=self.device,
            )
            validate_checkpoint_identity(
                restored, identity=self.identity, split_hash=self.split_hash
            )
            metadata = restored.metadata.get("training_metadata")
            if not isinstance(metadata, dict) or any(
                metadata.get(key) != value for key, value in training_contract.items()
            ):
                raise ValueError(
                    "checkpoint training objective or data-order contract does not match"
                )
            start_step = restored.global_step
            if start_step > self.config.max_steps:
                raise ValueError("checkpoint global_step exceeds configured max_steps")
            if start_step == self.config.max_steps:
                return TrainResult(start_step, 0.0, None, ())
        history: list[dict[str, float]] = []
        last_loss = 0.0
        validation_loss: float | None = None
        global_step = start_step
        record_iterator = iter(loader)
        # Each optimizer step consumes grad_accum_steps batches. The dataset
        # and collation are deterministic and shuffle=False, so the position
        # is derivable without storing a sampler or replaying model forwards.
        batches_consumed = start_step * self.config.grad_accum_steps
        for _ in range(batches_consumed % len(loader)):
            next(record_iterator)
        while global_step < self.config.max_steps:
            optimizer.zero_grad(set_to_none=True)
            accumulated_loss = 0.0
            for _ in range(self.config.grad_accum_steps):
                try:
                    record_batch = next(record_iterator)
                except StopIteration:
                    record_iterator = iter(loader)
                    record_batch = next(record_iterator)
                input_ids, labels, attention_mask = self._batch(record_batch)
                output = self._forward(input_ids, labels, attention_mask)
                if output.loss is None:
                    raise RuntimeError("model did not return a training loss")
                accumulated_loss += float(output.loss.detach().cpu())
                (output.loss / self.config.grad_accum_steps).backward()

            if self.config.grad_clip_norm is not None:
                self.torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(), self.config.grad_clip_norm
                )
            optimizer.step()
            scheduler.step()
            global_step += 1
            last_loss = accumulated_loss / self.config.grad_accum_steps
            if global_step % self.config.eval_every == 0:
                validation_loss = self._validation_loss(validation_loader)
                row = {"step": float(global_step), "train_loss": last_loss}
                row.update(self.validation_metrics)
                if validation_loss is not None:
                    row["validation_loss"] = validation_loss
                if output.task_loss is not None:
                    row["last_batch_token_loss"] = float(output.task_loss.detach().cpu())
                if output.first_target_loss is not None:
                    row["last_batch_first_target_loss"] = float(
                        output.first_target_loss.detach().cpu()
                    )
                if output.prompt_set_loss is not None:
                    row["last_batch_prompt_set_loss"] = float(output.prompt_set_loss.detach().cpu())
                if output.symmetric_relation_loss is not None:
                    row["last_batch_symmetric_relation_loss"] = float(
                        output.symmetric_relation_loss.detach().cpu()
                    )
                if output.continuation_set_loss is not None:
                    row["last_batch_continuation_set_loss"] = float(
                        output.continuation_set_loss.detach().cpu()
                    )
                    row["last_batch_continuation_set_query_count"] = (
                        output.continuation_set_query_count
                    )
                if output.aux_loss is not None:
                    row["last_batch_router_aux_loss"] = float(output.aux_loss.detach().cpu())
                if output.expert_load is not None:
                    for layer, loads in enumerate(output.expert_load.detach().cpu().tolist()):
                        for expert, fraction in enumerate(loads):
                            row[f"last_batch_layer_{layer}_expert_{expert}_load"] = fraction
                history.append(row)
                if self.run_dir is not None:
                    self.run_dir.mkdir(parents=True, exist_ok=True)
                    with (self.run_dir / "metrics.jsonl").open("a", encoding="utf-8") as stream:
                        stream.write(json.dumps(row, sort_keys=True) + "\n")
            if (
                self.run_dir is not None
                and self.config.checkpoint_every > 0
                and global_step % self.config.checkpoint_every == 0
            ):
                save_checkpoint(
                    self.run_dir / f"checkpoint-step-{global_step}.pt",
                    self.model,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    global_step=global_step,
                    config=self.config,
                    identity=self.identity,
                    corpus_identity=self.corpus_identity,
                    split_hash=self.split_hash,
                    training_metadata={"train_loss": last_loss, **training_contract},
                )
        checkpoint = None
        if checkpoint_path is not None:
            checkpoint = save_checkpoint(
                checkpoint_path,
                self.model,
                optimizer=optimizer,
                scheduler=scheduler,
                global_step=global_step,
                config=self.config,
                identity=self.identity,
                corpus_identity=self.corpus_identity,
                split_hash=self.split_hash,
                training_metadata={"train_loss": last_loss, **training_contract},
            )
        return TrainResult(global_step, last_loss, validation_loss, tuple(history), checkpoint)
