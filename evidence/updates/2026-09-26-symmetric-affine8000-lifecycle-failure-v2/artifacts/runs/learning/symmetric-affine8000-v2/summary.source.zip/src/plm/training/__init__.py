"""Data modules, trainer, and checkpointing (Phase C reference path).

Reference training loop: optional BF16 autocast, AdamW, cosine/WSD LR with
warmup, gradient clipping + accumulation, deterministic seeding (see
:mod:`plm.reproducibility`), and PyTorch checkpoints with full run provenance.
Compiled execution, activation checkpointing, TensorBoard logging, and
``safetensors`` checkpoints remain deferred boundaries.
"""

from __future__ import annotations

from plm.training.checkpoint import CheckpointState, load_checkpoint, save_checkpoint
from plm.training.data import CorpusDataset, collate_records
from plm.training.resume import ResumeEquivalenceResult, evaluate_resume_equivalence
from plm.training.runner import run_training
from plm.training.trainer import Trainer, TrainResult

__all__ = [
    "CheckpointState",
    "CorpusDataset",
    "ResumeEquivalenceResult",
    "TrainResult",
    "Trainer",
    "collate_records",
    "evaluate_resume_equivalence",
    "load_checkpoint",
    "run_training",
    "save_checkpoint",
]
