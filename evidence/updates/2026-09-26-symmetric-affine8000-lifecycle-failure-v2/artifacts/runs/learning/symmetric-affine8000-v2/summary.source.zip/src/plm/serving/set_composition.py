"""Explicit set composition over four generated paths; never a fabricated sequence."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Literal

from plm.protocol.tokenizer import Vocabulary
from plm.serving.generation import GenerationResult
from plm.serving.set_reranking import (
    _candidate_sets_and_scores,
    _generate_group,
    _score_set_ids,
)

__all__ = ["SetCandidateSlot", "SetCompositionResult", "generate_set_compositions"]

_PAIRS = ((1, 2), (1, 3), (1, 4), (2, 3), (2, 4), (3, 4))


@dataclass(frozen=True)
class SetCandidateSlot:
    """An original or pair set with immutable source provenance and eligibility."""

    slot: int
    kind: Literal["original", "pair_composition"]
    source_ranks: tuple[int, ...]
    set_ids: tuple[int, ...]
    source_eligible: bool
    score: float


@dataclass(frozen=True)
class SetCompositionResult:
    """Canonical set selection; only source paths have raw tokens and protocol flags.

    All-ineligible fallback preserves source_paths[0] and its diagnostic member
    set. It is unsuccessful and must not be hydrated or given valid-answer credit.
    """

    source_paths: tuple[GenerationResult, ...]
    slots: tuple[SetCandidateSlot, ...]
    selected_slot: int
    selected_kind: Literal["original", "pair_composition"]
    selected_source_ranks: tuple[int, ...]
    selected_set_ids: tuple[int, ...]
    selected_source_eligible: bool
    fallback_no_valid_source: bool
    policy: str


def _compose(
    source_paths: tuple[GenerationResult, ...],
    logits: list[float],
    vocabulary: Vocabulary,
    query: tuple[str, str],
    policy: str,
) -> SetCompositionResult:
    if len(source_paths) != 4:
        raise ValueError("set composition requires exactly four source paths")
    sets, scores, eligible = _candidate_sets_and_scores(source_paths, logits, vocabulary, query)
    slots = [
        SetCandidateSlot(i + 1, "original", (i + 1,), members, flag, score)
        for i, (members, flag, score) in enumerate(zip(sets, eligible, scores, strict=True))
    ]
    for first, second in _PAIRS:
        members = tuple(sorted(set(sets[first - 1]) | set(sets[second - 1])))
        slots.append(
            SetCandidateSlot(
                len(slots) + 1,
                "pair_composition",
                (first, second),
                members,
                eligible[first - 1] and eligible[second - 1],
                _score_set_ids(members, logits),
            )
        )
    choices = [slot for slot in slots if slot.source_eligible]
    chosen = min(choices, key=lambda slot: (-slot.score, slot.slot)) if choices else slots[0]
    return SetCompositionResult(
        source_paths,
        tuple(slots),
        chosen.slot,
        chosen.kind,
        chosen.source_ranks,
        chosen.set_ids,
        chosen.source_eligible,
        not choices,
        policy,
    )


def generate_set_compositions(
    model: Any,
    vocabulary: Vocabulary,
    queries: Sequence[tuple[str, str]],
    *,
    max_new_tokens: int,
    device: str | Any = "cpu",
    first_target_guidance_alpha: float = 0.0,
) -> tuple[SetCompositionResult, ...]:
    """Generate each four-path group once and score its fixed ten-slot set pool.

    No labels, graph relations, caller filters or oracle counts enter this API.
    Loaded-checkpoint callers validate trained-head metadata at the runtime
    boundary. The one final FP32 scoring-head pass is shared by originals and
    pairs; existing per-rank first-guidance forwards remain numerically unchanged.
    """
    sources, scores, decoding = _generate_group(
        model,
        vocabulary,
        queries,
        max_new_tokens=max_new_tokens,
        device=device,
        first_target_guidance_alpha=first_target_guidance_alpha,
    )
    policy = decoding + "+first4-pair6-symmetric-set-logit-sum-v1"
    return tuple(
        _compose(paths, logits, vocabulary, query, policy)
        for paths, logits, query in zip(sources, scores, queries, strict=True)
    )
