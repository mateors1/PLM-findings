"""Predeclared, non-scalar comparison rules for AVO candidates."""

from __future__ import annotations

import math
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Literal

from plm.experimentation.evidence import HardGateResult, ObjectiveVector

__all__ = ["ComparisonResult", "ComparisonRule", "compare_objectives"]


def _nonnegative_mapping(
    values: Mapping[str, float], label: str, directions: Mapping[str, object]
) -> Mapping[str, float]:
    if not isinstance(values, Mapping):
        raise ValueError(f"{label} must be a string-to-number mapping")
    converted: dict[str, float] = {}
    for name, value in values.items():
        if not isinstance(name, str) or not name:
            raise ValueError(f"{label} keys must be non-empty strings")
        if name not in directions:
            raise ValueError(f"{label} contains undeclared objective: {name}")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"{label}[{name}] must be a finite non-negative number")
        converted_value = float(value)
        if not math.isfinite(converted_value) or converted_value < 0:
            raise ValueError(f"{label}[{name}] must be a finite non-negative number")
        converted[name] = converted_value
    return MappingProxyType(converted)


@dataclass(frozen=True)
class ComparisonResult:
    """A gate-aware comparison result without collapsing objectives to a score."""

    status: Literal["improved", "regressed", "inconclusive", "rejected"]
    reason: str
    improvements: tuple[str, ...] = ()
    regressions: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.status not in {"improved", "regressed", "inconclusive", "rejected"}:
            raise ValueError("comparison status is invalid")
        if not isinstance(self.reason, str) or not self.reason:
            raise ValueError("comparison reason must be a non-empty string")
        for label, values in (
            ("improvements", self.improvements),
            ("regressions", self.regressions),
        ):
            if not isinstance(values, (tuple, list)) or not all(
                isinstance(value, str) and value for value in values
            ):
                raise ValueError(f"comparison {label} must contain objective names")
            object.__setattr__(self, label, tuple(values))

    def to_dict(self) -> dict[str, object]:
        return {
            "status": self.status,
            "reason": self.reason,
            "improvements": list(self.improvements),
            "regressions": list(self.regressions),
        }


@dataclass(frozen=True)
class ComparisonRule:
    """Compare vectors after hard gates, with tolerances and protected limits."""

    directions: Mapping[str, Literal["maximize", "minimize"]]
    tolerances: Mapping[str, float] = field(default_factory=dict)
    meaningful_margins: Mapping[str, float] = field(default_factory=dict)
    protected_dimension_limits: Mapping[str, float] = field(default_factory=dict)
    require_all_objectives: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.directions, Mapping):
            raise ValueError("comparison directions must be a mapping")
        directions: dict[str, Literal["maximize", "minimize"]] = {}
        for name, direction in self.directions.items():
            if not isinstance(name, str) or not name:
                raise ValueError("comparison objective names must be non-empty strings")
            if direction not in {"maximize", "minimize"}:
                raise ValueError(f"comparison direction for {name} is invalid")
            directions[name] = direction
        object.__setattr__(self, "directions", MappingProxyType(directions))
        object.__setattr__(
            self,
            "tolerances",
            _nonnegative_mapping(self.tolerances, "comparison tolerances", directions),
        )
        object.__setattr__(
            self,
            "meaningful_margins",
            _nonnegative_mapping(
                self.meaningful_margins, "comparison meaningful_margins", directions
            ),
        )
        object.__setattr__(
            self,
            "protected_dimension_limits",
            _nonnegative_mapping(
                self.protected_dimension_limits,
                "comparison protected_dimension_limits",
                directions,
            ),
        )
        if not isinstance(self.require_all_objectives, bool):
            raise ValueError("comparison require_all_objectives must be boolean")

    def compare(
        self,
        candidate: ObjectiveVector,
        baseline: ObjectiveVector,
        gates: Iterable[HardGateResult] = (),
    ) -> ComparisonResult:
        failed = tuple(gate.name for gate in gates if not gate.passed)
        if failed:
            return ComparisonResult("rejected", f"hard gates failed: {', '.join(failed)}")

        names = tuple(self.directions)
        if not names:
            return ComparisonResult("inconclusive", "no objectives were declared")
        missing = tuple(
            name for name in names if name not in candidate.values or name not in baseline.values
        )
        if missing:
            return ComparisonResult(
                "inconclusive", f"missing objective values: {', '.join(missing)}"
            )

        improvements: list[str] = []
        regressions: list[str] = []
        meaningful = False
        for name in names:
            direction = self.directions[name]
            delta = candidate.values[name] - baseline.values[name]
            signed = delta if direction == "maximize" else -delta
            tolerance = self.tolerances.get(name, 0.0)
            margin = self.meaningful_margins.get(name, 0.0)
            protected_limit = self.protected_dimension_limits.get(name)

            if signed > tolerance:
                improvements.append(name)
                meaningful = meaningful or signed > max(tolerance, margin)
            elif signed < -tolerance:
                # A protected dimension may decline inside its declared limit;
                # that decline is neutral and does not block a Pareto gain on
                # another objective.  Outside the limit it is a regression.
                if protected_limit is None or signed < -protected_limit:
                    regressions.append(name)

        if regressions:
            return ComparisonResult(
                "regressed",
                f"protected or objective regressions: {', '.join(regressions)}",
                tuple(improvements),
                tuple(regressions),
            )
        if not improvements or not meaningful:
            return ComparisonResult(
                "inconclusive",
                "change is within declared noise or margin",
                tuple(improvements),
            )
        if self.require_all_objectives and len(improvements) != len(names):
            return ComparisonResult(
                "inconclusive", "not all objectives improved", tuple(improvements)
            )
        return ComparisonResult(
            "improved",
            "candidate exceeds the declared comparison margin",
            tuple(improvements),
        )


def compare_objectives(
    candidate: ObjectiveVector,
    baseline: ObjectiveVector,
    *,
    directions: Mapping[str, Literal["maximize", "minimize"]],
    tolerances: Mapping[str, float] | None = None,
    meaningful_margins: Mapping[str, float] | None = None,
    protected_dimension_limits: Mapping[str, float] | None = None,
    require_all_objectives: bool = False,
    gates: Iterable[HardGateResult] = (),
) -> ComparisonResult:
    """Convenience wrapper for a one-off predeclared comparison."""

    return ComparisonRule(
        directions=directions,
        tolerances={} if tolerances is None else tolerances,
        meaningful_margins={} if meaningful_margins is None else meaningful_margins,
        protected_dimension_limits=(
            {} if protected_dimension_limits is None else protected_dimension_limits
        ),
        require_all_objectives=require_all_objectives,
    ).compare(candidate, baseline, gates)
