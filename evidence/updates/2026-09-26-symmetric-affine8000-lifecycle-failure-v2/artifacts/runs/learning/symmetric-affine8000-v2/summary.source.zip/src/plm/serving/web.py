"""Optional FastAPI transport for the native predictor."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from fastapi import FastAPI, HTTPException

from plm.serving.native import (
    GenerationFailure,
    InvalidRequestError,
    NativePredictor,
    PredictRequest,
    ServiceBusyError,
    SetCompositionDisabled,
    SetCompositionFailure,
)

__all__ = ["create_serving_app"]


def create_serving_app(predictor: NativePredictor) -> FastAPI:
    """Expose deployment identity, strict prediction requests and explicit failures."""
    app = FastAPI(title="PLM native reference service", version="0.1.0")

    @app.get("/health")
    def health() -> dict[str, Any]:
        return {"ready": True, **predictor.deployment}

    @app.post("/v1/predict")
    def predict(request: PredictRequest) -> dict[str, Any]:
        try:
            return predictor.predict(request)
        except ServiceBusyError as exc:
            raise HTTPException(
                status_code=503, detail=str(exc), headers={"Retry-After": "1"}
            ) from exc
        except GenerationFailure as exc:
            raise HTTPException(
                status_code=502,
                detail={"code": "generation_incomplete_or_invalid", "raw": asdict(exc.raw)},
            ) from exc
        except InvalidRequestError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @app.post("/v1/predict-set")
    def predict_set(request: PredictRequest) -> dict[str, Any]:
        try:
            return predictor.predict_set(request)
        except SetCompositionDisabled as exc:
            raise HTTPException(
                status_code=409, detail={"code": "set_composition_disabled"}
            ) from exc
        except ServiceBusyError as exc:
            raise HTTPException(
                status_code=503, detail=str(exc), headers={"Retry-After": "1"}
            ) from exc
        except SetCompositionFailure as exc:
            raise HTTPException(
                status_code=502,
                detail={
                    "code": "set_composition_no_valid_source",
                    **asdict(exc.composition),
                },
            ) from exc
        except InvalidRequestError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    return app
