"""Deterministic seeding.

Seeds Python, NumPy, and (when installed) Torch. Torch is an optional import so
this module works in the Phase A / core environment, which has no torch.

The determinism switch does the parts that actually matter and are easy to
forget:

* ``CUBLAS_WORKSPACE_CONFIG`` — without it, ``use_deterministic_algorithms`` on
  CUDA raises at runtime for several ops.
* cuDNN benchmark off, deterministic on.
* :func:`seed_worker` for ``DataLoader(worker_init_fn=...)`` — without it,
  workers re-introduce nondeterminism regardless of the global seed.

Windows note: ``DataLoader(num_workers > 0)`` uses spawn; the training
entrypoint must be guarded by ``if __name__ == "__main__":``.
"""

from __future__ import annotations

import os
import random

import numpy as np

__all__ = ["seed_everything", "seed_worker"]


def seed_everything(seed: int, *, deterministic: bool = False) -> None:
    """Seed all RNGs and record the seed in the environment.

    Args:
        seed: The seed value; also written to ``PYTHONHASHSEED``.
        deterministic: If ``True``, request deterministic algorithms. This can
            slow training, so it is a switch rather than a permanent default.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)

    try:
        import torch
    except ImportError:
        # Core / Phase A environment has no torch — nothing more to seed.
        return

    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    if deterministic:
        # Must be set before the first CUDA work for it to take effect.
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch.use_deterministic_algorithms(True, warn_only=False)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True


def seed_worker(worker_id: int) -> None:
    """``DataLoader`` ``worker_init_fn`` that reseeds NumPy/random per worker."""
    import torch

    worker_seed = (torch.initial_seed() + worker_id) % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)
