"""Small deterministic helpers for repeated evaluator measurements."""

from __future__ import annotations

import math
from collections.abc import Iterable
from dataclasses import dataclass
from statistics import fmean, pstdev

__all__ = ["MeasurementSummary", "summarize_measurements"]


@dataclass(frozen=True)
class MeasurementSummary:
    count: int
    mean: float
    stddev: float
    minimum: float
    maximum: float

    def to_dict(self) -> dict[str, float | int]:
        return {
            "count": self.count,
            "mean": self.mean,
            "stddev": self.stddev,
            "min": self.minimum,
            "max": self.maximum,
        }


def summarize_measurements(values: Iterable[float]) -> MeasurementSummary:
    samples = tuple(float(value) for value in values)
    if not samples or not all(math.isfinite(value) for value in samples):
        raise ValueError("measurements must contain at least one finite value")
    return MeasurementSummary(
        count=len(samples),
        mean=fmean(samples),
        stddev=pstdev(samples),
        minimum=min(samples),
        maximum=max(samples),
    )
