"""Score selected sets while keeping raw source-path diagnostics separate."""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import asdict, dataclass

from plm.corpus.compiler import CorpusRecord
from plm.protocol.tokenizer import Vocabulary
from plm.serving.generation import GenerationResult
from plm.serving.set_composition import SetCompositionResult

__all__ = ["SetCompositionMetrics", "evaluate_set_compositions"]


@dataclass(frozen=True)
class SetCompositionMetrics:
    query_count: int
    precision: float
    recall: float
    f1: float
    exact_set_accuracy: float
    exact_set_count: int
    mean_set_size: float
    selected_source_eligibility_rate: float
    failure_count: int
    original_selection_count: int
    pair_selection_count: int
    source_path_count: int
    source_path_protocol_valid_rate: float
    source_path_termination_rate: float
    source_path_error_count: int
    source_path_duplicate_count: int

    def to_dict(self) -> dict[str, float | int]:
        return asdict(self)


def evaluate_set_compositions(
    records: Sequence[CorpusRecord],
    results: Sequence[SetCompositionResult],
    vocabulary: Vocabulary,
) -> SetCompositionMetrics:
    """Macro-average successful answers; every failed answer receives zero credit.

    Size also uses zero for a failure, with all queries in the denominator.
    Original/pair counts describe successes only, so they plus failure_count
    equal query_count. Raw truncated members remain inspectable in source paths.
    No sequence, EOS or protocol-valid metric is attributed to the composed set.
    """
    if not records or len(records) != len(results):
        raise ValueError("set evaluation requires nonempty, aligned records and results")
    precisions, recalls, f1s = [], [], []
    sizes: list[int] = []
    exact = failures = originals = pairs = 0
    sources: list[GenerationResult] = []
    for record, result in zip(records, results, strict=True):
        if len(result.source_paths) != 4:
            raise ValueError("set evaluation requires four source paths per query")
        expected = set(vocabulary.encode(record.targets))
        if not expected:
            raise ValueError("set evaluation requires nonempty oracle targets")
        sources.extend(result.source_paths)
        success = result.selected_source_eligible and not result.fallback_no_valid_source
        predicted = set(result.selected_set_ids) if success else set()
        matches = len(predicted & expected)
        precision = matches / len(predicted) if predicted else 0.0
        recall = matches / len(expected)
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        precisions.append(precision)
        recalls.append(recall)
        f1s.append(f1)
        sizes.append(len(predicted))
        exact += int(success and predicted == expected)
        failures += int(not success)
        originals += int(success and result.selected_kind == "original")
        pairs += int(success and result.selected_kind == "pair_composition")
    count, source_count = len(records), len(sources)
    return SetCompositionMetrics(
        query_count=count,
        precision=math.fsum(precisions) / count,
        recall=math.fsum(recalls) / count,
        f1=math.fsum(f1s) / count,
        exact_set_accuracy=exact / count,
        exact_set_count=exact,
        mean_set_size=math.fsum(sizes) / count,
        selected_source_eligibility_rate=(count - failures) / count,
        failure_count=failures,
        original_selection_count=originals,
        pair_selection_count=pairs,
        source_path_count=source_count,
        source_path_protocol_valid_rate=sum(p.protocol_valid for p in sources) / source_count,
        source_path_termination_rate=sum(p.terminated for p in sources) / source_count,
        source_path_error_count=sum(p.error is not None for p in sources),
        source_path_duplicate_count=sum(len(p.targets) != len(set(p.targets)) for p in sources),
    )
