"""Dimension-specific target-frequency baseline."""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Iterable

from plm.corpus.compiler import CorpusRecord

__all__ = ["PopularityScorer"]


class PopularityScorer:
    def __init__(self, training_records: Iterable[CorpusRecord]) -> None:
        counts: defaultdict[str, Counter[str]] = defaultdict(Counter)
        for record in training_records:
            counts[record.dimension].update(record.targets)
        self.counts = dict(counts)

    def score(self, query: CorpusRecord, candidate: str) -> float:
        return float(self.counts.get(query.dimension, Counter()).get(candidate, 0))

    __call__ = score
