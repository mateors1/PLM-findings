"""Fail-closed validation of content-addressed corpus artifacts."""

from __future__ import annotations

import hashlib
import json
import sqlite3
from collections.abc import Mapping
from dataclasses import asdict, dataclass
from pathlib import Path

from plm.corpus.compiler import CorpusManifest, CorpusRecord, canonical_graph_hash
from plm.graph.schema import connect
from plm.protocol.config import ProtocolSpec
from plm.protocol.tokenizer import Vocabulary

__all__ = [
    "ArtifactValidationError",
    "ArtifactValidationReport",
    "load_corpus_records",
    "require_valid_artifacts",
    "validate_corpus_artifacts",
]


class ArtifactValidationError(ValueError):
    """Raised when a corpus artifact identity or payload does not validate."""


@dataclass(frozen=True)
class ArtifactValidationReport:
    manifest: CorpusManifest | None
    issues: tuple[str, ...]

    @property
    def ok(self) -> bool:
        return not self.issues


def _load_manifest(path: Path) -> CorpusManifest:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, Mapping):
        raise ValueError("manifest must be a JSON object")
    expected = {
        "schema_version",
        "protocol_version",
        "tokenizer_hash",
        "graph_hash",
        "records_hash",
        "record_count",
        "vocabulary_size",
    }
    missing = expected - set(raw)
    if missing:
        raise ValueError(f"manifest missing fields: {', '.join(sorted(missing))}")
    return CorpusManifest(
        schema_version=int(raw["schema_version"]),
        protocol_version=str(raw["protocol_version"]),
        tokenizer_hash=str(raw["tokenizer_hash"]),
        graph_hash=str(raw["graph_hash"]),
        records_hash=str(raw["records_hash"]),
        record_count=int(raw["record_count"]),
        vocabulary_size=int(raw["vocabulary_size"]),
    )


def _load_records(path: Path) -> tuple[list[CorpusRecord], str]:
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    records: list[CorpusRecord] = []
    for line_number, line in enumerate(lines, 1):
        try:
            raw = json.loads(line)
            records.append(
                CorpusRecord(
                    subject=str(raw["subject"]),
                    dimension=str(raw["dimension"]),
                    targets=tuple(str(item) for item in raw["targets"]),
                    input_ids=tuple(int(item) for item in raw["input_ids"]),
                    labels=tuple(int(item) for item in raw["labels"]),
                )
            )
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            raise ValueError(f"invalid records.jsonl line {line_number}: {exc}") from exc
    canonical = "".join(
        json.dumps(asdict(record), ensure_ascii=True, separators=(",", ":")) + "\n"
        for record in records
    )
    return records, hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def load_corpus_records(corpus_dir: str | Path) -> list[CorpusRecord]:
    """Load records after syntax validation; identity validation is separate."""

    records, _ = _load_records(Path(corpus_dir) / "records.jsonl")
    if not records:
        raise ArtifactValidationError("corpus records.jsonl must contain at least one record")
    return records


def validate_corpus_artifacts(
    corpus_dir: str | Path,
    *,
    graph_db: str | Path | None = None,
    protocol: ProtocolSpec | None = None,
) -> ArtifactValidationReport:
    """Validate manifest, vocabulary, records, and optional graph identity."""

    root = Path(corpus_dir)
    issues: list[str] = []
    manifest: CorpusManifest | None = None
    try:
        manifest = _load_manifest(root / "manifest.json")
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        issues.append(f"manifest invalid: {exc}")

    vocab: Vocabulary | None = None
    try:
        vocab = Vocabulary.load(root / "vocabulary.json")
    except (OSError, ValueError, TypeError, json.JSONDecodeError, IndexError) as exc:
        issues.append(f"vocabulary invalid: {exc}")

    records: list[CorpusRecord] = []
    records_hash: str | None = None
    try:
        records, records_hash = _load_records(root / "records.jsonl")
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        issues.append(f"records invalid: {exc}")

    if manifest is not None:
        if manifest.schema_version != 1:
            issues.append(f"unsupported corpus schema_version: {manifest.schema_version}")
        if vocab is not None:
            if vocab.content_hash() != manifest.tokenizer_hash:
                issues.append("vocabulary content hash does not match manifest")
            if len(vocab) != manifest.vocabulary_size:
                issues.append("vocabulary size does not match manifest")
            if vocab.version != manifest.protocol_version:
                issues.append("vocabulary protocol version does not match manifest")
        if records_hash is not None:
            if records_hash != manifest.records_hash:
                issues.append("records content hash does not match manifest")
            if len(records) != manifest.record_count:
                issues.append("record count does not match manifest")
        if protocol is not None:
            try:
                protocol.validate_for_compilation()
            except ValueError as exc:
                issues.append(f"protocol invalid: {exc}")
            if protocol.version != manifest.protocol_version:
                issues.append("protocol version does not match manifest")
        if graph_db is not None:
            try:
                graph_path = Path(graph_db)
                if not graph_path.exists():
                    raise FileNotFoundError(f"graph database not found: {graph_path}")
                conn = connect(graph_path)
                try:
                    actual_graph_hash = canonical_graph_hash(conn)
                finally:
                    conn.close()
                if actual_graph_hash != manifest.graph_hash:
                    issues.append("graph content hash does not match manifest")
            except (OSError, ValueError, TypeError, sqlite3.Error) as exc:
                issues.append(f"graph identity invalid: {exc}")

    return ArtifactValidationReport(manifest, tuple(issues))


def require_valid_artifacts(
    corpus_dir: str | Path,
    *,
    graph_db: str | Path | None = None,
    protocol: ProtocolSpec | None = None,
) -> ArtifactValidationReport:
    """Return a report or stop the caller before it consumes untrusted data."""

    report = validate_corpus_artifacts(corpus_dir, graph_db=graph_db, protocol=protocol)
    if not report.ok:
        raise ArtifactValidationError("; ".join(report.issues))
    return report
