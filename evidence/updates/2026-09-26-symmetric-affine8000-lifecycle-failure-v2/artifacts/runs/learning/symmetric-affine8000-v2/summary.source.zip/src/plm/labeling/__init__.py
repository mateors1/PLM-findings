"""Optional local web application for reviewing and curating graph buckets."""

from __future__ import annotations

from plm.labeling.web import create_labeling_app

__all__ = ["create_labeling_app"]
