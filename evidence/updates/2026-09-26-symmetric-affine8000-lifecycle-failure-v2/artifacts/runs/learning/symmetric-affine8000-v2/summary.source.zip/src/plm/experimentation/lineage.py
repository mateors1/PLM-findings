"""Filesystem-backed, namespace-separated candidate lineage."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from plm.experimentation.evidence import CandidateRecord, EvaluationReceipt, LineageEntry

__all__ = ["LineageLedger", "namespace_root"]


def namespace_root(run_root: str | Path, namespace: Literal["development", "research"]) -> Path:
    """Return the untracked namespace root for one AVO history."""

    if namespace not in {"development", "research"}:
        raise ValueError("namespace must be development or research")
    return Path(run_root) / "avo" / namespace


class LineageLedger:
    """Store candidate, receipt, and lineage JSON without mixing namespaces."""

    def __init__(self, run_root: str | Path, namespace: Literal["development", "research"]) -> None:
        self.namespace = namespace
        self.root = namespace_root(run_root, namespace)
        self.root.mkdir(parents=True, exist_ok=True)

    def write_candidate(self, candidate: CandidateRecord) -> Path:
        if candidate.namespace != self.namespace:
            raise ValueError("candidate namespace does not match this lineage ledger")
        path = self.root / "candidates" / f"{candidate.candidate_id}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(candidate.to_dict(), ensure_ascii=True, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
        )
        return path

    def write_receipt(self, receipt: EvaluationReceipt) -> Path:
        if receipt.namespace != self.namespace:
            raise ValueError("receipt namespace does not match this lineage ledger")
        path = self.root / "receipts" / f"{receipt.candidate_id}.json"
        receipt.save(path)
        return path

    def append_lineage(self, entry: LineageEntry) -> Path:
        if entry.namespace != self.namespace:
            raise ValueError("lineage entry namespace does not match this ledger")
        path = self.root / "lineage.jsonl"
        with path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(entry.to_dict(), ensure_ascii=True, sort_keys=True) + "\n")
        return path
