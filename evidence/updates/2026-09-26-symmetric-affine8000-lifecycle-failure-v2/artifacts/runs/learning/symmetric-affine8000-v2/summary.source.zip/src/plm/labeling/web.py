"""FastAPI labeling UI, imported only by the optional ``serving`` group."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from plm.graph.repository import GraphRepository

__all__ = ["create_labeling_app"]

_PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>PLM Labeling</title>
<style>body{font:16px system-ui;max-width:760px;margin:2rem auto;padding:0 1rem}button,select{font:inherit;padding:.4rem;margin:.25rem}fieldset{margin:1rem 0}#status{min-height:1.5rem;color:#065f46}.key{color:#666;font-family:monospace}</style>
</head><body><h1>PLM graph labeling</h1><p>Review and curate <code>TYPE</code> and <code>COLOR</code> buckets. Saving replaces this product's existing facts with curated provenance.</p>
<button id="previous">Previous</button><button id="next">Next</button><span id="position"></span>
<h2 id="name"></h2><div class="key" id="key"></div><form id="form"><fieldset><legend>Types (one or more)</legend><div id="types"></div></fieldset><fieldset><legend>Color (one)</legend><div id="colors"></div></fieldset><button type="submit">Save curated labels</button></form><p id="status"></p>
<script>
let products=[],attributes={},index=0,current=null;
const byId=id=>document.getElementById(id);
async function load(){attributes=await (await fetch('/api/attributes')).json();products=await (await fetch('/api/products')).json();await show();}
function escapeHtml(value){return String(value).replace(/[&<>\"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[char]))}
function option(kind,value,checked){return `<label><input type="${kind==='color'?'radio':'checkbox'}" name="${escapeHtml(kind)}" value="${escapeHtml(value.key)}" ${checked?'checked':''}> ${escapeHtml(value.label)}</label><br>`}
async function show(){if(!products.length)return;current=await (await fetch('/api/product/'+encodeURIComponent(products[index].key))).json();byId('name').textContent=current.label;byId('key').textContent=current.key;byId('position').textContent=`${index+1} / ${products.length}`;byId('types').innerHTML=attributes.types.map(x=>option('type',x,current.types.includes(x.key))).join('');byId('colors').innerHTML=attributes.colors.map(x=>option('color',x,current.color===x.key)).join('');}
byId('previous').onclick=async()=>{index=(index+products.length-1)%products.length;await show()};byId('next').onclick=async()=>{index=(index+1)%products.length;await show()};
byId('form').onsubmit=async e=>{e.preventDefault();const types=[...document.querySelectorAll('input[name=type]:checked')].map(x=>x.value);const color=document.querySelector('input[name=color]:checked')?.value;const response=await fetch('/api/product/'+encodeURIComponent(current.key),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({types,color})});const result=await response.json();byId('status').textContent=response.ok?'Saved.':result.detail||'Save failed.';if(response.ok)await show()};load();
</script></body></html>"""


def _attribute_options(repo: GraphRepository, relation: str) -> list[dict[str, str]]:
    return [
        {"key": key, "label": key.removeprefix("ATTR_")} for key in repo.attribute_keys(relation)
    ]


def _product(repo: GraphRepository, key: str) -> dict[str, object]:
    if key not in repo.node_keys(kind="product"):
        raise KeyError(key)
    types = repo.relation_targets(key, "HAS_TYPE")
    colors = repo.relation_targets(key, "HAS_COLOR")
    return {
        "key": key,
        "label": repo.node_label(key),
        "types": types,
        "color": colors[0] if colors else None,
    }


def _replace_labels_atomically(
    repo: GraphRepository, key: str, types: list[str], color: str, provenance_id: int
) -> None:
    """Replace TYPE and COLOR edges in one SQLite transaction."""
    src_id = repo.node_id(key)
    type_rel = repo.add_relation_type("HAS_TYPE")
    color_rel = repo.add_relation_type("HAS_COLOR")
    type_ids = [repo.node_id(item) for item in types]
    color_id = repo.node_id(color)
    with repo._conn:
        repo._conn.execute(
            "DELETE FROM edges WHERE src = ? AND rel IN (?, ?)", (src_id, type_rel, color_rel)
        )
        repo._conn.executemany(
            "INSERT INTO edges(src, dst, rel, provenance_id, is_canonical) VALUES (?, ?, ?, ?, 0)",
            [(src_id, dst_id, type_rel, provenance_id) for dst_id in type_ids]
            + [(src_id, color_id, color_rel, provenance_id)],
        )


def create_labeling_app(db_path: str | Path) -> Any:
    """Create the optional local FastAPI application for graph curation."""
    try:
        from fastapi import FastAPI, HTTPException
        from fastapi.responses import HTMLResponse
    except ModuleNotFoundError as exc:  # pragma: no cover - exercised by CLI message
        raise RuntimeError("install the serving group: uv sync --group serving") from exc

    database = Path(db_path)
    app = FastAPI(title="PLM Labeling", docs_url=None, redoc_url=None)

    @app.get("/", response_class=HTMLResponse)
    def home() -> str:
        return _PAGE

    @app.get("/api/products")
    def products() -> list[dict[str, str]]:
        with GraphRepository(database) as repo:
            keys = repo.node_keys(kind="product")
            return [{"key": key, "label": repo.node_label(key)} for key in keys]

    @app.get("/api/attributes")
    def attributes() -> dict[str, list[dict[str, str]]]:
        with GraphRepository(database) as repo:
            return {
                "types": _attribute_options(repo, "HAS_TYPE"),
                "colors": _attribute_options(repo, "HAS_COLOR"),
            }

    @app.get("/api/product/{key}")
    def product(key: str) -> dict[str, object]:
        try:
            with GraphRepository(database) as repo:
                return _product(repo, key)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="unknown product") from exc

    @app.put("/api/product/{key}")
    def save_product(key: str, payload: dict[str, object]) -> dict[str, bool]:
        types = payload.get("types")
        color = payload.get("color")
        if not isinstance(types, list) or not all(isinstance(item, str) for item in types):
            raise HTTPException(status_code=422, detail="types must be a non-empty string list")
        if not isinstance(color, str):
            raise HTTPException(status_code=422, detail="color must be a string")
        with GraphRepository(database) as repo:
            allowed_types = {item["key"] for item in _attribute_options(repo, "HAS_TYPE")}
            allowed_colors = {item["key"] for item in _attribute_options(repo, "HAS_COLOR")}
            if not types or not set(types) <= allowed_types or color not in allowed_colors:
                raise HTTPException(status_code=422, detail="labels must be known graph attributes")
            try:
                repo.node_id(key)
            except KeyError as exc:
                raise HTTPException(status_code=404, detail="unknown product") from exc
            provenance_id = repo.add_provenance(
                "curated", notes=f"Local labeling web app assignment for {key}."
            )
            _replace_labels_atomically(repo, key, types, color, provenance_id)
        return {"ok": True}

    return app
