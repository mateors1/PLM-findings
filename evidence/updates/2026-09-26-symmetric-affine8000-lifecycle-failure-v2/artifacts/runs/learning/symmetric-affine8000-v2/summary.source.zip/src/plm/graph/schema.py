"""SQLite schema, initialization, and validation for the product graph."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

__all__ = ["SCHEMA_VERSION", "ValidationReport", "connect", "init_graph", "validate_graph"]

SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Fact/entity lineage. Created before nodes/edges so their FKs resolve.
CREATE TABLE IF NOT EXISTS provenance (
    id          INTEGER PRIMARY KEY,
    source_type TEXT NOT NULL,             -- 'canon' | 'synthetic' | 'curated'
    citation    TEXT,
    license     TEXT,
    notes       TEXT
);

CREATE TABLE IF NOT EXISTS nodes (
    id            INTEGER PRIMARY KEY,
    key           TEXT NOT NULL UNIQUE,      -- product SKU (e.g. a name-as-SKU)
    namespace     TEXT NOT NULL DEFAULT 'PKM',
    kind          TEXT NOT NULL DEFAULT 'product',  -- 'product' (emittable) | 'attribute' (hidden)
    label         TEXT,                      -- hydration-only; never seen by the model
    status        TEXT NOT NULL DEFAULT 'active',
    provenance_id INTEGER REFERENCES provenance(id)
);

CREATE TABLE IF NOT EXISTS relation_types (
    id       INTEGER PRIMARY KEY,
    name     TEXT NOT NULL UNIQUE,
    category TEXT                            -- optional predicate grouping
);

CREATE TABLE IF NOT EXISTS edges (
    id            INTEGER PRIMARY KEY,
    src           INTEGER NOT NULL REFERENCES nodes(id),
    dst           INTEGER NOT NULL REFERENCES nodes(id),
    rel           INTEGER NOT NULL REFERENCES relation_types(id),
    weight        REAL NOT NULL DEFAULT 1.0,
    confidence    REAL NOT NULL DEFAULT 1.0,     -- ordering step 2 (protocol §5.3)
    is_canonical  INTEGER NOT NULL DEFAULT 1,    -- 0/1: canon vs synthetic/curated fact
    provenance_id INTEGER REFERENCES provenance(id),
    UNIQUE (src, dst, rel)
);

-- Deferred for v1 (synthetic SKUs need no localized names); table exists so the
-- parser's normalization step has a home when real canon is imported.
CREATE TABLE IF NOT EXISTS aliases (
    id       INTEGER PRIMARY KEY,
    node_id  INTEGER NOT NULL REFERENCES nodes(id),
    alias    TEXT NOT NULL,
    locale   TEXT NOT NULL DEFAULT '',
    priority INTEGER NOT NULL DEFAULT 0,
    UNIQUE (alias, locale)
);

CREATE TABLE IF NOT EXISTS snapshots (
    id                INTEGER PRIMARY KEY,
    name              TEXT NOT NULL UNIQUE,
    protocol_version  TEXT,
    tokenizer_version TEXT,
    node_count        INTEGER NOT NULL,
    edge_count        INTEGER NOT NULL,
    hash              TEXT NOT NULL,
    created_at        TEXT
);

CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst);
CREATE INDEX IF NOT EXISTS idx_edges_rel ON edges(rel);
CREATE INDEX IF NOT EXISTS idx_nodes_kind ON nodes(kind);
CREATE INDEX IF NOT EXISTS idx_aliases_node ON aliases(node_id);
"""


@dataclass
class ValidationReport:
    node_count: int
    edge_count: int
    relation_type_count: int
    schema_version: int
    protocol_version: str
    issues: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.issues


def connect(db_path: str | Path) -> sqlite3.Connection:
    """Open a connection with foreign keys enforced."""
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_graph(db_path: str | Path, *, protocol_version: str = "0.0.0-dev") -> None:
    """Create the schema (idempotent) and stamp meta."""
    conn = connect(db_path)
    try:
        conn.executescript(_SCHEMA)
        conn.executemany(
            "INSERT INTO meta(key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [
                ("schema_version", str(SCHEMA_VERSION)),
                ("protocol_version", protocol_version),
            ],
        )
        conn.commit()
    finally:
        conn.close()


def validate_graph(db_path: str | Path) -> ValidationReport:
    """Check referential integrity and report basic counts."""
    if not Path(db_path).exists():
        raise FileNotFoundError(f"graph database not found: {db_path}")

    conn = connect(db_path)
    try:
        cur = conn.cursor()
        node_count = _scalar(cur, "SELECT COUNT(*) FROM nodes")
        edge_count = _scalar(cur, "SELECT COUNT(*) FROM edges")
        rel_count = _scalar(cur, "SELECT COUNT(*) FROM relation_types")

        meta = dict(cur.execute("SELECT key, value FROM meta").fetchall())
        schema_version = int(meta.get("schema_version", "0"))
        protocol_version = str(meta.get("protocol_version", "unknown"))

        issues: list[str] = []
        if schema_version != SCHEMA_VERSION:
            issues.append(f"schema_version {schema_version} != expected {SCHEMA_VERSION}")
        # SQLite's own FK integrity check.
        fk_violations = cur.execute("PRAGMA foreign_key_check").fetchall()
        if fk_violations:
            issues.append(f"{len(fk_violations)} foreign-key violation(s)")
        # Self-loops are usually a modeling error for a product relation graph.
        self_loops = _scalar(cur, "SELECT COUNT(*) FROM edges WHERE src = dst")
        if self_loops:
            issues.append(f"{self_loops} self-loop edge(s)")

        return ValidationReport(
            node_count=node_count,
            edge_count=edge_count,
            relation_type_count=rel_count,
            schema_version=schema_version,
            protocol_version=protocol_version,
            issues=issues,
        )
    finally:
        conn.close()


def _scalar(cur: sqlite3.Cursor, sql: str) -> int:
    row = cur.execute(sql).fetchone()
    return int(row[0]) if row is not None else 0
