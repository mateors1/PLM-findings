"""PLM decoder architecture — factory boundary for the Phase-C reference model.

Intended stack (over-engineered by design; every item is a validated field on
:class:`plm.config.ModelConfig`):

* Pre-norm **RMSNorm** transformer blocks.
* **RoPE** positional encoding (advanced scaling is a declared hypothesis).
* **Grouped-Query Attention** (``n_kv_heads`` → MHA…MQA continuum) with optional
  **QK-norm**, sliding-window attention, and **logit soft-capping**.
* **SwiGLU** feed-forward, hidden dim rounded to ``ffn_multiple_of``.
* Optional sparse top-k **Mixture-of-Experts** FFN with router telemetry.
* Weight-tied embeddings; **muP** remains unsupported.
* Attention via ``torch.nn.functional.scaled_dot_product_attention`` where the
  configured backend is supported; deterministic mode uses the eager reference
  path. Activation checkpointing and opt-in native KV caching are supported.

Kept torch-free at import time so Phase A / core stays dependency-light.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from plm.config import ModelConfig

__all__ = ["build_model"]


def build_model(config: ModelConfig) -> Any:
    """Instantiate the PLM decoder from a validated :class:`ModelConfig`.

    Raises:
        ImportError: If the optional training dependency is not installed.
        NotImplementedError: If an advanced config switch is not supported by
            the minimal reference decoder.
    """
    try:
        import torch  # noqa: F401  # imported at the dependency boundary
    except ImportError as exc:
        raise ImportError(
            "PLM decoder requires the optional torch dependency; run `uv sync --group training`"
        ) from exc
    from plm.model.layers import PLMDecoder

    return PLMDecoder(config)
