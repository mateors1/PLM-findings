"""Optional first-position scoring from the model's existing learned head."""

from __future__ import annotations

import math
from dataclasses import replace
from numbers import Real
from typing import Any

from plm.model.interfaces import DecodeOutput
from plm.protocol.tokenizer import ENTITY_BASE

__all__ = [
    "apply_first_target_guidance",
    "guidance_decoding_suffix",
    "validate_guidance_alpha",
]


def validate_guidance_alpha(alpha: object) -> None:
    """Require a finite nonnegative numeric strength, rejecting booleans."""
    if isinstance(alpha, bool) or not isinstance(alpha, Real):
        raise ValueError("guidance strength must be a finite nonnegative number")
    try:
        value = float(alpha)
        valid = math.isfinite(value) and value >= 0
    except OverflowError:
        valid = False
    if not valid:
        raise ValueError("guidance strength must be a finite nonnegative number")


def guidance_decoding_suffix(alpha: float) -> str:
    """Identify the inference intervention without changing zero-strength labels."""
    validate_guidance_alpha(alpha)
    return "" if alpha == 0 else f"+first-relation-logsigmoid-alpha{alpha:.17g}-v1"


def apply_first_target_guidance(
    model: Any, input_ids: Any, decoded: DecodeOutput, alpha: float
) -> DecodeOutput:
    """Bias only product logits at a fresh five-token prefill's final position.

    Callers own the first-step condition. The zero path returns the original
    output without running the optional head or importing Torch. Positive
    strength reuses the existing forward head with prompt IDs only, preserving
    the frozen experiment's extra forward pass and FP32 log-sigmoid arithmetic.
    """
    validate_guidance_alpha(alpha)
    if alpha == 0:
        return decoded

    import torch
    import torch.nn.functional as F

    if input_ids.ndim != 2 or input_ids.shape[1] != 5:
        raise ValueError("first guidance requires a five-token prompt")
    if (
        decoded.logits.ndim != 3
        or decoded.logits.shape[:2] != input_ids.shape
        or decoded.logits.shape[-1] <= ENTITY_BASE
    ):
        raise ValueError("guidance requires prompt-aligned logits with product columns")
    if not callable(model):
        raise ValueError("guidance requires a model with a symmetric relation head")
    scores = getattr(model(input_ids), "symmetric_relation_logits", None)
    expected_shape = (input_ids.shape[0], decoded.logits.shape[-1] - ENTITY_BASE)
    if (
        not isinstance(scores, torch.Tensor)
        or scores.shape != expected_shape
        or not torch.isfinite(scores).all()
    ):
        raise ValueError("guidance requires finite product-aligned relation logits")
    logits = decoded.logits.clone()
    logits[:, -1, ENTITY_BASE:] += alpha * F.logsigmoid(scores.float())
    return replace(decoded, logits=logits)
