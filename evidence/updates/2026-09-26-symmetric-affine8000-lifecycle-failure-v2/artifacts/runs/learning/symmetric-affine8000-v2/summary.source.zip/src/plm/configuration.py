"""Authoritative Hydra-to-Pydantic configuration loading.

Commands and experiment helpers use this module instead of recreating CLI
defaults. Hydra resolves interpolation and group composition first; only the
resolved mapping is then validated by :mod:`plm.config`.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from copy import deepcopy
from pathlib import Path
from typing import Any, cast

from hydra import compose, initialize_config_dir
from omegaconf import DictConfig, OmegaConf

from plm.config import RootConfig, validate_config

__all__ = ["config_hash", "load_config", "resolved_config_dict", "validate_saved_config"]


def _default_config_dir() -> Path:
    return Path(__file__).resolve().parents[2] / "configs"


def resolved_config_dict(config: RootConfig) -> dict[str, object]:
    """Return the canonical experiment mapping used for identity and receipts.

    ``run_name`` is a filesystem label and commonly contains Hydra's current
    timestamp; including it would make an otherwise identical rerun look like
    a different experiment and would prevent checkpoint resume.
    """

    raw = config.model_dump(mode="json")
    raw.pop("run_name", None)
    return {str(key): value for key, value in raw.items()}


def config_hash(config: RootConfig) -> str:
    """Hash the fully validated configuration, not an unresolved YAML tree."""

    payload = json.dumps(
        resolved_config_dict(config), ensure_ascii=True, sort_keys=True, separators=(",", ":")
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def load_config(
    config_name: str = "config",
    *,
    config_dir: str | Path | None = None,
    overrides: Iterable[str] = (),
) -> RootConfig:
    """Compose a Hydra config and validate its resolved mapping exactly once."""

    directory = Path(config_dir) if config_dir is not None else _default_config_dir()
    directory = directory.resolve()
    name = config_name[:-5] if config_name.endswith(".yaml") else config_name
    with initialize_config_dir(version_base=None, config_dir=str(directory)):
        composed: DictConfig = compose(config_name=name, overrides=list(overrides))
    raw = OmegaConf.to_container(composed, resolve=True)
    if not isinstance(raw, dict):
        raise TypeError("resolved Hydra configuration must be a mapping")
    return validate_config(cast(dict[str, object], raw))


def validate_saved_config(raw: dict[str, Any], expected_hash: str) -> RootConfig:
    """Authenticate saved JSON before the two named inference default migrations.

    The historical digest stays the training identity. The returned configuration
    has its own effective hash; never substitute that hash into historical evidence.
    Only absent ``eval.symmetric_set_reranking`` and ``eval.pair_set_composition``
    may acquire false defaults. Any other missing field, coercion or changed value
    requires a separate migration.
    """
    historical = deepcopy(raw)
    historical.pop("run_name", None)
    payload = json.dumps(
        historical, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    )
    if hashlib.sha256(payload.encode("utf-8")).hexdigest() != expected_hash:
        raise ValueError("saved configuration hash does not match historical identity")
    expected = deepcopy(raw)
    evaluation = expected.get("eval")
    if not isinstance(evaluation, dict):
        raise ValueError("saved configuration must include its evaluation fields")
    evaluation.setdefault("symmetric_set_reranking", False)
    evaluation.setdefault("pair_set_composition", False)
    config = RootConfig.model_validate(expected)
    # Canonical JSON distinguishes false from 0 and integers from coerced strings.
    actual_json = json.dumps(config.model_dump(mode="json"), sort_keys=True, allow_nan=False)
    expected_json = json.dumps(expected, sort_keys=True, allow_nan=False)
    if actual_json != expected_json:
        raise ValueError("saved configuration requires an unsupported schema transformation")
    return config
