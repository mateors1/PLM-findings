"""PLM command-line interface (Typer).

Core graph, corpus, training/evaluation and native serving commands are available.
The separate Linux/vLLM serving adapter remains a deferred boundary.
"""

from __future__ import annotations

import json
import sys
from collections.abc import Iterator
from dataclasses import asdict
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from plm import __version__
from plm.baselines.complex import ComplExScorer
from plm.baselines.oracle import OracleScorer
from plm.baselines.popularity import PopularityScorer
from plm.configuration import config_hash, load_config
from plm.corpus import (
    ArtifactValidationError,
    CorpusRecord,
    compile_corpus,
    require_valid_artifacts,
)
from plm.corpus.snapshot import prepare_dataset_snapshot
from plm.evaluation import PLMScorer, evaluate_final_test, evaluate_validation
from plm.evaluation.generation import evaluate_generation
from plm.evaluation.ranking import Scorer, evaluate_ranking
from plm.evaluation.set_composition import evaluate_set_compositions
from plm.evaluation.split import split_queries
from plm.graph import init_graph, validate_graph
from plm.graph.importers import import_national_dex
from plm.protocol import Vocabulary, load_protocol
from plm.serving.generation import GenerationResult, generate_response
from plm.serving.generation_batch import generate_responses
from plm.serving.guidance import guidance_decoding_suffix
from plm.serving.set_composition import SetCompositionResult, generate_set_compositions

# Windows consoles frequently default to a legacy code page (e.g. cp1252) that
# cannot encode Rich's box-drawing/status glyphs. Force UTF-8 stdio so CLI
# output never crashes with UnicodeEncodeError.
if sys.platform == "win32":  # pragma: no cover
    for _stream in (sys.stdout, sys.stderr):
        _reconfigure = getattr(_stream, "reconfigure", None)
        if callable(_reconfigure):
            _reconfigure(encoding="utf-8")

app = typer.Typer(
    name="plm",
    help="Protocolized Language Model — CLI.",
    no_args_is_help=True,
    add_completion=False,
)
graph_app = typer.Typer(help="Product-graph operations.", no_args_is_help=True)
tokenizer_app = typer.Typer(help="Tokenizer / vocabulary operations.", no_args_is_help=True)
corpus_app = typer.Typer(help="Corpus compilation (Phase B).", no_args_is_help=True)
baseline_app = typer.Typer(help="Baseline recommenders (Phase B).", no_args_is_help=True)
label_app = typer.Typer(help="Local graph labeling and review UI.", no_args_is_help=True)
app.add_typer(graph_app, name="graph")
app.add_typer(tokenizer_app, name="tokenizer")
app.add_typer(corpus_app, name="corpus")
app.add_typer(baseline_app, name="baseline")
app.add_typer(label_app, name="label")

console = Console()


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"plm {__version__}")
        raise typer.Exit


@app.callback()
def main(
    _version: Annotated[
        bool,
        typer.Option("--version", callback=_version_callback, is_eager=True, help="Show version."),
    ] = False,
) -> None:
    """PLM root command."""


# --- graph ------------------------------------------------------------------
@graph_app.command("init")
def graph_init(
    database: Annotated[Path, typer.Option(help="SQLite database path.")],
    protocol_version: Annotated[str, typer.Option(help="Protocol version to stamp.")] = "0.0.0-dev",
) -> None:
    """Create the product-graph schema (idempotent)."""
    init_graph(database, protocol_version=protocol_version)
    console.print(f"[green]OK[/] initialized graph at [bold]{database}[/]")


@graph_app.command("validate")
def graph_validate(
    database: Annotated[Path, typer.Option(help="SQLite database path.")],
) -> None:
    """Validate integrity and report counts."""
    report = validate_graph(database)
    table = Table(title=f"graph: {database}")
    table.add_column("metric")
    table.add_column("value", justify="right")
    table.add_row("nodes", str(report.node_count))
    table.add_row("edges", str(report.edge_count))
    table.add_row("relation types", str(report.relation_type_count))
    table.add_row("schema version", str(report.schema_version))
    table.add_row("protocol version", report.protocol_version)
    console.print(table)
    if report.ok:
        console.print("[green]OK - no issues[/]")
    else:
        for issue in report.issues:
            console.print(f"[red]FAIL {issue}[/]")
        raise typer.Exit(code=1)


@graph_app.command("import-national-dex")
def graph_import_national_dex(
    database: Annotated[Path, typer.Option(help="SQLite database path.")],
    protocol_version: Annotated[
        str, typer.Option(help="Protocol version to stamp.")
    ] = "pokemon-v1",
) -> None:
    """Import the full National Dex with PokeAPI type/color facts."""
    products, edges = import_national_dex(database, protocol_version=protocol_version)
    console.print(f"[green]OK[/] imported {products} National Dex products and {edges} edges")


# --- tokenizer --------------------------------------------------------------
@graph_app.command("snapshot")
def graph_snapshot(
    name: Annotated[str, typer.Option(help="New immutable dataset version name.")],
    data_root: Annotated[Path, typer.Option(help="Root for dataset artifacts.")] = Path("data"),
    protocol_config: Annotated[Path, typer.Option(help="Versioned protocol YAML.")] = Path(
        "configs/protocol/pokemon_v1.yaml"
    ),
) -> None:
    """Prepare or verify a pinned graph/corpus snapshot and provenance receipt."""
    try:
        receipt = prepare_dataset_snapshot(data_root, name, protocol_path=protocol_config)
    except (OSError, ValueError) as exc:
        raise typer.BadParameter(str(exc)) from exc
    console.print(str(receipt))


@tokenizer_app.command("build")
def tokenizer_build(
    names: Annotated[Path, typer.Option(help="Newline-delimited product SKUs.")],
    out: Annotated[Path, typer.Option(help="Output vocabulary JSON path.")],
) -> None:
    """Build a direct token->ID vocabulary from a names file."""
    raw = names.read_text(encoding="utf-8").splitlines()
    tokens = [line.strip() for line in raw if line.strip()]
    vocab = Vocabulary.build(tokens)
    digest = vocab.save(out)
    console.print(
        f"[green]OK[/] wrote vocab ({len(vocab)} tokens) to [bold]{out}[/]\n"
        f"  hash: [dim]{digest}[/]"
    )


@corpus_app.command("compile")
def corpus_compile(
    database: Annotated[Path, typer.Option(help="SQLite graph database.")],
    protocol_config: Annotated[Path, typer.Option(help="Versioned protocol YAML.")],
    out: Annotated[Path, typer.Option(help="Output corpus directory.")],
) -> None:
    """Compile a graph into deterministic v1 protocol records."""
    manifest = compile_corpus(database, protocol=load_protocol(protocol_config), output_dir=out)
    console.print(
        f"[green]OK[/] wrote {manifest.record_count} records to [bold]{out}[/]\n"
        f"  records hash: [dim]{manifest.records_hash}[/]"
    )


# --- labeling ---------------------------------------------------------------
@label_app.command("serve")
def label_serve(
    database: Annotated[Path, typer.Option(help="SQLite graph database.")],
    host: Annotated[str, typer.Option(help="Host interface.")] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="TCP port.")] = 8010,
) -> None:
    """Run the local TYPE/COLOR graph-labeling web app."""
    try:
        import uvicorn
    except ModuleNotFoundError:
        console.print("[yellow]label serve requires[/] [bold]uv sync --group serving[/]")
        raise typer.Exit(code=2) from None
    from plm.labeling import create_labeling_app

    uvicorn.run(create_labeling_app(database), host=host, port=port)


def _load_corpus_records(path: Path) -> list[CorpusRecord]:
    records: list[CorpusRecord] = []
    for line_number, line in enumerate(
        (path / "records.jsonl").read_text(encoding="utf-8").splitlines(), 1
    ):
        try:
            raw = json.loads(line)
            records.append(
                CorpusRecord(
                    subject=str(raw["subject"]),
                    dimension=str(raw["dimension"]),
                    targets=tuple(str(item) for item in raw["targets"]),
                    input_ids=tuple(int(item) for item in raw["input_ids"]),
                    labels=tuple(int(item) for item in raw["labels"]),
                )
            )
        except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
            raise typer.BadParameter(f"invalid records.jsonl line {line_number}: {exc}") from exc
    if not records:
        raise typer.BadParameter("corpus records.jsonl must contain at least one record")
    return records


@baseline_app.command("evaluate")
def baseline_evaluate(
    corpus: Annotated[Path, typer.Option(help="Compiled corpus directory.")],
    baseline: Annotated[
        str, typer.Option(help="Baseline: oracle, popularity, or complex.")
    ] = "oracle",
    validation_fraction: Annotated[
        float | None, typer.Option("--validation-fraction", help="Validation query fraction.")
    ] = None,
    test_fraction: Annotated[
        float | None, typer.Option("--test-fraction", help="Final-test query fraction.")
    ] = None,
    held_out_fraction: Annotated[
        float | None,
        typer.Option("--held-out-fraction", help="Deprecated combined holdout fraction."),
    ] = None,
    seed: Annotated[int | None, typer.Option(help="Baseline initialization/sampling seed.")] = None,
    split_seed: Annotated[
        int | None, typer.Option(help="Independent query partition seed.")
    ] = None,
    graph_db: Annotated[
        Path | None, typer.Option(help="Optional graph DB for full identity validation.")
    ] = None,
    protocol_config: Annotated[
        Path | None, typer.Option(help="Optional protocol YAML for semantic validation.")
    ] = None,
    out: Annotated[Path | None, typer.Option(help="Optional JSON output path.")] = None,
    override: Annotated[
        list[str] | None, typer.Option(help="Hydra override; may be repeated.")
    ] = None,
) -> None:
    """Evaluate a baseline on a deterministic held-out query split."""
    if baseline not in {"oracle", "popularity", "complex"}:
        raise typer.BadParameter("baseline must be one of: oracle, popularity, complex")
    config = load_config(overrides=override or ())
    try:
        protocol = load_protocol(protocol_config) if protocol_config is not None else None
        artifact_report = require_valid_artifacts(corpus, graph_db=graph_db, protocol=protocol)
    except (ArtifactValidationError, OSError, ValueError) as exc:
        raise typer.BadParameter(f"invalid corpus artifacts: {exc}") from exc
    # ``require_valid_artifacts`` is fail-closed, so this is defensive only.
    if artifact_report.manifest is None:  # pragma: no cover
        raise typer.BadParameter("validated corpus has no manifest")
    records = _load_corpus_records(corpus)
    resolved_seed = config.seed if seed is None else seed
    resolved_split_seed = config.data.split_seed if split_seed is None else split_seed
    if held_out_fraction is not None:
        if validation_fraction is not None or test_fraction is not None:
            raise typer.BadParameter(
                "--held-out-fraction cannot be combined with explicit split fractions"
            )
        split = split_queries(records, held_out_fraction, resolved_split_seed)
        resolved_validation = held_out_fraction / 2.0
        resolved_test = held_out_fraction / 2.0
    else:
        resolved_validation = (
            config.data.validation_query_fraction
            if validation_fraction is None
            else validation_fraction
        )
        resolved_test = config.data.test_query_fraction if test_fraction is None else test_fraction
        split = split_queries(records, resolved_validation, resolved_test, resolved_split_seed)
    effective_config = config.model_copy(
        update={
            "seed": resolved_seed,
            "data": config.data.model_copy(
                update={
                    "corpus_manifest": str(corpus / "manifest.json"),
                    "graph_db": str(graph_db) if graph_db is not None else config.data.graph_db,
                    "validation_query_fraction": resolved_validation,
                    "test_query_fraction": resolved_test,
                    "split_seed": resolved_split_seed,
                }
            ),
        }
    )
    vocab = Vocabulary.load(corpus / "vocabulary.json")
    candidates = [vocab.token_of(token_id) for token_id in vocab.entity_ids()]
    scorer: Scorer
    if baseline == "oracle":
        scorer = OracleScorer(records)
    elif baseline == "popularity":
        scorer = PopularityScorer(split.train)
    elif baseline == "complex":
        complex_config = config.baseline.complex
        scorer = ComplExScorer(
            dimension=complex_config.dimension,
            epochs=complex_config.epochs,
            learning_rate=complex_config.learning_rate,
            negative_samples=complex_config.negative_samples,
            regularization=complex_config.regularization,
            batch_size=complex_config.batch_size,
            seed=resolved_seed,
        ).fit(split.train, candidates)
    metrics = evaluate_ranking(split.validation, candidates, scorer)
    from plm.experimentation.provenance import capture_runtime_provenance

    source_commit, environment = capture_runtime_provenance(
        source_archive=out.with_suffix(".source.zip") if out is not None else None
    )
    result = {
        "baseline": baseline,
        "config_hash": config_hash(effective_config),
        "baseline_config": config.baseline.model_dump(mode="json"),
        "source_commit": source_commit,
        "environment": environment,
        "evaluator_version": "baseline-fixed-split-v2",
        "protocol_version": artifact_report.manifest.protocol_version,
        "graph_hash": artifact_report.manifest.graph_hash,
        "records_hash": artifact_report.manifest.records_hash,
        "vocabulary_hash": artifact_report.manifest.tokenizer_hash,
        "validation_query_fraction": resolved_validation,
        "test_query_fraction": resolved_test,
        "seed": resolved_seed,
        "split_seed": resolved_split_seed,
        "split_hash": split.split_hash,
        "train_count": len(split.train),
        "validation_count": len(split.validation),
        "test_count": len(split.test),
        "evaluation_count": len(split.validation),
        "metrics": {"mrr": metrics.mrr, "hits_at": metrics.hits_at, "map": metrics.map},
    }
    payload = json.dumps(result, ensure_ascii=True, sort_keys=True, indent=2) + "\n"
    if out is not None:
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists():
            try:
                existing = out.read_text(encoding="utf-8")
            except OSError as exc:
                raise typer.BadParameter(f"cannot read existing report: {exc}") from exc
            if existing != payload:
                raise typer.BadParameter(f"refusing to overwrite immutable baseline report: {out}")
        else:
            out.write_text(payload, encoding="utf-8", newline="\n")
    console.print(payload, end="")


@app.command("train")
def train(
    config_name: Annotated[str, typer.Option(help="Config name under configs/.")] = "config",
    corpus: Annotated[Path | None, typer.Option(help="Compiled corpus directory override.")] = None,
    checkpoint: Annotated[Path | None, typer.Option(help="Final checkpoint output path.")] = None,
    resume: Annotated[Path | None, typer.Option(help="Checkpoint to resume from.")] = None,
    override: Annotated[
        list[str] | None, typer.Option(help="Hydra override; may be repeated.")
    ] = None,
) -> None:
    """Train the minimal reference PLM and write a provenance-bound checkpoint."""
    try:
        import torch  # noqa: F401
    except ImportError:
        console.print("[yellow]train requires[/] [bold]uv sync --group training[/]")
        raise typer.Exit(code=2) from None
    try:
        from plm.training.runner import run_training

        result = run_training(
            load_config(config_name, overrides=override or ()),
            corpus_dir=corpus,
            checkpoint_path=checkpoint,
            resume_checkpoint=resume,
        )
    except (ArtifactValidationError, OSError, ValueError, RuntimeError) as exc:
        console.print(f"[red]training failed:[/] {exc}")
        raise typer.Exit(code=1) from exc
    console.print(
        json.dumps(
            {
                "global_step": result.global_step,
                "train_loss": result.train_loss,
                "validation_loss": result.validation_loss,
                "checkpoint": None if result.checkpoint is None else str(result.checkpoint.path),
            },
            ensure_ascii=True,
            sort_keys=True,
            indent=2,
        )
    )


def _evaluate_checkpoint(
    *,
    config_name: str,
    checkpoint: Path,
    corpus: Path | None,
    split_name: str,
    graph_db: Path | None,
    protocol_config: Path | None,
    final_test: bool,
    overrides: list[str] | None = None,
) -> dict[str, object]:
    normalized_split = split_name.strip().lower()
    if normalized_split == "test" and not final_test:
        raise ValueError("test is protected; use `plm evaluate-final` for finalization")
    if normalized_split not in {"validation", "test"}:
        raise ValueError("split must be validation or test")
    from plm.experimentation.provenance import capture_runtime_provenance
    from plm.serving.runtime import load_inference_runtime

    config = load_config(config_name, overrides=overrides or ())
    runtime = load_inference_runtime(
        config,
        checkpoint,
        corpus=corpus,
        graph_db=graph_db,
        protocol=load_protocol(protocol_config) if protocol_config is not None else None,
    )
    model, vocabulary, split = runtime.model, runtime.vocabulary, runtime.split
    effective_config = runtime.config
    selected = split.test if normalized_split == "test" else split.validation
    corpus_identity, identity = runtime.corpus_identity, runtime.training_identity
    device = runtime.device
    source_commit, environment = capture_runtime_provenance()
    scorer = PLMScorer(model, vocabulary, device=device)
    evaluation = (
        evaluate_final_test(
            selected,
            [vocabulary.token_of(token_id) for token_id in vocabulary.entity_ids()],
            scorer,
        )
        if final_test
        else evaluate_validation(
            selected,
            [vocabulary.token_of(token_id) for token_id in vocabulary.entity_ids()],
            scorer,
        )
    )
    result = evaluation.to_dict()
    if config.eval.pair_set_composition:
        composed: list[SetCompositionResult] = []
        for start in range(0, len(selected), config.eval.generation_batch_size):
            records = selected[start : start + config.eval.generation_batch_size]
            composed.extend(
                generate_set_compositions(
                    model,
                    vocabulary,
                    [(record.subject, record.dimension) for record in records],
                    max_new_tokens=config.eval.max_new_tokens,
                    device=device,
                    first_target_guidance_alpha=config.eval.first_target_guidance_alpha,
                )
            )
        # Ranking's unknown protocol field is not a property of a composed set.
        result.pop("protocol_valid", None)
        result.update(
            {
                "set_generation": evaluate_set_compositions(
                    selected, composed, vocabulary
                ).to_dict(),
                "set_responses": [
                    {
                        "subject": record.subject,
                        "dimension": record.dimension,
                        "expected": list(record.targets),
                        "selected_set": list(vocabulary.decode(answer.selected_set_ids)),
                        **asdict(answer),
                    }
                    for record, answer in zip(selected, composed, strict=True)
                ],
                "checkpoint": str(checkpoint),
                "checkpoint_hash": runtime.checkpoint_hash,
                "split_hash": split.split_hash,
                "corpus_identity": corpus_identity,
                "training_identity": identity,
                "evaluation_config_hash": config_hash(effective_config),
                "evaluator_version": "plm-ranking-and-set-composition-v1",
                "evaluator_source_commit": source_commit,
                "evaluator_environment": environment,
                "set_policy": composed[0].policy,
                "pair_set_composition": True,
                "symmetric_set_reranking": True,
                "generation_batch_size": config.eval.generation_batch_size,
                "first_target_guidance_alpha": config.eval.first_target_guidance_alpha,
                "prevent_repeated_targets": config.eval.prevent_repeated_targets,
                "use_kv_cache": config.eval.use_kv_cache,
                "constrained_decoding": config.eval.constrained_decoding,
                "source_max_new_tokens": config.eval.max_new_tokens,
                "device": device,
            }
        )
        return result
    observations: list[dict[str, object]] = []
    batched_results: Iterator[GenerationResult] | None = None
    if config.eval.generation_batch_size > 1:
        generated: list[GenerationResult] = []
        for start in range(0, len(selected), config.eval.generation_batch_size):
            records = selected[start : start + config.eval.generation_batch_size]
            generated.extend(
                generate_responses(
                    model,
                    vocabulary,
                    [(record.subject, record.dimension) for record in records],
                    max_new_tokens=config.eval.max_new_tokens,
                    device=device,
                    prevent_repeated_targets=config.eval.prevent_repeated_targets,
                    first_target_guidance_alpha=config.eval.first_target_guidance_alpha,
                    symmetric_set_reranking=config.eval.symmetric_set_reranking,
                )
            )
        batched_results = iter(generated)

    def observe_response(record: CorpusRecord) -> GenerationResult:
        response = (
            next(batched_results)
            if batched_results is not None
            else generate_response(
                model,
                vocabulary,
                record.subject,
                record.dimension,
                max_new_tokens=config.eval.max_new_tokens,
                device=device,
                constrained=config.eval.constrained_decoding,
                use_cache=config.eval.use_kv_cache,
                prevent_repeated_targets=config.eval.prevent_repeated_targets,
                first_target_guidance_alpha=config.eval.first_target_guidance_alpha,
                symmetric_set_reranking=config.eval.symmetric_set_reranking,
            )
        )
        observations.append(
            {
                "subject": record.subject,
                "dimension": record.dimension,
                "expected": list(record.targets),
                "predicted": list(response.targets),
                "token_ids": list(response.token_ids),
                "terminated": response.terminated,
                "protocol_valid": response.protocol_valid,
                "error": response.error,
            }
        )
        return response

    generation = evaluate_generation(selected, observe_response)
    result["generation"] = generation.to_dict()
    result["responses"] = observations
    result["protocol_valid"] = generation.protocol_valid_rate == 1.0
    result.update(
        {
            "checkpoint": str(checkpoint),
            "checkpoint_hash": runtime.checkpoint_hash,
            "split_hash": split.split_hash,
            "corpus_identity": corpus_identity,
            "training_identity": identity,
            "evaluation_config_hash": config_hash(effective_config),
            "evaluator_version": "plm-ranking-and-generation-v2",
            "evaluator_source_commit": source_commit,
            "evaluator_environment": environment,
            "decoding": (
                "greedy-protocol-mask-v1"
                if config.eval.constrained_decoding
                else "greedy-unconstrained-v1"
            )
            + ("+unique-v1" if config.eval.prevent_repeated_targets else "")
            + ("+kv-v1" if config.eval.use_kv_cache else "")
            + (
                "+batch-v1"
                if config.eval.generation_batch_size > 1 or config.eval.symmetric_set_reranking
                else ""
            )
            + guidance_decoding_suffix(config.eval.first_target_guidance_alpha)
            + ("+first4-symmetric-set-logit-sum-v1" if config.eval.symmetric_set_reranking else ""),
            "prevent_repeated_targets": config.eval.prevent_repeated_targets,
            "generation_batch_size": config.eval.generation_batch_size,
            "first_target_guidance_alpha": config.eval.first_target_guidance_alpha,
            "symmetric_set_reranking": config.eval.symmetric_set_reranking,
            "use_kv_cache": config.eval.use_kv_cache,
            "constrained_decoding": config.eval.constrained_decoding,
            "max_new_tokens": config.eval.max_new_tokens,
            "device": device,
        }
    )
    return result


@app.command("evaluate")
def evaluate(
    checkpoint: Annotated[Path, typer.Option(help="Checkpoint path.")],
    corpus: Annotated[Path | None, typer.Option(help="Compiled corpus directory override.")] = None,
    config_name: Annotated[str, typer.Option(help="Config name under configs/.")] = "config",
    split: Annotated[str, typer.Option(help="Adaptive split: validation only.")] = "validation",
    graph_db: Annotated[Path | None, typer.Option(help="Optional graph DB identity check.")] = None,
    protocol_config: Annotated[
        Path | None, typer.Option(help="Optional protocol YAML check.")
    ] = None,
    override: Annotated[
        list[str] | None, typer.Option(help="Hydra override; may be repeated.")
    ] = None,
    out: Annotated[Path | None, typer.Option(help="Immutable JSON report path.")] = None,
) -> None:
    """Evaluate a trained checkpoint on validation (never final test)."""
    try:
        result = _evaluate_checkpoint(
            config_name=config_name,
            checkpoint=checkpoint,
            corpus=corpus,
            split_name=split,
            graph_db=graph_db,
            protocol_config=protocol_config,
            final_test=False,
            overrides=override,
        )
    except ImportError as exc:
        console.print(f"[yellow]{exc}[/]")
        raise typer.Exit(code=2) from exc
    except (ArtifactValidationError, OSError, ValueError, RuntimeError) as exc:
        console.print(f"[red]evaluation failed:[/] {exc}")
        raise typer.Exit(code=1) from exc
    _write_evaluation_report(result, out)


@app.command("evaluate-final")
def evaluate_final(
    checkpoint: Annotated[Path, typer.Option(help="Checkpoint path.")],
    corpus: Annotated[Path | None, typer.Option(help="Compiled corpus directory override.")] = None,
    config_name: Annotated[str, typer.Option(help="Config name under configs/.")] = "config",
    graph_db: Annotated[Path | None, typer.Option(help="Graph DB identity check.")] = None,
    protocol_config: Annotated[
        Path | None, typer.Option(help="Protocol YAML identity check.")
    ] = None,
    override: Annotated[
        list[str] | None, typer.Option(help="Hydra override; may be repeated.")
    ] = None,
    out: Annotated[Path | None, typer.Option(help="Immutable JSON report path.")] = None,
) -> None:
    """Explicitly finalize a selected checkpoint against the protected test split."""
    try:
        result = _evaluate_checkpoint(
            config_name=config_name,
            checkpoint=checkpoint,
            corpus=corpus,
            split_name="test",
            graph_db=graph_db,
            protocol_config=protocol_config,
            final_test=True,
            overrides=override,
        )
    except ImportError as exc:
        console.print(f"[yellow]{exc}[/]")
        raise typer.Exit(code=2) from exc
    except (ArtifactValidationError, OSError, ValueError, RuntimeError) as exc:
        console.print(f"[red]final evaluation failed:[/] {exc}")
        raise typer.Exit(code=1) from exc
    _write_evaluation_report(result, out)


def _write_evaluation_report(result: dict[str, object], out: Path | None) -> None:
    payload = json.dumps(result, ensure_ascii=True, sort_keys=True, indent=2) + "\n"
    if out is not None:
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists():
            if out.read_text(encoding="utf-8") != payload:
                raise typer.BadParameter(
                    f"refusing to overwrite a different evaluation report: {out}"
                )
        else:
            with out.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(payload)
    console.print(payload, end="")


@app.command("serve")
def serve(
    checkpoint: Annotated[Path, typer.Option(help="Validated native model checkpoint.")],
    config_name: Annotated[str, typer.Option(help="Config name under configs/.")] = "config",
    corpus: Annotated[Path | None, typer.Option(help="Compiled corpus directory override.")] = None,
    graph_db: Annotated[Path | None, typer.Option(help="Source graph to snapshot.")] = None,
    override: Annotated[list[str] | None, typer.Option(help="Repeatable Hydra override.")] = None,
    runtime_dir: Annotated[
        Path, typer.Option(help="Dedicated snapshots and deployment receipts.")
    ] = Path("runs/serving"),
    host: Annotated[
        str, typer.Option(help="Bind address; defaults to this computer only.")
    ] = "127.0.0.1",
    port: Annotated[int, typer.Option(min=1, max=65535)] = 8000,
    max_pending: Annotated[
        int, typer.Option(min=1, help="Maximum running plus queued requests.")
    ] = 8,
) -> None:
    """Run the cross-platform native reference API against a dedicated snapshot."""
    try:
        import uvicorn

        from plm.serving.native import NativePredictor
        from plm.serving.web import create_serving_app

        predictor = NativePredictor.from_checkpoint(
            load_config(config_name, overrides=override or ()),
            checkpoint,
            runtime_dir=runtime_dir,
            corpus=corpus,
            graph_db=graph_db,
            max_pending=max_pending,
        )
        application = create_serving_app(predictor)
    except ImportError as exc:
        console.print("[red]serve requires `uv sync --group training --group serving`[/]")
        raise typer.Exit(code=2) from exc
    except (OSError, ValueError, RuntimeError) as exc:
        console.print(f"[red]serving initialization failed:[/] {exc}")
        raise typer.Exit(code=1) from exc
    console.print(f"Native snapshot: {predictor.snapshot}")
    uvicorn.run(application, host=host, port=port, workers=1)


if __name__ == "__main__":
    app()
