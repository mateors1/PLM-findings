"""One validated checkpoint-loading boundary for evaluation and native serving."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from plm.config import EvalConfig, ModelConfig, RootConfig
from plm.corpus import load_corpus_records, require_valid_artifacts
from plm.evaluation.split import QuerySplit, split_queries
from plm.protocol import Vocabulary
from plm.protocol.config import ProtocolSpec

__all__ = ["InferenceRuntime", "load_inference_runtime"]


@dataclass(frozen=True)
class InferenceRuntime:
    model: Any
    vocabulary: Vocabulary
    config: RootConfig
    split: QuerySplit
    checkpoint_hash: str
    training_identity: dict[str, Any]
    corpus_identity: dict[str, str]
    device: str


def load_inference_runtime(
    config: RootConfig,
    checkpoint: str | Path,
    *,
    corpus: str | Path | None = None,
    graph_db: str | Path | None = None,
    protocol: ProtocolSpec | None = None,
) -> InferenceRuntime:
    """Load once, rejecting wrong data, model config, objective or checkpoint metadata."""
    import torch

    from plm.model import build_model
    from plm.training.checkpoint import load_checkpoint, validate_checkpoint_identity

    EvalConfig.model_validate(config.eval.model_dump())
    if (
        config.eval.first_target_guidance_alpha > 0
        and config.model.symmetric_relation_loss_weight <= 0
    ):
        raise ValueError("first-target guidance requires a trained symmetric relation head")

    if config.eval.symmetric_set_reranking and config.model.symmetric_relation_loss_weight <= 0:
        raise ValueError("symmetric set reranking requires a trained symmetric relation head")

    if corpus is None and config.data.corpus_manifest is None:
        raise ValueError("data.corpus_manifest is required for inference")
    corpus_dir = (
        Path(corpus) if corpus is not None else Path(str(config.data.corpus_manifest)).parent
    )
    graph_path = Path(graph_db) if graph_db is not None else Path(config.data.graph_db)
    report = require_valid_artifacts(corpus_dir, graph_db=graph_path, protocol=protocol)
    if report.manifest is None:
        raise ValueError("validated corpus has no manifest")
    split = split_queries(
        load_corpus_records(corpus_dir),
        config.data.validation_query_fraction,
        config.data.test_query_fraction,
        config.data.split_seed,
    )
    vocabulary = Vocabulary.load(corpus_dir / "vocabulary.json")
    model_config = config.model.model_copy(
        update={"vocab_size": len(vocabulary), "max_seq_len": config.train.seq_len}
    )
    model = build_model(model_config)
    state = load_checkpoint(checkpoint, model, map_location="cpu", restore_rng=False)
    if config.eval.symmetric_set_reranking and state.global_step == 0:
        raise ValueError("symmetric set reranking requires a checkpoint with training steps")
    validate_checkpoint_identity(state, split_hash=split.split_hash)
    corpus_identity = {
        "graph_hash": report.manifest.graph_hash,
        "records_hash": report.manifest.records_hash,
        "vocabulary_hash": report.manifest.tokenizer_hash,
    }
    if state.metadata.get("corpus_identity") != corpus_identity:
        raise ValueError("checkpoint corpus identity does not match evaluation artifacts")
    metadata = state.metadata.get("training_metadata")
    if not isinstance(metadata, dict) or metadata.get("objective") != "causal-next-token-v1":
        raise ValueError("checkpoint lacks the corrected next-token objective contract")
    if ModelConfig.model_validate(metadata.get("model_config")) != model_config:
        raise ValueError("checkpoint model configuration does not match evaluation configuration")
    identity = state.metadata.get("experiment_identity")
    if not isinstance(identity, dict) or identity.get("evaluator_version") != "plm-train-causal-v2":
        raise ValueError("checkpoint lacks current training provenance")
    if identity.get("split_hash") != split.split_hash or any(
        identity.get(key) != value for key, value in corpus_identity.items()
    ):
        raise ValueError("checkpoint training identity differs from its data metadata")
    device = config.eval.device
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device).eval()
    return InferenceRuntime(
        model,
        vocabulary,
        config.model_copy(update={"model": model_config}),
        split,
        state.checkpoint_hash,
        identity,
        corpus_identity,
        device,
    )
