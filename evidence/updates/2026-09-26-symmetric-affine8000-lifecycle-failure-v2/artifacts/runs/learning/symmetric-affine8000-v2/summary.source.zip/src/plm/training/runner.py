"""High-level Phase-C training entry point used by the CLI."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from plm.config import RootConfig
from plm.configuration import config_hash
from plm.corpus import load_corpus_records, require_valid_artifacts
from plm.evaluation.split import split_queries
from plm.experimentation.identity import ExperimentIdentity
from plm.experimentation.provenance import capture_runtime_provenance
from plm.protocol.tokenizer import Vocabulary
from plm.reproducibility import seed_everything
from plm.training.trainer import Trainer, TrainResult

__all__ = ["run_training"]


def _corpus_dir(config: RootConfig, override: str | Path | None) -> Path:
    if override is not None:
        return Path(override)
    if config.data.corpus_manifest is None:
        raise ValueError("data.corpus_manifest is required for training")
    return Path(config.data.corpus_manifest).parent


def run_training(
    config: RootConfig,
    *,
    corpus_dir: str | Path | None = None,
    checkpoint_path: str | Path | None = None,
    resume_checkpoint: str | Path | None = None,
) -> TrainResult:
    """Validate corpus identity, build the reference model, and train it."""

    from plm.model.architecture import build_model

    # Model initialization must observe the committed run seed; seeding only
    # inside Trainer would be too late because the model already exists here.
    seed_everything(config.seed, deterministic=config.deterministic)
    corpus = _corpus_dir(config, corpus_dir)
    report = require_valid_artifacts(corpus, graph_db=config.data.graph_db)
    if report.manifest is None:
        raise ValueError("validated corpus has no manifest")
    records = load_corpus_records(corpus)
    split = split_queries(
        records,
        config.data.validation_query_fraction,
        config.data.test_query_fraction,
        config.data.split_seed,
    )
    vocabulary = Vocabulary.load(corpus / "vocabulary.json")
    model_config = config.model.model_copy(
        update={"vocab_size": len(vocabulary), "max_seq_len": config.train.seq_len}
    )
    model: Any = build_model(model_config)
    effective_config = config.model_copy(
        update={
            "model": model_config,
            "data": config.data.model_copy(
                update={"corpus_manifest": str(corpus / "manifest.json")}
            ),
        }
    )
    run_dir = Path(config.paths.run_root) / config.run_name
    final_checkpoint = (
        Path(checkpoint_path) if checkpoint_path is not None else run_dir / "checkpoint-final.pt"
    )
    if (run_dir / "training-result.json").exists() or final_checkpoint.exists():
        raise FileExistsError("completed run already exists; choose a new run name/checkpoint")
    if (run_dir / "metrics.jsonl").exists() and resume_checkpoint is None:
        raise FileExistsError("run has training progress; resume explicitly or choose a new name")
    revision, environment = capture_runtime_provenance(source_archive=run_dir / "source.zip")
    identity = ExperimentIdentity(
        source_commit=revision,
        resolved_config_hash=config_hash(effective_config),
        protocol_version=report.manifest.protocol_version,
        graph_hash=report.manifest.graph_hash,
        records_hash=report.manifest.records_hash,
        vocabulary_hash=report.manifest.tokenizer_hash,
        split_hash=split.split_hash,
        evaluator_version="plm-train-causal-v2",
        environment=environment,
        seeds=(config.seed,),
    )
    run_dir.mkdir(parents=True, exist_ok=True)
    run_manifest = run_dir / "run.json"
    payload = (
        json.dumps(
            {"config": effective_config.model_dump(mode="json"), "identity": identity.to_dict()},
            sort_keys=True,
            indent=2,
        )
        + "\n"
    )
    if run_manifest.exists():
        if run_manifest.read_text(encoding="utf-8") != payload:
            raise ValueError("run directory already contains a different experiment identity")
    else:
        with run_manifest.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(payload)
    trainer = Trainer(
        model,
        split.train,
        config=config.train,
        seed=config.seed,
        pad_id=vocabulary.pad_id,
        validation_records=split.validation,
        run_dir=run_dir,
        identity=identity,
        corpus_identity={
            "graph_hash": report.manifest.graph_hash,
            "records_hash": report.manifest.records_hash,
            "vocabulary_hash": report.manifest.tokenizer_hash,
        },
        split_hash=split.split_hash,
        deterministic=config.deterministic,
    )
    started = time.perf_counter()
    result = trainer.train(checkpoint_path=final_checkpoint, resume_checkpoint=resume_checkpoint)
    summary = {
        "global_step": result.global_step,
        "training_wall_seconds": time.perf_counter() - started,
        "train_loss": result.train_loss,
        "validation_loss": result.validation_loss,
        "history": result.history,
        "checkpoint": str(final_checkpoint),
        "checkpoint_hash": result.checkpoint.checkpoint_hash if result.checkpoint else None,
        "identity": identity.to_dict(),
    }
    (run_dir / "training-result.json").write_text(
        json.dumps(summary, sort_keys=True, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    return result
