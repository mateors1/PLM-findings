"""Structured metrics and profiling (latency, RPS, tokens/sec, GPU mem/util/watts).

Wraps ``pynvml``/``psutil`` and Prometheus counters for the benchmark reports in
``docs/benchmarks.md``.
"""

from __future__ import annotations

__all__: list[str] = []
