"""Shared multi-positive ranking metrics and scorer protocol."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from plm.corpus.compiler import CorpusRecord

__all__ = ["RankingMetrics", "Scorer", "evaluate_ranking"]


@runtime_checkable
class Scorer(Protocol):
    """Return a score for one candidate under a query."""

    def score(self, query: CorpusRecord, candidate: str) -> float: ...


@dataclass(frozen=True)
class RankingMetrics:
    mrr: float
    hits_at: dict[int, float]
    map: float

    @property
    def map_score(self) -> float:
        return self.map


def _score(
    scorer: Scorer | Mapping[str, float] | Callable[[CorpusRecord, str], float],
    query: CorpusRecord,
    candidate: str,
) -> float:
    if isinstance(scorer, Mapping):
        return float(scorer[candidate])
    if callable(scorer) and not hasattr(scorer, "score"):
        return float(scorer(query, candidate))
    assert hasattr(scorer, "score")
    return float(scorer.score(query, candidate))


def evaluate_ranking(
    records: Iterable[CorpusRecord],
    candidates: Sequence[str],
    scorer: Scorer | Mapping[str, float] | Callable[[CorpusRecord, str], float],
    *,
    ks: Sequence[int] = (1, 3, 10),
) -> RankingMetrics:
    """Evaluate macro MRR, Hits@K and MAP over complete positive sets."""
    queries = list(records)
    if not queries:
        raise ValueError("cannot evaluate an empty prediction set")
    if not candidates:
        raise ValueError("candidate vocabulary must not be empty")
    unique_ks = tuple(dict.fromkeys(int(k) for k in ks))
    if any(k <= 0 for k in unique_ks):
        raise ValueError("Hits@K values must be positive")
    candidate_keys = tuple(dict.fromkeys(str(c) for c in candidates))
    reciprocal = 0.0
    average_precision = 0.0
    hits = dict.fromkeys(unique_ks, 0.0)
    for query in queries:
        positives = set(query.targets)
        if not positives:
            raise ValueError("query has no positive targets")
        ranked = sorted(candidate_keys, key=lambda key: (-_score(scorer, query, key), key))
        ranks = [i for i, key in enumerate(ranked, 1) if key in positives]
        if not ranks:
            raise ValueError("no query positive appears in candidate vocabulary")
        reciprocal += 1.0 / ranks[0]
        for k in unique_ks:
            hits[k] += float(any(rank <= k for rank in ranks))
        precisions = [sum(rank <= r for rank in ranks[:i]) / r for i, r in enumerate(ranks, 1)]
        average_precision += sum(precisions) / len(positives)
    n = float(len(queries))
    return RankingMetrics(
        mrr=reciprocal / n, hits_at={k: v / n for k, v in hits.items()}, map=average_precision / n
    )
