"""Config-driven optimizer and scheduler factories."""

from __future__ import annotations

import math
from typing import Any

from plm.config import OptimizerConfig, SchedulerConfig

__all__ = ["create_optimizer", "create_scheduler"]


def create_optimizer(model: Any, config: OptimizerConfig) -> Any:
    """Create an optimizer without hiding decay or fused-kernel choices."""

    import torch

    if config.lr <= 0.0:
        raise ValueError("optimizer learning rate must be positive")
    if config.weight_decay < 0.0:
        raise ValueError("optimizer weight_decay must be non-negative")
    if not 0.0 <= config.betas[0] < 1.0 or not 0.0 <= config.betas[1] < 1.0:
        raise ValueError("optimizer betas must be in [0, 1)")
    if config.eps <= 0.0:
        raise ValueError("optimizer eps must be positive")

    decay: list[Any] = []
    no_decay: list[Any] = []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if config.decay_excludes_norm_and_bias and (
            name.endswith("bias") or "norm" in name.lower() or "embedding" in name.lower()
        ):
            no_decay.append(parameter)
        else:
            decay.append(parameter)
    if not decay and not no_decay:
        raise ValueError("model has no trainable parameters")
    groups: list[dict[str, Any]] = [
        {"params": decay, "weight_decay": config.weight_decay},
        {"params": no_decay, "weight_decay": 0.0},
    ]
    if config.name == "lion":
        raise NotImplementedError("Lion is a research hypothesis, not in the reference trainer")
    fused = config.name == "adamw_fused" and torch.cuda.is_available()
    kwargs: dict[str, Any] = {
        "lr": config.lr,
        "betas": config.betas,
        "eps": config.eps,
    }
    if fused:
        kwargs["fused"] = True
    try:
        return torch.optim.AdamW(groups, **kwargs)
    except (TypeError, RuntimeError):
        if not fused:
            raise
        kwargs.pop("fused", None)
        return torch.optim.AdamW(groups, **kwargs)


def create_scheduler(optimizer: Any, config: SchedulerConfig, *, total_steps: int) -> Any:
    """Create a deterministic warmup/decay schedule from committed config."""

    import torch

    if total_steps < 1:
        raise ValueError("total_steps must be positive")
    if config.warmup_steps < 0:
        raise ValueError("scheduler warmup_steps must be non-negative")
    if not 0.0 <= config.min_lr_ratio <= 1.0:
        raise ValueError("scheduler min_lr_ratio must be in [0, 1]")
    if config.name not in {"constant", "linear", "cosine", "wsd"}:
        raise ValueError(f"unsupported scheduler: {config.name}")
    warmup = min(config.warmup_steps, total_steps)

    def multiplier(step: int) -> float:
        if step < warmup:
            return max(step, 1) / max(warmup, 1)
        progress = (step - warmup) / max(total_steps - warmup, 1)
        progress = min(max(progress, 0.0), 1.0)
        if config.name == "constant":
            return 1.0
        if config.name == "linear" or config.name == "wsd":
            return 1.0 - progress * (1.0 - config.min_lr_ratio)
        if config.name == "cosine":
            return (
                config.min_lr_ratio
                + (1.0 - config.min_lr_ratio) * (1.0 + math.cos(progress * math.pi)) / 2.0
            )
        raise AssertionError("scheduler name was validated before construction")

    return torch.optim.lr_scheduler.LambdaLR(optimizer, multiplier)
