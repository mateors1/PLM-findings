"""Tiny overfit gate for the minimal reference decoder."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from plm.config import ModelConfig

__all__ = ["SyntheticOverfitReport", "run_synthetic_overfit"]


@dataclass(frozen=True)
class SyntheticOverfitReport:
    initial_loss: float
    final_loss: float
    steps: int
    threshold: float
    generated_ids: tuple[int, ...]
    expected_ids: tuple[int, ...]

    @property
    def passed(self) -> bool:
        return self.final_loss <= self.threshold and self.generated_ids == self.expected_ids


def run_synthetic_overfit(
    config: ModelConfig,
    *,
    steps: int = 200,
    learning_rate: float = 1.0e-2,
    threshold: float = 0.05,
    seed: int = 1729,
) -> SyntheticOverfitReport:
    """Overfit a toy sequence, then generate its completion from the prompt.

    IDs 1..5 stand in for the five protocol prompt tokens, 6 for a target,
    and 7 for EOS. This is a mechanics gate, not a graph-learning result.
    With prompt-set supervision, the fixture uses real banded product IDs and
    protocol specials so control tokens cannot masquerade as set members.
    """

    import torch

    from plm.model.architecture import build_model

    if steps < 1:
        raise ValueError("synthetic overfit steps must be positive")
    if config.vocab_size < 8 or config.max_seq_len < 7:
        raise ValueError("synthetic overfit requires vocab_size >= 8 and max_seq_len >= 7")
    torch.manual_seed(seed)
    model: Any = build_model(config)
    model.train()
    fixture = [1, 2, 3, 4, 5, 6, 7]
    if config.prompt_set_loss_weight or config.symmetric_relation_loss_weight:
        from plm.protocol import Vocabulary

        products = (
            ["PKM_A", "PKM_B", "PKM_C"]
            if config.symmetric_relation_loss_weight
            else ["PKM_A", "PKM_B"]
        )
        vocabulary = Vocabulary.build(products)
        if config.vocab_size < len(vocabulary):
            raise ValueError("prompt-set overfit requires at least two product tokens")
        fixture = vocabulary.encode(["BOS", "PKM_A", "TYPE", "SAME", "ANSWER", "PKM_B", "EOS"])
    expected_ids = tuple(fixture[5:])
    input_ids = torch.tensor([fixture], dtype=torch.long)
    labels = input_ids.clone()
    labels[:, :5] = -100
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate)
    initial_loss: float | None = None
    final_loss = float("inf")
    for _ in range(steps):
        output = model(input_ids, labels=labels)
        if output.loss is None:
            raise RuntimeError("reference decoder did not return a loss")
        if initial_loss is None:
            initial_loss = float(output.loss.detach().cpu())
        optimizer.zero_grad(set_to_none=True)
        output.loss.backward()
        optimizer.step()
        final_loss = float(output.loss.detach().cpu())
    if initial_loss is None:
        raise RuntimeError("synthetic overfit did not execute")
    model.eval()
    generated: list[int] = []
    prefix = input_ids[:, :5]
    with torch.no_grad():
        # Measure the final weights, after the last optimizer update.
        final_loss = float(model(input_ids, labels=labels).loss)
        for _ in range(2):
            token = model(prefix).logits[:, -1].argmax(dim=-1, keepdim=True)
            generated.append(int(token.item()))
            prefix = torch.cat((prefix, token), dim=1)
    return SyntheticOverfitReport(
        initial_loss, final_loss, steps, threshold, tuple(generated), expected_ids
    )
