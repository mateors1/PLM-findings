"""Deterministic query-level train/validation/test splits."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Iterable
from dataclasses import dataclass
from numbers import Real

from plm.corpus.compiler import CorpusRecord

__all__ = ["QuerySplit", "split_queries"]


@dataclass(frozen=True)
class QuerySplit:
    """An immutable partition of complete corpus queries.

    Records retain compiler order within each partition.  ``split_hash``
    identifies the ordered train/validation/test assignment independently of
    object identity or process-randomized Python hashing.
    """

    train: tuple[CorpusRecord, ...]
    validation: tuple[CorpusRecord, ...]
    test: tuple[CorpusRecord, ...]
    split_hash: str

    @property
    def train_records(self) -> tuple[CorpusRecord, ...]:
        """Compatibility spelling for the training partition."""

        return self.train

    @property
    def validation_records(self) -> tuple[CorpusRecord, ...]:
        """Compatibility spelling for the validation partition."""

        return self.validation

    @property
    def test_records(self) -> tuple[CorpusRecord, ...]:
        """Compatibility spelling for the test partition."""

        return self.test

    @property
    def evaluation(self) -> tuple[CorpusRecord, ...]:
        """Compatibility spelling for the final evaluation/test partition."""

        return self.test

    @property
    def eval_records(self) -> tuple[CorpusRecord, ...]:
        """Compatibility spelling for the final evaluation/test partition."""

        return self.test


def _normalized_digest(seed: int, record: CorpusRecord) -> float:
    key = f"{seed}:{record.subject}:{record.dimension}".encode()
    digest = hashlib.sha256(key).digest()
    return int.from_bytes(digest, "big") / float(1 << 256)


def _validated_fraction(value: object, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite number in [0, 1)")
    fraction = float(value)
    if not math.isfinite(fraction) or not 0.0 <= fraction < 1.0:
        raise ValueError(f"{name} must be a finite number in [0, 1)")
    return fraction


def _assignment_hash(
    train: tuple[CorpusRecord, ...],
    validation: tuple[CorpusRecord, ...],
    test: tuple[CorpusRecord, ...],
    *,
    seed: int,
    validation_fraction: float,
    test_fraction: float,
) -> str:
    """Hash split metadata and all three ordered query assignments."""

    payload = {
        "algorithm": "sha256-threshold-v2",
        "seed": seed,
        "validation_fraction": validation_fraction,
        "test_fraction": test_fraction,
        "train": [[record.subject, record.dimension] for record in train],
        "validation": [[record.subject, record.dimension] for record in validation],
        "test": [[record.subject, record.dimension] for record in test],
    }
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _rebalance_legacy_partitions(
    records: tuple[CorpusRecord, ...],
    partitions: dict[str, list[int]],
    seed: int,
) -> None:
    """Give legacy callers a valid three-way result for tiny corpora.

    The old API had only one held-out side.  Its compatibility adapter can
    otherwise put every query in train when the corpus is small.  Rebalancing
    moves complete query-key groups selected by the same SHA-256 digest and
    keeps the source partition non-empty; the strict new API never uses this
    path.
    """

    for target_name in ("validation", "test"):
        if partitions[target_name]:
            continue

        donor_names = sorted(
            (name for name, indices in partitions.items() if name != target_name),
            key=lambda name: (-len(partitions[name]), name),
        )
        for donor_name in donor_names:
            donor = partitions[donor_name]
            groups: dict[tuple[str, str], list[int]] = {}
            for index in donor:
                record = records[index]
                groups.setdefault((record.subject, record.dimension), []).append(index)
            eligible = [
                (key, indices) for key, indices in groups.items() if len(donor) > len(indices)
            ]
            if not eligible:
                continue
            _, moved = min(
                eligible,
                key=lambda item: (
                    _normalized_digest(seed, records[item[1][0]]),
                    item[1][0],
                ),
            )
            moved_set = set(moved)
            donor[:] = [index for index in donor if index not in moved_set]
            partitions[target_name].extend(moved)
            break


def split_queries(
    records: Iterable[CorpusRecord],
    validation_query_fraction: float | None = None,
    test_query_fraction: float | int | None = None,
    seed: int | None = None,
    *,
    validation_fraction: float | None = None,
    test_fraction: float | int | None = None,
    held_out_fraction: float | None = None,
    held_out_query_fraction: float | None = None,
) -> QuerySplit:
    """Partition complete ``(subject, dimension)`` queries deterministically.

    The SHA-256 digest of ``f"{seed}:{subject}:{dimension}"`` is normalized to
    ``[0, 1)``.  Values below ``validation_query_fraction`` go to validation,
    values below the sum of the two fractions go to test, and the remainder
    goes to train.  The graph and each record's complete target tuple are
    untouched.

    The shorter ``validation_fraction``/``test_fraction`` spellings are
    accepted as aliases.  ``held_out_fraction``,
    ``held_out_query_fraction``, and the legacy three-argument positional form
    are accepted only as compatibility adapters.  They divide the old
    held-out fraction equally between validation and test; the returned object
    still has three non-empty partitions and the final evaluation alias is
    ``test``.
    """

    if validation_fraction is not None:
        if validation_query_fraction is not None:
            raise ValueError("validation fractions cannot be specified twice")
        validation_query_fraction = validation_fraction
    if test_fraction is not None:
        if test_query_fraction is not None:
            raise ValueError("test fractions cannot be specified twice")
        test_query_fraction = test_fraction

    if held_out_fraction is not None and held_out_query_fraction is not None:
        raise ValueError("held-out fractions cannot be specified twice")
    held_out = held_out_fraction
    held_out_name = "held_out_fraction"
    if held_out_query_fraction is not None:
        held_out = held_out_query_fraction
        held_out_name = "held_out_query_fraction"

    legacy = held_out is not None
    if held_out is not None:
        if validation_query_fraction is not None or test_query_fraction is not None:
            raise ValueError("held-out fractions cannot be combined with split fractions")
        if seed is None:
            raise ValueError("seed is required")
        old_fraction = _validated_fraction(held_out, held_out_name)
        validation_query_fraction = old_fraction / 2.0
        test_query_fraction = old_fraction / 2.0
    elif (
        seed is None
        and isinstance(test_query_fraction, int)
        and not isinstance(test_query_fraction, bool)
    ):
        # Existing callers used split_queries(records, held_out_fraction, seed).
        if validation_query_fraction is None:
            raise ValueError("held_out_fraction is required")
        old_fraction = _validated_fraction(validation_query_fraction, "held_out_fraction")
        seed = test_query_fraction
        validation_query_fraction = old_fraction / 2.0
        test_query_fraction = old_fraction / 2.0
        legacy = True
    elif test_query_fraction is None and seed is not None:
        # Also accept the old keyword spelling with a positional fraction.
        if validation_query_fraction is None:
            raise ValueError("held_out_fraction is required")
        old_fraction = _validated_fraction(validation_query_fraction, "held_out_fraction")
        validation_query_fraction = old_fraction / 2.0
        test_query_fraction = old_fraction / 2.0
        legacy = True

    if validation_query_fraction is None or test_query_fraction is None or seed is None:
        raise ValueError("validation_query_fraction, test_query_fraction, and seed are required")
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError("seed must be an integer")

    validation_name = held_out_name if legacy else "validation_query_fraction"
    validated_validation = _validated_fraction(validation_query_fraction, validation_name)
    validated_test = _validated_fraction(test_query_fraction, "test_query_fraction")
    if validated_validation + validated_test >= 1.0:
        raise ValueError("validation_query_fraction + test_query_fraction must be less than 1")

    record_list = tuple(records)
    train_indices: list[int] = []
    validation_indices: list[int] = []
    test_indices: list[int] = []
    test_threshold = validated_validation + validated_test
    for index, record in enumerate(record_list):
        digest = _normalized_digest(seed, record)
        if digest < validated_validation:
            validation_indices.append(index)
        elif digest < test_threshold:
            test_indices.append(index)
        else:
            train_indices.append(index)

    partitions = {
        "train": train_indices,
        "validation": validation_indices,
        "test": test_indices,
    }
    if legacy and validated_validation > 0.0 and validated_test > 0.0:
        _rebalance_legacy_partitions(record_list, partitions, seed)

    train = [record_list[index] for index in sorted(train_indices)]
    validation = [record_list[index] for index in sorted(validation_indices)]
    test = [record_list[index] for index in sorted(test_indices)]

    if not train or not validation or not test:
        raise ValueError(
            "query split must produce non-empty train, validation, and test partitions"
        )

    train_tuple = tuple(train)
    validation_tuple = tuple(validation)
    test_tuple = tuple(test)
    return QuerySplit(
        train_tuple,
        validation_tuple,
        test_tuple,
        _assignment_hash(
            train_tuple,
            validation_tuple,
            test_tuple,
            seed=seed,
            validation_fraction=validated_validation,
            test_fraction=validated_test,
        ),
    )


# Explicit alias for callers that describe this operation as a corpus split.
split_corpus = split_queries
