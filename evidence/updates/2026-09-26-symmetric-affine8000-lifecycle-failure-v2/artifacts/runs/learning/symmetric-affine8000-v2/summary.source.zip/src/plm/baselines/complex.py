"""Optional, lazily imported Torch ComplEx scorer.

This is a defensible knowledge-graph ranking baseline, not a quality claim: it
uses deterministic object-corruption negatives, mini-batched logistic loss, and
explicit L2 regularization while keeping Torch outside the core import path.
"""

from __future__ import annotations

import math
import random
from collections import defaultdict
from collections.abc import Iterable, Sequence
from typing import Any, cast

from plm.corpus.compiler import CorpusRecord

__all__ = ["ComplExScorer"]


def _complex_score(
    entity_real: Any,
    entity_imag: Any,
    relation_real: Any,
    relation_imag: Any,
    subjects: Any,
    relations: Any,
    objects: Any,
) -> Any:
    """Return ComplEx scores for broadcast-compatible index tensors."""

    subject_real = entity_real(subjects)
    subject_imag = entity_imag(subjects)
    relation_real_values = relation_real(relations)
    relation_imag_values = relation_imag(relations)
    object_real = entity_real(objects)
    object_imag = entity_imag(objects)
    return (
        subject_real * relation_real_values * object_real
        + subject_real * relation_imag_values * object_imag
        + subject_imag * relation_real_values * object_imag
        - subject_imag * relation_imag_values * object_real
    ).sum(dim=-1)


class ComplExScorer:
    """ComplEx link-prediction scorer with deterministic mini-batch training."""

    def __init__(
        self,
        *,
        dimension: int = 32,
        epochs: int = 100,
        learning_rate: float = 0.01,
        negative_samples: int = 1,
        regularization: float = 0.0,
        batch_size: int = 32,
        seed: int = 0,
    ) -> None:
        if isinstance(dimension, bool) or not isinstance(dimension, int) or dimension <= 0:
            raise ValueError("dimension must be a positive integer")
        if isinstance(epochs, bool) or not isinstance(epochs, int) or epochs <= 0:
            raise ValueError("epochs must be a positive integer")
        if not math.isfinite(learning_rate) or learning_rate <= 0.0:
            raise ValueError("learning_rate must be finite and positive")
        if (
            isinstance(negative_samples, bool)
            or not isinstance(negative_samples, int)
            or negative_samples <= 0
        ):
            raise ValueError("negative_samples must be a positive integer")
        if not math.isfinite(regularization) or regularization < 0.0:
            raise ValueError("regularization must be finite and non-negative")
        if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size <= 0:
            raise ValueError("batch_size must be a positive integer")
        if isinstance(seed, bool) or not isinstance(seed, int):
            raise ValueError("seed must be an integer")

        self.dimension = dimension
        self.epochs = epochs
        self.learning_rate = learning_rate
        self.negative_samples = negative_samples
        self.regularization = regularization
        self.batch_size = batch_size
        self.seed = seed
        self._model: Any = None
        self._entities: dict[str, int] = {}
        self._relations: dict[str, int] = {}

    def fit(
        self, records: Iterable[CorpusRecord], candidates: Sequence[str] | None = None
    ) -> ComplExScorer:
        try:
            import torch
        except ImportError as exc:
            raise ImportError("ComplExScorer requires the optional torch dependency") from exc

        rows = list(records)
        if not rows:
            raise ValueError("ComplExScorer.fit requires at least one training record")

        candidate_values = tuple(candidates or ())
        entities = sorted(
            set(candidate_values)
            | {row.subject for row in rows}
            | {target for row in rows for target in row.targets}
        )
        relations = sorted({row.dimension for row in rows})
        if not entities or not relations:
            raise ValueError("ComplExScorer.fit requires entities and relations")

        self._entities = {key: index for index, key in enumerate(entities)}
        self._relations = {key: index for index, key in enumerate(relations)}

        triples: list[tuple[int, int, int]] = []
        known_targets: defaultdict[tuple[int, int], set[int]] = defaultdict(set)
        for row in rows:
            subject = self._entities[row.subject]
            relation = self._relations[row.dimension]
            for target in row.targets:
                object_index = self._entities[target]
                triples.append((subject, relation, object_index))
                known_targets[(subject, relation)].add(object_index)
        if not triples:
            raise ValueError("ComplExScorer.fit requires at least one positive target")

        all_entities = set(range(len(entities)))
        negative_pools: dict[tuple[int, int], tuple[int, ...]] = {}
        for key, positives in known_targets.items():
            pool = tuple(sorted(all_entities - positives))
            if not pool:
                raise ValueError(
                    "ComplExScorer.fit cannot sample a negative entity for every positive query"
                )
            negative_pools[key] = pool

        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(self.seed)
            entity_real = torch.nn.Embedding(len(entities), self.dimension)
            entity_imag = torch.nn.Embedding(len(entities), self.dimension)
            relation_real = torch.nn.Embedding(len(relations), self.dimension)
            relation_imag = torch.nn.Embedding(len(relations), self.dimension)

            optimizer = torch.optim.Adam(
                [
                    *entity_real.parameters(),
                    *entity_imag.parameters(),
                    *relation_real.parameters(),
                    *relation_imag.parameters(),
                ],
                lr=self.learning_rate,
            )
            rng = random.Random(self.seed)
            triple_indices = list(range(len(triples)))

            for _ in range(self.epochs):
                rng.shuffle(triple_indices)
                for start in range(0, len(triple_indices), self.batch_size):
                    batch = [
                        triples[index] for index in triple_indices[start : start + self.batch_size]
                    ]
                    subjects = torch.tensor([triple[0] for triple in batch], dtype=torch.long)
                    relations_tensor = torch.tensor(
                        [triple[1] for triple in batch], dtype=torch.long
                    )
                    objects = torch.tensor([triple[2] for triple in batch], dtype=torch.long)
                    negative_objects = torch.tensor(
                        [
                            [
                                negative_pools[(subject, relation)][
                                    rng.randrange(len(negative_pools[(subject, relation)]))
                                ]
                                for _ in range(self.negative_samples)
                            ]
                            for subject, relation, _ in batch
                        ],
                        dtype=torch.long,
                    )

                    positive_scores = _complex_score(
                        entity_real,
                        entity_imag,
                        relation_real,
                        relation_imag,
                        subjects,
                        relations_tensor,
                        objects,
                    )
                    negative_subjects = subjects.unsqueeze(1).expand_as(negative_objects)
                    negative_relations = relations_tensor.unsqueeze(1).expand_as(negative_objects)
                    negative_scores = _complex_score(
                        entity_real,
                        entity_imag,
                        relation_real,
                        relation_imag,
                        negative_subjects,
                        negative_relations,
                        negative_objects,
                    )
                    scores = torch.cat((positive_scores, negative_scores.reshape(-1)))
                    labels = torch.cat(
                        (
                            torch.ones_like(positive_scores),
                            torch.zeros_like(negative_scores.reshape(-1)),
                        )
                    )
                    loss = torch.nn.functional.binary_cross_entropy_with_logits(scores, labels)
                    if self.regularization:
                        l2 = sum(
                            parameter.square().mean()
                            for parameter in (
                                entity_real.weight,
                                entity_imag.weight,
                                relation_real.weight,
                                relation_imag.weight,
                            )
                        )
                        loss = loss + self.regularization * l2

                    optimizer.zero_grad(set_to_none=True)
                    cast(Any, loss).backward()
                    optimizer.step()

        self._model = (entity_real, entity_imag, relation_real, relation_imag)
        return self

    def score(self, query: CorpusRecord, candidate: str) -> float:
        if (
            self._model is None
            or candidate not in self._entities
            or query.subject not in self._entities
            or query.dimension not in self._relations
        ):
            return 0.0
        entity_real, entity_imag, relation_real, relation_imag = self._model
        subject = self._entities[query.subject]
        relation = self._relations[query.dimension]
        object_index = self._entities[candidate]
        return float(
            (
                entity_real.weight[subject]
                * relation_real.weight[relation]
                * entity_real.weight[object_index]
                + entity_real.weight[subject]
                * relation_imag.weight[relation]
                * entity_imag.weight[object_index]
                + entity_imag.weight[subject]
                * relation_real.weight[relation]
                * entity_imag.weight[object_index]
                - entity_imag.weight[subject]
                * relation_imag.weight[relation]
                * entity_real.weight[object_index]
            )
            .sum()
            .detach()
            .cpu()
            .item()
        )

    __call__ = score
