"""Apply deterministic request metadata to parsed model IDs, without graph facts."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

from plm.serving.parser import ProtocolResponse

__all__ = ["PostprocessResult", "postprocess_response"]


@dataclass(frozen=True)
class PostprocessResult:
    """Processed IDs and disjoint removal counts; targets may be empty."""

    response: ProtocolResponse
    removed_subject: int
    removed_ignored: int
    removed_duplicates: int
    removed_by_limit: int


def postprocess_response(
    response: ProtocolResponse,
    *,
    ignore: Iterable[str] = (),
    limit: int | None = None,
) -> PostprocessResult:
    """Enforce SAME self-exclusion, IGNORE, stable uniqueness, then a return bound.

    Operates on an already parsed response. It never looks up relation facts,
    fills missing products, fabricates EOS, or changes the model's raw evidence.
    IGNORE and numeric limits are metadata, never tokens. Filters may yield no IDs.
    """
    if response.mode != "SAME":
        raise ValueError("post-processing supports SAME mode only")
    if limit is not None and (isinstance(limit, bool) or not isinstance(limit, int) or limit < 0):
        raise ValueError("limit must be a nonnegative integer or None")
    if isinstance(ignore, str):
        raise TypeError("ignore must be a collection of product keys, not one string")
    ignored = set(ignore)
    if any(not isinstance(key, str) for key in ignored):
        raise TypeError("ignored product keys must be strings")
    subject_count = ignored_count = duplicate_count = 0
    unique = []
    seen = set()
    for key in response.targets:
        if key == response.subject:
            subject_count += 1
        elif key in ignored:
            ignored_count += 1
        elif key in seen:
            duplicate_count += 1
        else:
            seen.add(key)
            unique.append(key)
    selected = unique if limit is None else unique[:limit]
    processed = ProtocolResponse(
        response.subject, response.dimension, response.mode, tuple(selected)
    )
    return PostprocessResult(
        processed, subject_count, ignored_count, duplicate_count, len(unique) - len(selected)
    )
