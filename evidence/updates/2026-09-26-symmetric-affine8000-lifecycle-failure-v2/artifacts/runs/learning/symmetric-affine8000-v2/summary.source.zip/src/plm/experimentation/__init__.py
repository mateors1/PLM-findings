"""AVO-compatible experiment identity, evidence, comparison, and lineage APIs.

This package intentionally exposes infrastructure rather than an autonomous
search policy.  An external AVO operator may vary candidates, but the package
records exactly what was tried and prevents adaptive search from consuming the
protected final-test split.
"""

from __future__ import annotations

from plm.experimentation.comparison import (
    ComparisonResult,
    ComparisonRule,
    compare_objectives,
)
from plm.experimentation.evidence import (
    CandidateRecord,
    EvaluationProtocol,
    EvaluationReceipt,
    HardGateResult,
    Hypothesis,
    LineageEntry,
    ObjectiveVector,
    Prediction,
    SelectionDecision,
)
from plm.experimentation.firewall import (
    TestFirewallError,
    assert_candidate_split,
    assert_final_test_split,
)
from plm.experimentation.identity import ExperimentIdentity
from plm.experimentation.lineage import LineageLedger, namespace_root
from plm.experimentation.measurement import MeasurementSummary, summarize_measurements

__all__ = [
    "CandidateRecord",
    "ComparisonResult",
    "ComparisonRule",
    "EvaluationProtocol",
    "EvaluationReceipt",
    "ExperimentIdentity",
    "HardGateResult",
    "Hypothesis",
    "LineageEntry",
    "LineageLedger",
    "MeasurementSummary",
    "ObjectiveVector",
    "Prediction",
    "SelectionDecision",
    "TestFirewallError",
    "assert_candidate_split",
    "assert_final_test_split",
    "compare_objectives",
    "namespace_root",
    "summarize_measurements",
]
