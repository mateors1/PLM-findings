"""Torch-light model input/output contracts shared by training and evaluation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = ["DecodeOutput", "KVCache", "ModelInput", "ModelOutput"]


@dataclass(frozen=True)
class KVCache:
    """Ephemeral unpadded inference state; layers contain unrepeated (K, V)."""

    layers: tuple[tuple[Any, Any], ...]
    position: int
    owner: object


@dataclass(frozen=True)
class DecodeOutput:
    """Token logits for the supplied chunk and its updated request-local cache."""

    logits: Any
    cache: KVCache


@dataclass(frozen=True)
class ModelInput:
    """Inputs with unshifted, input-aligned labels; -100 excludes a target.

    The decoder shifts labels once internally for next-token prediction.
    """

    input_ids: Any
    labels: Any | None = None
    attention_mask: Any | None = None


@dataclass(frozen=True)
class ModelOutput:
    """Reference decoder output with optional masked causal-LM loss."""

    logits: Any
    loss: Any | None = None
    aux_loss: Any | None = None
    expert_load: Any | None = None
    task_loss: Any | None = None
    first_target_loss: Any | None = None
    prompt_set_loss: Any | None = None
    prompt_set_logits: Any | None = None
    symmetric_relation_loss: Any | None = None
    symmetric_relation_logits: Any | None = None
    continuation_set_loss: Any | None = None
    continuation_set_query_count: int = 0
