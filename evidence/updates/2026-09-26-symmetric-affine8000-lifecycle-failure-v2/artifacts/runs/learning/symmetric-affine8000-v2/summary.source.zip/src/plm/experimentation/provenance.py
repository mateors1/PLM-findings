"""Capture the executed source, dependency lock, and optional training runtime."""

from __future__ import annotations

import hashlib
import io
import platform
import subprocess
import zipfile
from pathlib import Path

__all__ = ["capture_runtime_provenance"]


def capture_runtime_provenance(
    *,
    source_archive: str | Path | None = None,
) -> tuple[str, dict[str, str]]:
    """Return Git revision and content/runtime identities, including dirty code.

    Source bytes, not only HEAD, identify uncommitted implementations. Resolved
    config has a separate hash. Documentation changes do not change this digest.
    """
    root = Path(__file__).resolve().parents[3]
    paths = [*sorted((root / "src").rglob("*.py")), root / "pyproject.toml", root / "uv.lock"]
    digest = hashlib.sha256()
    archive_buffer = io.BytesIO()
    with zipfile.ZipFile(archive_buffer, "w") as archive:
        for path in paths:
            relative = path.relative_to(root).as_posix().encode("utf-8")
            payload = path.read_bytes()
            digest.update(len(relative).to_bytes(8, "big") + relative)
            digest.update(len(payload).to_bytes(8, "big") + payload)
            info = zipfile.ZipInfo(relative.decode("utf-8"))  # Fixed timestamp.
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, payload)
    archive_bytes = archive_buffer.getvalue()
    if source_archive is not None:
        target = Path(source_archive)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if target.read_bytes() != archive_bytes:
                raise ValueError("source archive already contains a different implementation")
        else:
            with target.open("xb") as stream:
                stream.write(archive_bytes)
    revision = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=root, check=True, capture_output=True, text=True
    ).stdout.strip()
    environment = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "source_tree_sha256": digest.hexdigest(),
        "source_archive_sha256": hashlib.sha256(archive_bytes).hexdigest(),
        "uv_lock_sha256": hashlib.sha256((root / "uv.lock").read_bytes()).hexdigest(),
    }
    # Baseline reporting also works in a core environment without Torch.
    try:
        import torch
    except ImportError:
        environment["torch"] = "not-installed"
        return revision, environment

    environment.update(
        {
            "torch": str(torch.__version__),
            "cuda": str(torch.version.cuda),
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none",
        }
    )
    return revision, environment
