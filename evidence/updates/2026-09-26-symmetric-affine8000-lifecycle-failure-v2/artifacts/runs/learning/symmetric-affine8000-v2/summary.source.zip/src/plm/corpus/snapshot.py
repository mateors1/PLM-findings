"""Create a named, provenance-backed dataset without replacing existing data."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Callable
from dataclasses import asdict
from pathlib import Path
from tempfile import TemporaryDirectory

from plm.corpus.compiler import compile_corpus
from plm.corpus.validation import require_valid_artifacts
from plm.graph.importers import POKEAPI_SOURCE_REVISION, _fetch_text, import_national_dex
from plm.graph.schema import connect, validate_graph
from plm.protocol.config import load_protocol

__all__ = ["prepare_dataset_snapshot"]


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare_dataset_snapshot(
    data_root: str | Path,
    name: str,
    *,
    protocol_path: str | Path,
    fetch_text: Callable[[str], str] = _fetch_text,
) -> Path:
    """Import pinned sources, validate/recompile, publish once, and save a receipt.

    Existing complete snapshots are verified without network calls or writes.
    A receipt with all data absent can be reconstructed from its pinned sources;
    every reconstructed byte hash must match before anything is published.
    Partial snapshots are never overwritten; select a new name after diagnosing
    an interrupted publication. CSV hashes cover the UTF-8 text the importer uses.
    """
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,95}", name):
        raise ValueError("dataset name must use lowercase letters, digits, underscores or hyphens")
    root = Path(data_root).resolve()
    protocol_file = Path(protocol_path)
    protocol_hash = _digest(protocol_file)
    protocol = load_protocol(protocol_file)
    receipt_path = root / "manifests" / f"{name}.json"
    graph_relative = Path("sqlite") / f"{name}.snapshot.db"
    corpus_relative = Path("processed") / name
    raw_relative = Path("raw") / name
    recorded_receipt = None
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        if receipt.get("source_revision") != POKEAPI_SOURCE_REVISION:
            raise ValueError("snapshot source revision differs from the current recipe")
        if receipt.get("protocol_sha256") != protocol_hash:
            raise ValueError("snapshot protocol differs from the current recipe")
        files = receipt.get("files")
        if not isinstance(files, dict) or not files:
            raise ValueError("snapshot receipt has no file identities")
        required = {graph_relative.as_posix()} | {
            (corpus_relative / filename).as_posix()
            for filename in ("manifest.json", "records.jsonl", "vocabulary.json")
        }
        if not required.issubset(files):
            raise ValueError("snapshot receipt is missing required artifact identities")
        missing = []
        for relative, expected in files.items():
            path = (root / relative).resolve()
            if not path.is_relative_to(root):
                raise ValueError(f"snapshot file identity mismatch: {relative}")
            if not path.exists():
                missing.append(relative)
            elif not path.is_file() or _digest(path) != expected:
                raise ValueError(f"snapshot file identity mismatch: {relative}")
        if not missing:
            require_valid_artifacts(
                root / corpus_relative, graph_db=root / graph_relative, protocol=protocol
            )
            return receipt_path
        if len(missing) != len(files):
            raise ValueError("snapshot is partially missing; refusing to repair it in place")
        recorded_receipt = receipt
    for relative in (graph_relative, corpus_relative, raw_relative):
        if (root / relative).exists():
            raise FileExistsError(f"refusing to overwrite an existing snapshot path: {relative}")

    with TemporaryDirectory(prefix="plm-snapshot-") as temporary:
        stage = Path(temporary)
        raw_dir = stage / raw_relative
        raw_dir.mkdir(parents=True)

        def capture_source(url: str) -> str:
            text = fetch_text(url)
            filename = url.rsplit("/", 1)[-1]
            (raw_dir / filename).write_text(text, encoding="utf-8", newline="\n")
            return text

        graph_path = stage / graph_relative
        graph_path.parent.mkdir(parents=True)
        products, edges = import_national_dex(
            graph_path,
            protocol_version=protocol.version,
            fetch_text=capture_source,
            snapshot_imported_at=(
                recorded_receipt["source_metadata"]["imported_at"] if recorded_receipt else None
            ),
        )
        graph_report = validate_graph(graph_path)
        if not graph_report.ok:
            raise ValueError(f"imported graph is invalid: {graph_report.issues}")
        corpus_dir = stage / corpus_relative
        manifest = compile_corpus(graph_path, protocol=protocol, output_dir=corpus_dir)
        require_valid_artifacts(corpus_dir, graph_db=graph_path, protocol=protocol)
        # Independent second output proves byte stability for this snapshot.
        recompiled = stage / "recompiled"
        compile_corpus(graph_path, protocol=protocol, output_dir=recompiled)
        for filename in ("manifest.json", "records.jsonl", "vocabulary.json"):
            if (corpus_dir / filename).read_bytes() != (recompiled / filename).read_bytes():
                raise ValueError(f"corpus compilation is not byte stable: {filename}")
        conn = connect(graph_path)
        try:
            metadata = dict(conn.execute("SELECT key, value FROM meta"))
        finally:
            conn.close()
        sources = json.loads(metadata["source_metadata"])
        files = [graph_path, *sorted(raw_dir.iterdir()), *sorted(corpus_dir.iterdir())]
        receipt = {
            "schema_version": 1,
            "dataset_name": name,
            "source_revision": POKEAPI_SOURCE_REVISION,
            "source_metadata": sources,
            "protocol_sha256": protocol_hash,
            "graph_path": graph_relative.as_posix(),
            "corpus_path": corpus_relative.as_posix(),
            "product_count": products,
            "edge_count": edges,
            "corpus_manifest": asdict(manifest),
            "byte_stable_recompilation": True,
            "files": {path.relative_to(stage).as_posix(): _digest(path) for path in files},
        }
        if recorded_receipt is not None and receipt != recorded_receipt:
            raise ValueError("reconstructed snapshot differs from its recorded receipt")
        # Publish only validated files; exclusive creation protects old versions.
        # The receipt is written last, so its absence marks incomplete publication.
        for path in files:
            destination = root / path.relative_to(stage)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("xb") as stream:
                stream.write(path.read_bytes())
        if recorded_receipt is None:
            receipt_path.parent.mkdir(parents=True, exist_ok=True)
            with receipt_path.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
    return receipt_path
