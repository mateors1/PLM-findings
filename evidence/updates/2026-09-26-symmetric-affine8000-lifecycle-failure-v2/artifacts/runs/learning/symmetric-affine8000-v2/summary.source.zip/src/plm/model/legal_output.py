"""Vocabulary-class-aware legal output masking for constrained emission."""

from __future__ import annotations

from typing import Any

from plm.protocol.tokenizer import Vocabulary

__all__ = ["apply_legal_entity_mask"]


def apply_legal_entity_mask(
    logits: Any,
    vocabulary: Vocabulary,
    *,
    fill_value: float = -float("inf"),
) -> Any:
    """Mask a logits tensor so only product/entity IDs remain emittable."""

    import torch

    if logits.ndim < 1:
        raise ValueError("logits must have a vocabulary dimension")
    if logits.shape[-1] != len(vocabulary):
        raise ValueError("logits vocabulary dimension does not match the vocabulary")
    entity_ids = vocabulary.entity_ids()
    if not entity_ids:
        raise ValueError("vocabulary has no legal entity IDs")
    allowed = torch.zeros(len(vocabulary), dtype=torch.bool, device=logits.device)
    allowed[entity_ids] = True
    return logits.masked_fill(~allowed, fill_value)
