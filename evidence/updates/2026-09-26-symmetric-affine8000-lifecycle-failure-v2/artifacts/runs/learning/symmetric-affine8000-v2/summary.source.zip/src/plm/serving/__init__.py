"""Serving: protocol parsing, deterministic post-filtering, hydration (Phase D).

The FastAPI boundary (protocol parser + metrics) is cross-platform. The vLLM
adapter is Linux/WSL2-only and lives in ``serving/`` with its own lockfile —
never train and serve from divergent model implementations, and serve off an
immutable graph snapshot, not a live-written database.
"""

from __future__ import annotations

from plm.serving.hydration import HydratedResponse, HydratedTarget, HydrationIndex, hydrate_response
from plm.serving.parser import (
    ProtocolParseError,
    ProtocolResponse,
    allowed_token_ids,
    constrain_logits,
    parse_generated,
    prompt_ids,
)
from plm.serving.postprocess import PostprocessResult, postprocess_response

__all__ = [
    "HydratedResponse",
    "HydratedTarget",
    "HydrationIndex",
    "PostprocessResult",
    "ProtocolParseError",
    "ProtocolResponse",
    "allowed_token_ids",
    "constrain_logits",
    "hydrate_response",
    "parse_generated",
    "postprocess_response",
    "prompt_ids",
]
