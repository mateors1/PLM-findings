"""Portable checkpoint contract with experiment and RNG provenance."""

from __future__ import annotations

import hashlib
import json
import random
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from plm.experimentation.identity import ExperimentIdentity

__all__ = [
    "CheckpointState",
    "load_checkpoint",
    "save_checkpoint",
    "validate_checkpoint_identity",
]


@dataclass(frozen=True)
class CheckpointState:
    path: Path
    global_step: int
    checkpoint_hash: str
    metadata: Mapping[str, object]


def _config_dict(config: object | None) -> dict[str, object]:
    if config is None:
        return {}
    if hasattr(config, "model_dump"):
        value = config.model_dump(mode="json")
        return {str(key): item for key, item in value.items()}
    if isinstance(config, Mapping):
        return {str(key): value for key, value in config.items()}
    raise TypeError("config must be a Pydantic model or mapping")


def _rng_state() -> dict[str, object]:
    import numpy as np
    import torch

    state: dict[str, object] = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch": torch.get_rng_state(),
    }
    if torch.cuda.is_available():
        state["cuda"] = torch.cuda.get_rng_state_all()
    return state


def _restore_rng_state(state: Mapping[str, object]) -> None:
    import numpy as np
    import torch

    if "python" in state:
        random.setstate(cast(tuple[Any, ...], state["python"]))
    if "numpy" in state:
        np.random.set_state(cast(Any, state["numpy"]))
    if "torch" in state:
        # ``map_location`` may move every serialized tensor, including the
        # CPU RNG state, onto the model device.  PyTorch requires the default
        # generator state to remain a CPU ByteTensor.
        torch_state = cast(Any, state["torch"])
        torch.set_rng_state(torch_state.detach().cpu())
    if "cuda" in state and torch.cuda.is_available():
        cuda_states = cast(Any, state["cuda"])
        torch.cuda.set_rng_state_all([cuda_state.detach().cpu() for cuda_state in cuda_states])


def save_checkpoint(
    path: str | Path,
    model: Any,
    *,
    optimizer: Any | None = None,
    scheduler: Any | None = None,
    global_step: int,
    config: object | None = None,
    identity: ExperimentIdentity | None = None,
    corpus_identity: Mapping[str, str] | None = None,
    split_hash: str | None = None,
    training_metadata: Mapping[str, object] | None = None,
) -> CheckpointState:
    """Persist all state required for a deterministic resume."""

    import torch

    if not isinstance(global_step, int) or isinstance(global_step, bool) or global_step < 0:
        raise ValueError("checkpoint global_step must be a non-negative integer")
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "model": model.state_dict(),
        "optimizer": None if optimizer is None else optimizer.state_dict(),
        "scheduler": None if scheduler is None else scheduler.state_dict(),
        "global_step": global_step,
        "rng_state": _rng_state(),
        "config": _config_dict(config),
        "experiment_identity": None if identity is None else identity.to_dict(),
        "corpus_identity": dict(corpus_identity or {}),
        "split_hash": split_hash,
        "training_metadata": dict(training_metadata or {}),
    }
    torch.save(payload, target)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    metadata_path = target.with_suffix(target.suffix + ".json")
    metadata = {
        "schema_version": 1,
        "global_step": global_step,
        "checkpoint_hash": digest,
        "config": payload["config"],
        "experiment_identity": payload["experiment_identity"],
        "corpus_identity": payload["corpus_identity"],
        "split_hash": split_hash,
        "training_metadata": payload["training_metadata"],
    }
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=True, sort_keys=True, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    return CheckpointState(target, global_step, digest, metadata)


def load_checkpoint(
    path: str | Path,
    model: Any,
    *,
    optimizer: Any | None = None,
    scheduler: Any | None = None,
    map_location: str | Any = "cpu",
    restore_rng: bool = True,
) -> CheckpointState:
    """Load a checkpoint and restore model, optimizer, scheduler, and RNG."""

    import torch

    target = Path(path)
    payload = torch.load(target, map_location=map_location, weights_only=False)
    if not isinstance(payload, Mapping):
        raise ValueError("checkpoint payload must be a mapping")
    raw_step = payload.get("global_step")
    if not isinstance(raw_step, int) or isinstance(raw_step, bool) or raw_step < 0:
        raise ValueError("checkpoint global_step must be a non-negative integer")
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    metadata_path = target.with_suffix(target.suffix + ".json")
    metadata_raw: dict[str, object] = {}
    if metadata_path.exists():
        try:
            raw = json.loads(metadata_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError("checkpoint sidecar is not valid JSON") from exc
        if not isinstance(raw, dict):
            raise ValueError("checkpoint sidecar must contain a JSON object")
        metadata_raw = raw
        stored_hash = metadata_raw.get("checkpoint_hash")
        if stored_hash is not None and stored_hash != digest:
            raise ValueError("checkpoint sidecar hash does not match checkpoint bytes")
        sidecar_step = metadata_raw.get("global_step")
        if sidecar_step is not None and sidecar_step != raw_step:
            raise ValueError("checkpoint sidecar global_step does not match checkpoint payload")

    # The checkpoint bytes are authoritative. A sidecar must never substitute
    # another corpus/config identity while retaining the same checkpoint hash.
    authoritative = {
        "schema_version": 1,
        "global_step": raw_step,
        "checkpoint_hash": digest,
        **{
            key: payload.get(key)
            for key in (
                "config",
                "experiment_identity",
                "corpus_identity",
                "split_hash",
                "training_metadata",
            )
        },
    }
    if metadata_path.exists():
        for key, expected in authoritative.items():
            if metadata_raw.get(key) != expected:
                raise ValueError(f"checkpoint sidecar {key} does not match checkpoint payload")

    model.load_state_dict(payload["model"])
    if optimizer is not None:
        stored_optimizer = payload.get("optimizer")
        if stored_optimizer is None:
            raise ValueError("checkpoint has no optimizer state")
        optimizer.load_state_dict(stored_optimizer)
    if scheduler is not None:
        stored_scheduler = payload.get("scheduler")
        if stored_scheduler is None:
            raise ValueError("checkpoint has no scheduler state")
        scheduler.load_state_dict(stored_scheduler)
    if restore_rng and payload.get("rng_state") is not None:
        rng_state = payload["rng_state"]
        if not isinstance(rng_state, Mapping):
            raise ValueError("checkpoint RNG state must be a mapping")
        _restore_rng_state(rng_state)
    return CheckpointState(target, raw_step, digest, authoritative)


def validate_checkpoint_identity(
    state: CheckpointState,
    *,
    identity: ExperimentIdentity | None = None,
    split_hash: str | None = None,
) -> None:
    """Fail closed when a checkpoint is resumed against different evidence."""

    if state.global_step < 0:
        raise ValueError("checkpoint global_step must be non-negative")
    if state.metadata.get("checkpoint_hash") not in {None, state.checkpoint_hash}:
        raise ValueError("checkpoint sidecar hash does not match checkpoint bytes")
    if state.metadata.get("global_step") not in {None, state.global_step}:
        raise ValueError("checkpoint sidecar global_step does not match checkpoint payload")
    if split_hash is not None and state.metadata.get("split_hash") != split_hash:
        raise ValueError("checkpoint split identity does not match requested split")
    if identity is not None:
        raw = state.metadata.get("experiment_identity")
        if not isinstance(raw, Mapping):
            raise ValueError("checkpoint has no experiment identity")
        stored = ExperimentIdentity.from_dict(raw)
        if stored.content_hash() != identity.content_hash():
            raise ValueError("checkpoint experiment identity does not match requested identity")
