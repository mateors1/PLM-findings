"""Four independent first-choice paths selected by learned symmetric set logits."""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass, replace
from typing import Any

from plm.protocol.tokenizer import CLASS_ENTITY, ENTITY_BASE, Vocabulary
from plm.serving.generation import GenerationResult, _generation_result
from plm.serving.guidance import (
    apply_first_target_guidance,
    guidance_decoding_suffix,
    validate_guidance_alpha,
)
from plm.serving.parser import ProtocolResponse, prompt_ids
from plm.serving.postprocess import postprocess_response

__all__ = ["RerankedGenerationResult", "generate_reranked_responses"]


@dataclass(frozen=True)
class RerankedGenerationResult:
    """Selected raw evidence and four immutable candidates in first-rank order."""

    selected: GenerationResult
    candidates: tuple[GenerationResult, ...]
    set_scores: tuple[float, ...]
    selected_rank: int
    eligible: tuple[bool, ...]
    fallback_no_valid_path: bool


def _generate_rank(
    model: Any,
    vocabulary: Vocabulary,
    prompts: list[list[int]],
    rank: int,
    *,
    max_new_tokens: int,
    device: Any,
    alpha: float,
    decoding: str,
) -> tuple[GenerationResult, ...]:
    import torch

    prefixes = [list(prompt) for prompt in prompts]
    inputs = torch.tensor(prefixes, dtype=torch.long, device=device)
    count = len(prefixes)
    allowed = torch.zeros(len(vocabulary), dtype=torch.bool, device=device)
    allowed[list(vocabulary.entity_ids())] = True
    seen = torch.zeros(count, len(vocabulary), dtype=torch.bool, device=device)
    active = torch.ones(count, dtype=torch.bool, device=device)
    finished = [False] * count
    cache = None
    for step in range(max_new_tokens):
        output = model.decode(inputs, cache=cache)
        if step == 0 and alpha:
            output = apply_first_target_guidance(model, inputs, output, alpha)
        cache = output.cache
        if output.logits.shape != (count, inputs.shape[1], len(vocabulary)):
            raise ValueError("reranking logits must match batch, chunk and vocabulary")
        logits = output.logits[:, -1]
        if not torch.isfinite(logits[active]).all():
            raise ValueError("active reranking logits must be finite")
        if step:
            allowed[vocabulary.eos_id] = True
        masked = logits.masked_fill(~allowed[None, :], -float("inf"))
        masked = masked.masked_fill(seen, -float("inf"))
        next_ids = (
            masked.argsort(dim=-1, descending=True, stable=True)[:, rank - 1]
            if step == 0
            else masked.argmax(dim=-1)
        )
        next_ids = torch.where(active, next_ids, vocabulary.eos_id)
        for row, token in enumerate(next_ids.tolist()):
            if not finished[row]:
                prefixes[row].append(token)
                finished[row] = token == vocabulary.eos_id
        if all(finished):
            break
        seen.scatter_(1, next_ids[:, None], True)
        seen[:, vocabulary.eos_id] = False
        active = active & (next_ids != vocabulary.eos_id)
        inputs = next_ids[:, None]
    descriptor = decoding + (f"+first-rank{rank}-v1" if rank > 1 else "")
    return tuple(
        _generation_result(prefix, vocabulary, done, descriptor)
        for prefix, done in zip(prefixes, finished, strict=True)
    )


def _candidate_sets_and_scores(
    candidates: tuple[GenerationResult, ...],
    logits: list[float],
    vocabulary: Vocabulary,
    query: tuple[str, str],
) -> tuple[tuple[tuple[int, ...], ...], tuple[float, ...], tuple[bool, ...]]:
    subject, dimension = query
    eligibility = tuple(
        path.protocol_valid and path.terminated and len(path.targets) == len(set(path.targets))
        for path in candidates
    )
    sets, scores = [], []
    for path in candidates:
        # Failure evidence stays raw. Only valid complete responses receive the
        # existing SAME identity rules; caller IGNORE/limit never affect selection.
        targets = path.targets
        if path.protocol_valid and path.terminated:
            targets = postprocess_response(
                ProtocolResponse(subject, dimension, "SAME", targets)
            ).response.targets
        ids = sorted(set(vocabulary.encode(targets)))
        sets.append(tuple(ids))
        scores.append(_score_set_ids(ids, logits))
    return tuple(sets), tuple(scores), eligibility


def _score_set_ids(ids: Sequence[int], logits: Sequence[float]) -> float:
    """Score canonical distinct ascending IDs; callers own set construction."""
    score = math.fsum(logits[token - ENTITY_BASE] for token in ids)
    if not math.isfinite(score):
        raise ValueError("canonical symmetric set score must be finite")
    return score


def _select(
    candidates: tuple[GenerationResult, ...],
    logits: list[float],
    vocabulary: Vocabulary,
    query: tuple[str, str],
    decoding: str,
) -> RerankedGenerationResult:
    _, scores, eligibility = _candidate_sets_and_scores(candidates, logits, vocabulary, query)
    eligible_indices = [i for i, eligible in enumerate(eligibility) if eligible]
    selected = min(eligible_indices, key=lambda i: (-scores[i], i)) if eligible_indices else 0
    return RerankedGenerationResult(
        selected=replace(candidates[selected], decoding=decoding),
        candidates=candidates,
        set_scores=tuple(scores),
        selected_rank=selected + 1,
        eligible=eligibility,
        fallback_no_valid_path=not eligible_indices,
    )


def _generate_group(
    model: Any,
    vocabulary: Vocabulary,
    queries: Sequence[tuple[str, str]],
    *,
    max_new_tokens: int,
    device: str | Any = "cpu",
    first_target_guidance_alpha: float = 0.0,
) -> tuple[tuple[tuple[GenerationResult, ...], ...], list[list[float]], str]:
    """Generate four first-choice branches, then choose a complete learned set.

    Each rank repeats the original query group with a fresh cache and unique-ID
    state. Rank one follows ordinary constrained cached greedy generation.
    A separate prompt-only head pass supplies FP32 set logits. Loaded-checkpoint
    callers must establish trained-head provenance at the runtime boundary.
    """
    import torch

    validate_guidance_alpha(first_target_guidance_alpha)
    decoding = "greedy-protocol-mask-v1+unique-v1+kv-v1+batch-v1" + guidance_decoding_suffix(
        first_target_guidance_alpha
    )
    if type(max_new_tokens) is not int or max_new_tokens < 1:
        raise ValueError("max_new_tokens must be a positive integer")
    products = list(vocabulary.entity_ids())
    if len(products) < 4 or products != list(range(ENTITY_BASE, len(vocabulary))):
        raise ValueError("reranking requires at least four contiguous product columns")
    prompts = []
    for subject, dimension in queries:
        if vocabulary.class_of(subject) != CLASS_ENTITY or dimension not in {"TYPE", "COLOR"}:
            raise ValueError("reranking requires a product subject and TYPE or COLOR")
        prompts.append(list(prompt_ids(subject, dimension, vocabulary)))
    if not prompts:
        return (), [], decoding
    config = getattr(model, "config", None)
    context_limit = getattr(config, "max_seq_len", None)
    if context_limit is not None and 5 + max_new_tokens > context_limit:
        raise ValueError("prompt plus max_new_tokens exceeds model context")
    weight = getattr(config, "symmetric_relation_loss_weight", None)
    if (
        isinstance(weight, bool)
        or not isinstance(weight, (int, float))
        or not math.isfinite(weight)
        or weight <= 0
    ):
        raise ValueError("reranking requires a trained symmetric relation head")
    if not callable(model) or not callable(getattr(model, "decode", None)):
        raise ValueError("reranking requires callable model and cached decode implementation")
    model = model.to(device).eval()
    with torch.inference_mode():
        ranks = [
            _generate_rank(
                model,
                vocabulary,
                prompts,
                rank,
                max_new_tokens=max_new_tokens,
                device=device,
                alpha=first_target_guidance_alpha,
                decoding=decoding,
            )
            for rank in range(1, 5)
        ]
        ids = torch.tensor(prompts, dtype=torch.long, device=device)
        logits = getattr(model(ids), "symmetric_relation_logits", None)
        if (
            not isinstance(logits, torch.Tensor)
            or logits.shape != (len(prompts), len(products))
            or logits.dtype != torch.float32
            or not torch.isfinite(logits).all()
        ):
            raise ValueError("reranking requires finite FP32 prompt-aligned symmetric logits")
        scores: list[list[float]] = logits.cpu().tolist()
    return tuple(tuple(row) for row in zip(*ranks, strict=True)), scores, decoding


def generate_reranked_responses(
    model: Any,
    vocabulary: Vocabulary,
    queries: Sequence[tuple[str, str]],
    *,
    max_new_tokens: int,
    device: str | Any = "cpu",
    first_target_guidance_alpha: float = 0.0,
) -> tuple[RerankedGenerationResult, ...]:
    """Select one emitted path, preserving the original four-path numerical route."""
    ranks, scores, decoding = _generate_group(
        model,
        vocabulary,
        queries,
        max_new_tokens=max_new_tokens,
        device=device,
        first_target_guidance_alpha=first_target_guidance_alpha,
    )
    return tuple(
        _select(
            tuple(candidates),
            row_logits,
            vocabulary,
            query,
            decoding + "+first4-symmetric-set-logit-sum-v1",
        )
        for candidates, row_logits, query in zip(ranks, scores, queries, strict=True)
    )
