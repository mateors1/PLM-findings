"""Reproducible graph importers backed by canonical source snapshots."""

from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from collections.abc import Callable
from datetime import UTC, datetime
from io import StringIO
from pathlib import Path
from urllib.request import Request, urlopen

from plm.graph.repository import GraphRepository
from plm.graph.schema import connect, init_graph

__all__ = ["POKEAPI_CSV_BASE_URL", "POKEAPI_SOURCE_REVISION", "import_national_dex"]

# PokeAPI's maintained CSV dump gives the entire National Dex in five requests,
# rather than one HTTP request per species/attribute pair.
POKEAPI_SOURCE_REVISION = "f15414790832c88d784d1537658b957fd73cbbbd"
POKEAPI_CSV_BASE_URL = (
    f"https://raw.githubusercontent.com/PokeAPI/pokeapi/{POKEAPI_SOURCE_REVISION}/data/v2/csv"
)
_CSV_FILES = (
    "pokemon_species.csv",
    "pokemon.csv",
    "pokemon_types.csv",
    "types.csv",
    "pokemon_colors.csv",
)


def _fetch_text(url: str) -> str:
    request = Request(url, headers={"User-Agent": "plm-research-importer/0.1"})
    with urlopen(request, timeout=60) as response:
        return bytes(response.read()).decode("utf-8")


def _rows(text: str) -> list[dict[str, str]]:
    return list(csv.DictReader(StringIO(text)))


def _token_key(prefix: str, value: str) -> str:
    return f"{prefix}_{value.upper().replace('-', '_')}"


def import_national_dex(
    db_path: str | Path,
    *,
    protocol_version: str,
    base_url: str = POKEAPI_CSV_BASE_URL,
    source_revision: str | None = None,
    fetch_text: Callable[[str], str] = _fetch_text,
    snapshot_imported_at: str | None = None,
) -> tuple[int, int]:
    """Import every National-Dex species with its default-form type and color.

    PokeAPI CSV data is the external source; SQLite becomes the project's
    source of truth after import. The importer deliberately persists only v1's
    hidden ``TYPE``/``COLOR`` pivots, not textual or presentation metadata.
    Returns ``(product_count, edge_count)`` and is safe to re-run.
    ``snapshot_imported_at`` preserves the original import timestamp when
    reconstructing a recorded snapshot; it is not the reconstruction time.
    """
    base = base_url.rstrip("/")
    source_revision = source_revision or (
        POKEAPI_SOURCE_REVISION if base_url.rstrip("/") == POKEAPI_CSV_BASE_URL else "custom"
    )
    source_urls = {name: f"{base}/{name}" for name in _CSV_FILES}
    raw_sources = {name: fetch_text(url) for name, url in source_urls.items()}
    source_hashes = {
        name: hashlib.sha256(text.encode("utf-8")).hexdigest() for name, text in raw_sources.items()
    }
    source_rows = {name: _rows(text) for name, text in raw_sources.items()}
    species_rows = source_rows["pokemon_species.csv"]
    pokemon_rows = source_rows["pokemon.csv"]
    pokemon_type_rows = source_rows["pokemon_types.csv"]

    colors = {row["id"]: row["identifier"] for row in source_rows["pokemon_colors.csv"]}
    types = {row["id"]: row["identifier"] for row in source_rows["types.csv"]}
    default_pokemon = {
        row["species_id"]: row["id"] for row in pokemon_rows if row["is_default"] == "1"
    }
    type_ids_by_pokemon: defaultdict[str, list[str]] = defaultdict(list)
    for row in pokemon_type_rows:
        type_ids_by_pokemon[row["pokemon_id"]].append(row["type_id"])

    init_graph(db_path, protocol_version=protocol_version)
    with GraphRepository(db_path) as repo:
        imported_at = snapshot_imported_at or datetime.now(UTC).replace(microsecond=0).isoformat()
        source_metadata = {
            "provider": "PokeAPI",
            "revision": source_revision,
            "revision_url": f"https://github.com/PokeAPI/pokeapi/commit/{source_revision}",
            "imported_at": imported_at,
            "files": {
                name: {"url": source_urls[name], "sha256": source_hashes[name]}
                for name in _CSV_FILES
            },
        }
        provenance_id = repo.add_provenance(
            "canon",
            citation=f"https://github.com/PokeAPI/pokeapi/tree/{source_revision}",
            license="CC BY-SA 4.0 (PokeAPI data)",
            notes=json.dumps(source_metadata, ensure_ascii=True, sort_keys=True),
        )
        for species in sorted(species_rows, key=lambda row: int(row["id"])):
            species_id = species["id"]
            name = species["identifier"]
            color_name = colors.get(species["color_id"])
            pokemon_id = default_pokemon.get(species_id)
            if color_name is None or pokemon_id is None:
                raise ValueError(f"PokeAPI data is incomplete for species id {species_id}")
            type_ids = type_ids_by_pokemon[pokemon_id]
            if not type_ids:
                raise ValueError(
                    f"PokeAPI data has no default-form types for species id {species_id}"
                )

            product_key = _token_key("PKM", name)
            repo.add_node(product_key, label=name, provenance_id=provenance_id)
            color_key = _token_key("ATTR", color_name)
            repo.add_node(color_key, kind="attribute", provenance_id=provenance_id)
            repo.add_edge(product_key, color_key, "HAS_COLOR", provenance_id=provenance_id)
            for type_id in type_ids:
                type_name = types.get(type_id)
                if type_name is None:
                    raise ValueError(f"PokeAPI data references unknown type id {type_id}")
                type_key = _token_key("ATTR", type_name)
                repo.add_node(type_key, kind="attribute", provenance_id=provenance_id)
                repo.add_edge(product_key, type_key, "HAS_TYPE", provenance_id=provenance_id)

        product_count = len(repo.node_keys(kind="product"))
        _, edge_count, _ = repo.counts()
    conn = connect(db_path)
    try:
        conn.executemany(
            "INSERT INTO meta(key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            [
                ("source_provider", "PokeAPI"),
                ("source_revision", source_revision),
                (
                    "source_metadata",
                    json.dumps(source_metadata, ensure_ascii=True, sort_keys=True),
                ),
            ],
        )
        conn.commit()
    finally:
        conn.close()
    return product_count, edge_count
