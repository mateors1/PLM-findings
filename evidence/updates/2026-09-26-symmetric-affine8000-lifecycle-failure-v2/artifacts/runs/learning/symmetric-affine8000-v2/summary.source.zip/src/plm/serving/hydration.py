"""Hydration of opaque protocol IDs against an immutable SQLite snapshot."""

from __future__ import annotations

import sqlite3
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

from plm.serving.parser import ProtocolResponse

__all__ = ["HydratedResponse", "HydratedTarget", "HydrationIndex", "hydrate_response"]


@dataclass(frozen=True)
class HydratedTarget:
    key: str
    label: str | None


@dataclass(frozen=True)
class HydratedResponse:
    subject: HydratedTarget
    dimension: str
    mode: str
    targets: tuple[HydratedTarget, ...]


@dataclass(frozen=True)
class HydrationIndex:
    """Frozen product-only lookup; no relation facts are exposed to generation."""

    products: Mapping[str, HydratedTarget]

    @classmethod
    def from_snapshot(cls, graph_db: str | Path) -> HydrationIndex:
        path = Path(graph_db).resolve()
        conn = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
        try:
            products = {
                str(key): HydratedTarget(str(key), None if label is None else str(label))
                for key, label in conn.execute(
                    "SELECT key, label FROM nodes WHERE kind='product' AND status='active'"
                )
            }
        finally:
            conn.close()
        return cls(MappingProxyType(products))

    def _lookup(self, key: str) -> HydratedTarget:
        if key not in self.products:
            raise ValueError(f"cannot hydrate non-active product: {key}")
        return self.products[key]

    def hydrate(self, response: ProtocolResponse) -> HydratedResponse:
        return _hydrate(response, self._lookup)


def _hydrate(
    response: ProtocolResponse, lookup: Callable[[str], HydratedTarget]
) -> HydratedResponse:
    return HydratedResponse(
        lookup(response.subject),
        response.dimension,
        response.mode,
        tuple(lookup(target) for target in response.targets),
    )


def _lookup(conn: sqlite3.Connection, key: str) -> HydratedTarget:
    row = conn.execute(
        "SELECT key, label, kind, status FROM nodes WHERE key = ?", (key,)
    ).fetchone()
    if row is None or row[2] != "product" or row[3] != "active":
        raise ValueError(f"cannot hydrate non-active product: {key}")
    return HydratedTarget(str(row[0]), None if row[1] is None else str(row[1]))


def hydrate_response(response: ProtocolResponse, graph_db: str | Path) -> HydratedResponse:
    """Hydrate only product nodes from a read-only graph snapshot."""

    path = Path(graph_db).resolve()
    if not path.exists():
        raise FileNotFoundError(f"graph snapshot not found: {path}")
    conn = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        return _hydrate(response, lambda key: _lookup(conn, key))
    finally:
        conn.close()
