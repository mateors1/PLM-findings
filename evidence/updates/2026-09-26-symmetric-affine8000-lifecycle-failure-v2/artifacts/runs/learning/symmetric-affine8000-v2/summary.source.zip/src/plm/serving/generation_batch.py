"""Fixed-group cached decoding with independent per-query completion state."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from plm.protocol.tokenizer import CLASS_ENTITY, Vocabulary
from plm.serving.generation import GenerationResult, _generation_result
from plm.serving.guidance import (
    apply_first_target_guidance,
    guidance_decoding_suffix,
    validate_guidance_alpha,
)
from plm.serving.parser import prompt_ids

__all__ = ["generate_responses"]


def generate_responses(
    model: Any,
    vocabulary: Vocabulary,
    queries: Sequence[tuple[str, str]],
    *,
    max_new_tokens: int,
    device: str | Any = "cpu",
    prevent_repeated_targets: bool = False,
    first_target_guidance_alpha: float = 0.0,
    symmetric_set_reranking: bool = False,
) -> tuple[GenerationResult, ...]:
    """Decode a fixed group of five-token prompts using constrained KV inference.

    Returned results preserve query order, including duplicate queries. Finished
    rows remain in the cache, but their subsequent dummy inputs are never returned.
    This is neither dynamic admission nor continuous batching. No oracle labels,
    subject exclusion, or forced EOS enter token selection.
    Optional first-target guidance scores the learned head once per group and
    changes product logits only at the fresh prompt's first decision.
    """
    import torch

    if symmetric_set_reranking:
        if not prevent_repeated_targets:
            raise ValueError("symmetric set reranking requires unique cached decoding")
        from plm.serving.set_reranking import generate_reranked_responses

        return tuple(
            item.selected
            for item in generate_reranked_responses(
                model,
                vocabulary,
                queries,
                max_new_tokens=max_new_tokens,
                device=device,
                first_target_guidance_alpha=first_target_guidance_alpha,
            )
        )

    validate_guidance_alpha(first_target_guidance_alpha)
    if (
        isinstance(max_new_tokens, bool)
        or not isinstance(max_new_tokens, int)
        or max_new_tokens < 1
    ):
        raise ValueError("max_new_tokens must be a positive integer")
    prefixes = []
    for subject, dimension in queries:
        if vocabulary.class_of(subject) != CLASS_ENTITY or dimension not in {"TYPE", "COLOR"}:
            raise ValueError("generation requires a product subject and TYPE or COLOR")
        prefixes.append(list(prompt_ids(subject, dimension, vocabulary)))
    if not prefixes:
        return ()
    context_limit = getattr(getattr(model, "config", None), "max_seq_len", None)
    if context_limit is not None and 5 + max_new_tokens > context_limit:
        raise ValueError("prompt plus max_new_tokens exceeds model context")
    if not callable(getattr(model, "decode", None)):
        raise ValueError("batched generation requires a model.decode implementation")
    model = model.to(device).eval()
    inputs = torch.tensor(prefixes, dtype=torch.long, device=device)
    batch_size = len(prefixes)
    allowed = torch.zeros(len(vocabulary), dtype=torch.bool, device=device)
    allowed[list(vocabulary.entity_ids())] = True
    seen = (
        torch.zeros(batch_size, len(vocabulary), dtype=torch.bool, device=device)
        if prevent_repeated_targets
        else None
    )
    finished = [False] * batch_size
    active = torch.ones(batch_size, dtype=torch.bool, device=device)
    cache = None
    with torch.inference_mode():
        for step in range(max_new_tokens):
            output = model.decode(inputs, cache=cache)
            if step == 0 and first_target_guidance_alpha:
                output = apply_first_target_guidance(
                    model, inputs, output, first_target_guidance_alpha
                )
            cache = output.cache
            if output.logits.shape != (batch_size, inputs.shape[1], len(vocabulary)):
                raise ValueError("batched logits must match batch, chunk and vocabulary dimensions")
            logits = output.logits[:, -1]
            if not torch.isfinite(logits[active]).all():
                raise ValueError("active generation logits must be finite")
            if step:
                allowed[vocabulary.eos_id] = True
            masked = logits.masked_fill(~allowed[None, :], -float("inf"))
            if seen is not None:
                masked = masked.masked_fill(seen, -float("inf"))
            next_ids = masked.argmax(dim=-1)
            # EOS padding is only for already finished rows; it is never appended
            # to an active answer to disguise truncation or manufacture completion.
            next_ids = torch.where(active, next_ids, vocabulary.eos_id)
            choices = next_ids.tolist()
            for row, token in enumerate(choices):
                if not finished[row]:
                    prefixes[row].append(token)
                    finished[row] = token == vocabulary.eos_id
            if all(finished):
                break
            if seen is not None:
                seen.scatter_(1, next_ids[:, None], True)
                seen[:, vocabulary.eos_id] = False
            active = active & (next_ids != vocabulary.eos_id)
            inputs = next_ids[:, None]
    decoding = (
        "greedy-protocol-mask-v1"
        + ("+unique-v1" if prevent_repeated_targets else "")
        + "+kv-v1+batch-v1"
        + guidance_decoding_suffix(first_target_guidance_alpha)
    )
    return tuple(
        _generation_result(prefix, vocabulary, done, decoding)
        for prefix, done in zip(prefixes, finished, strict=True)
    )
