"""Typed candidate and evaluator evidence records for AVO-compatible runs."""

from __future__ import annotations

import json
import math
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Literal

from plm.experimentation.identity import ExperimentIdentity

__all__ = [
    "CandidateRecord",
    "EvaluationProtocol",
    "EvaluationReceipt",
    "HardGateResult",
    "Hypothesis",
    "LineageEntry",
    "ObjectiveVector",
    "Prediction",
    "SelectionDecision",
]


def _json_value(value: object) -> object:
    """Convert supported evidence values to strict JSON-compatible values."""

    if hasattr(value, "to_dict"):
        return _json_value(value.to_dict())
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("evidence JSON values must contain finite floats")
        return value
    if isinstance(value, tuple | list):
        return [_json_value(item) for item in value]
    if isinstance(value, Mapping):
        converted: dict[str, object] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("evidence mapping keys must be strings")
            converted[key] = _json_value(item)
        return dict(sorted(converted.items()))
    raise TypeError(f"unsupported evidence JSON value: {type(value).__name__}")


def _identifier(value: object, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{label} must be a non-empty string")
    if value in {".", ".."} or any(separator in value for separator in ("/", "\\", ":")):
        raise ValueError(f"{label} must be a safe path component")
    return value


def _text(value: object, label: str, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value):
        qualifier = "string" if allow_empty else "non-empty string"
        raise ValueError(f"{label} must be a {qualifier}")
    return value


def _string_sequence(value: object, label: str) -> tuple[str, ...]:
    if not isinstance(value, (tuple, list)) or not all(isinstance(item, str) for item in value):
        raise ValueError(f"{label} must be a sequence of strings")
    return tuple(value)


def _seed_sequence(value: object, label: str) -> tuple[int, ...]:
    if (
        not isinstance(value, (tuple, list))
        or not value
        or not all(isinstance(seed, int) and not isinstance(seed, bool) for seed in value)
    ):
        raise ValueError(f"{label} must contain at least one integer seed")
    return tuple(value)


def _finite_float(value: object, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be a finite number")
    converted = float(value)
    if not math.isfinite(converted):
        raise ValueError(f"{label} must be a finite number")
    return converted


def _numeric_mapping(value: object, label: str) -> Mapping[str, float]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} must be a string-to-number mapping")
    converted: dict[str, float] = {}
    for key, item in value.items():
        name = _text(key, f"{label} key")
        converted[name] = _finite_float(item, f"{label}[{name}]")
    return MappingProxyType(converted)


def _string_mapping(value: object, label: str) -> Mapping[str, str]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} must be a string-to-string mapping")
    converted: dict[str, str] = {}
    for key, item in value.items():
        name = _text(key, f"{label} key")
        converted[name] = _text(item, f"{label}[{name}]", allow_empty=True)
    return MappingProxyType(converted)


def _json_mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} must be a JSON object")
    converted = _json_value(value)
    if not isinstance(converted, dict):
        raise ValueError(f"{label} must be a JSON object")
    return MappingProxyType(converted)


@dataclass(frozen=True)
class Hypothesis:
    statement: str
    rationale: str = ""
    variables: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "statement", _text(self.statement, "hypothesis statement"))
        object.__setattr__(
            self, "rationale", _text(self.rationale, "hypothesis rationale", allow_empty=True)
        )
        object.__setattr__(
            self, "variables", _string_sequence(self.variables, "hypothesis variables")
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "statement": self.statement,
            "rationale": self.rationale,
            "variables": list(self.variables),
        }


@dataclass(frozen=True)
class Prediction:
    metric: str
    direction: Literal["increase", "decrease", "unchanged"]
    expected_delta: float | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "metric", _text(self.metric, "prediction metric"))
        if self.direction not in {"increase", "decrease", "unchanged"}:
            raise ValueError("prediction direction is invalid")
        if self.expected_delta is not None:
            object.__setattr__(
                self,
                "expected_delta",
                _finite_float(self.expected_delta, "prediction expected_delta"),
            )

    def to_dict(self) -> dict[str, object]:
        return {
            "metric": self.metric,
            "direction": self.direction,
            "expected_delta": self.expected_delta,
        }


@dataclass(frozen=True)
class HardGateResult:
    name: str
    passed: bool
    details: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "name", _text(self.name, "hard gate name"))
        if not isinstance(self.passed, bool):
            raise ValueError("hard gate passed must be boolean")
        object.__setattr__(
            self, "details", _text(self.details, "hard gate details", allow_empty=True)
        )

    def to_dict(self) -> dict[str, object]:
        return {"name": self.name, "passed": self.passed, "details": self.details}


@dataclass(frozen=True)
class ObjectiveVector:
    values: Mapping[str, float]
    directions: Mapping[str, Literal["maximize", "minimize"]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "values", _numeric_mapping(self.values, "objective values"))
        if not isinstance(self.directions, Mapping):
            raise ValueError("objective directions must be a string mapping")
        directions: dict[str, Literal["maximize", "minimize"]] = {}
        for key, direction in self.directions.items():
            name = _text(key, "objective direction key")
            if direction not in {"maximize", "minimize"}:
                raise ValueError(f"objective direction for {name} is invalid")
            directions[name] = direction
        object.__setattr__(self, "directions", MappingProxyType(directions))

    def to_dict(self) -> dict[str, object]:
        return {
            "values": dict(sorted(self.values.items())),
            "directions": dict(sorted(self.directions.items())),
        }


@dataclass(frozen=True)
class EvaluationProtocol:
    split: Literal["train", "validation", "test"]
    evaluator_version: str
    seeds: tuple[int, ...]
    repetitions: int
    procedure: str
    purpose: Literal["search", "finalization"] = "search"

    def __post_init__(self) -> None:
        if self.split not in {"train", "validation", "test"}:
            raise ValueError("evaluation protocol split is invalid")
        object.__setattr__(
            self, "evaluator_version", _text(self.evaluator_version, "evaluator_version")
        )
        object.__setattr__(self, "procedure", _text(self.procedure, "evaluation procedure"))
        object.__setattr__(self, "seeds", _seed_sequence(self.seeds, "evaluation protocol seeds"))
        if not isinstance(self.repetitions, int) or isinstance(self.repetitions, bool):
            raise ValueError("evaluation protocol repetitions must be an integer")
        if self.repetitions < 1:
            raise ValueError("evaluation protocol repetitions must be positive")
        if self.purpose not in {"search", "finalization"}:
            raise ValueError("evaluation protocol purpose is invalid")
        if self.purpose == "search" and self.split == "test":
            raise ValueError("test split is protected from candidate-selection evaluations")

    def to_dict(self) -> dict[str, object]:
        return {
            "split": self.split,
            "evaluator_version": self.evaluator_version,
            "seeds": list(self.seeds),
            "repetitions": self.repetitions,
            "procedure": self.procedure,
            "purpose": self.purpose,
        }


@dataclass(frozen=True)
class EvaluationReceipt:
    candidate_id: str
    identity: ExperimentIdentity
    protocol: EvaluationProtocol
    inputs: Mapping[str, str]
    raw_measurements: tuple[Mapping[str, float], ...]
    aggregates: Mapping[str, float]
    hard_gates: tuple[HardGateResult, ...] = ()
    diagnostics: Mapping[str, object] = field(default_factory=dict)
    namespace: Literal["development", "research"] = "development"

    def __post_init__(self) -> None:
        object.__setattr__(self, "candidate_id", _identifier(self.candidate_id, "candidate_id"))
        if not isinstance(self.identity, ExperimentIdentity):
            raise ValueError("evaluation receipt identity is invalid")
        if not isinstance(self.protocol, EvaluationProtocol):
            raise ValueError("evaluation receipt protocol is invalid")
        if self.identity.seeds != self.protocol.seeds:
            raise ValueError("receipt identity seeds must match evaluation protocol seeds")
        if self.identity.repetitions != self.protocol.repetitions:
            raise ValueError("receipt identity repetitions must match evaluation protocol")
        object.__setattr__(self, "inputs", _string_mapping(self.inputs, "receipt inputs"))
        if not isinstance(self.raw_measurements, (tuple, list)):
            raise ValueError("raw measurements must be a sequence of mappings")
        raw_measurements: list[Mapping[str, float]] = []
        for index, measurement in enumerate(self.raw_measurements):
            raw_measurements.append(_numeric_mapping(measurement, f"raw_measurements[{index}]"))
        if len(raw_measurements) != self.protocol.repetitions:
            raise ValueError("raw measurement count must equal protocol repetitions")
        object.__setattr__(self, "raw_measurements", tuple(raw_measurements))
        object.__setattr__(
            self, "aggregates", _numeric_mapping(self.aggregates, "receipt aggregates")
        )
        if not isinstance(self.hard_gates, (tuple, list)) or not all(
            isinstance(gate, HardGateResult) for gate in self.hard_gates
        ):
            raise ValueError("receipt hard_gates must contain HardGateResult values")
        object.__setattr__(self, "hard_gates", tuple(self.hard_gates))
        object.__setattr__(
            self, "diagnostics", _json_mapping(self.diagnostics, "receipt diagnostics")
        )
        if self.namespace not in {"development", "research"}:
            raise ValueError("receipt namespace is invalid")

    @property
    def gates_passed(self) -> bool:
        return all(gate.passed for gate in self.hard_gates)

    def to_dict(self) -> dict[str, object]:
        return {
            "candidate_id": self.candidate_id,
            "namespace": self.namespace,
            "identity": self.identity.to_dict(),
            "protocol": self.protocol.to_dict(),
            "inputs": dict(sorted(self.inputs.items())),
            "raw_measurements": [_json_value(item) for item in self.raw_measurements],
            "aggregates": dict(sorted(self.aggregates.items())),
            "hard_gates": [_json_value(item) for item in self.hard_gates],
            "diagnostics": _json_value(self.diagnostics),
        }

    def save(self, path: str | Path) -> None:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(self.to_dict(), ensure_ascii=True, sort_keys=True, indent=2, allow_nan=False)
            + "\n",
            encoding="utf-8",
        )


@dataclass(frozen=True)
class SelectionDecision:
    status: Literal["accepted", "rejected", "inconclusive"]
    reason: str
    compared_to: str | None = None

    def __post_init__(self) -> None:
        if self.status not in {"accepted", "rejected", "inconclusive"}:
            raise ValueError("selection decision status is invalid")
        object.__setattr__(self, "reason", _text(self.reason, "selection decision reason"))
        if self.compared_to is not None:
            object.__setattr__(
                self, "compared_to", _identifier(self.compared_to, "selection compared_to")
            )

    def to_dict(self) -> dict[str, object]:
        return {
            "status": self.status,
            "reason": self.reason,
            "compared_to": self.compared_to,
        }


@dataclass(frozen=True)
class CandidateRecord:
    candidate_id: str
    namespace: Literal["development", "research"]
    identity: ExperimentIdentity
    parent: str | None = None
    hypothesis: Hypothesis | None = None
    prediction: Prediction | None = None
    change_scope: tuple[str, ...] = ()
    evaluation_protocol: EvaluationProtocol | None = None
    gates: tuple[HardGateResult, ...] = ()
    objectives: ObjectiveVector | None = None
    decision: SelectionDecision | None = None
    failure_class: str | None = None
    diagnostics: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "candidate_id", _identifier(self.candidate_id, "candidate_id"))
        if self.namespace not in {"development", "research"}:
            raise ValueError("candidate namespace is invalid")
        if not isinstance(self.identity, ExperimentIdentity):
            raise ValueError("candidate identity is invalid")
        if self.parent is not None:
            object.__setattr__(self, "parent", _identifier(self.parent, "candidate parent"))
        object.__setattr__(
            self, "change_scope", _string_sequence(self.change_scope, "candidate change_scope")
        )
        if self.evaluation_protocol is not None:
            if not isinstance(self.evaluation_protocol, EvaluationProtocol):
                raise ValueError("candidate evaluation_protocol is invalid")
            if self.identity.seeds != self.evaluation_protocol.seeds:
                raise ValueError("candidate identity seeds must match evaluation protocol seeds")
            if self.identity.repetitions != self.evaluation_protocol.repetitions:
                raise ValueError("candidate identity repetitions must match evaluation protocol")
        if not isinstance(self.gates, (tuple, list)) or not all(
            isinstance(gate, HardGateResult) for gate in self.gates
        ):
            raise ValueError("candidate gates must contain HardGateResult values")
        object.__setattr__(self, "gates", tuple(self.gates))
        for label, value, expected_type in (
            ("hypothesis", self.hypothesis, Hypothesis),
            ("prediction", self.prediction, Prediction),
            ("objectives", self.objectives, ObjectiveVector),
            ("decision", self.decision, SelectionDecision),
        ):
            if value is not None and not isinstance(value, expected_type):
                raise ValueError(f"candidate {label} is invalid")
        if self.failure_class is not None:
            object.__setattr__(
                self, "failure_class", _text(self.failure_class, "candidate failure_class")
            )
        object.__setattr__(
            self, "diagnostics", _json_mapping(self.diagnostics, "candidate diagnostics")
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "candidate_id": self.candidate_id,
            "namespace": self.namespace,
            "identity": self.identity.to_dict(),
            "parent": self.parent,
            "hypothesis": _json_value(self.hypothesis),
            "prediction": _json_value(self.prediction),
            "change_scope": list(self.change_scope),
            "evaluation_protocol": _json_value(self.evaluation_protocol),
            "gates": [_json_value(item) for item in self.gates],
            "objectives": _json_value(self.objectives),
            "decision": _json_value(self.decision),
            "failure_class": self.failure_class,
            "diagnostics": _json_value(self.diagnostics),
        }


@dataclass(frozen=True)
class LineageEntry:
    candidate_id: str
    namespace: Literal["development", "research"]
    parent: str | None
    decision: SelectionDecision
    receipt_path: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "candidate_id", _identifier(self.candidate_id, "lineage candidate_id")
        )
        if self.namespace not in {"development", "research"}:
            raise ValueError("lineage namespace is invalid")
        if self.parent is not None:
            object.__setattr__(self, "parent", _identifier(self.parent, "lineage parent"))
        if not isinstance(self.decision, SelectionDecision):
            raise ValueError("lineage decision is invalid")
        if self.receipt_path is not None:
            object.__setattr__(
                self, "receipt_path", _text(self.receipt_path, "lineage receipt_path")
            )

    def to_dict(self) -> dict[str, object]:
        return {
            "candidate_id": self.candidate_id,
            "namespace": self.namespace,
            "parent": self.parent,
            "decision": self.decision.to_dict(),
            "receipt_path": self.receipt_path,
        }
