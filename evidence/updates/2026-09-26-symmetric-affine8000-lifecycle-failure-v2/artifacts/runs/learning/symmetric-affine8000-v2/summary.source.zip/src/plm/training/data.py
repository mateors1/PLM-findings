"""Torch-light corpus datasets and deterministic batch collation."""

from __future__ import annotations

from collections.abc import Sequence

from plm.corpus.compiler import CorpusRecord
from plm.model.interfaces import ModelInput

__all__ = ["CorpusDataset", "collate_records"]


class CorpusDataset:
    """Minimal map-style dataset that keeps compiler records immutable."""

    def __init__(self, records: Sequence[CorpusRecord], *, max_seq_len: int | None = None) -> None:
        self.records = tuple(records)
        self.max_seq_len = max_seq_len
        if max_seq_len is not None and max_seq_len < 1:
            raise ValueError("max_seq_len must be positive")
        if any(len(record.input_ids) != len(record.labels) for record in self.records):
            raise ValueError("corpus record input_ids and labels must have equal lengths")
        if max_seq_len is not None and any(
            len(record.input_ids) > max_seq_len for record in self.records
        ):
            raise ValueError("corpus record exceeds configured max_seq_len")

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> CorpusRecord:
        return self.records[index]


def collate_records(batch: Sequence[CorpusRecord], *, pad_id: int) -> ModelInput:
    """Pad a batch while ensuring padding never contributes to loss."""

    import torch

    if not batch:
        raise ValueError("cannot collate an empty batch")
    lengths = [len(record.input_ids) for record in batch]
    if any(length < 1 for length in lengths):
        raise ValueError("corpus records must contain at least one token")
    if any(len(record.labels) != length for record, length in zip(batch, lengths, strict=True)):
        raise ValueError("corpus record input_ids and labels must have equal lengths")
    max_length = max(lengths)
    input_ids = torch.full((len(batch), max_length), pad_id, dtype=torch.long)
    labels = torch.full((len(batch), max_length), -100, dtype=torch.long)
    attention_mask = torch.zeros((len(batch), max_length), dtype=torch.bool)
    for row, record in enumerate(batch):
        length = lengths[row]
        input_ids[row, :length] = torch.tensor(record.input_ids, dtype=torch.long)
        labels[row, :length] = torch.tensor(record.labels, dtype=torch.long)
        attention_mask[row, :length] = True
    return ModelInput(input_ids=input_ids, labels=labels, attention_mask=attention_mask)
