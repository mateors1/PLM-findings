"""PLM — Protocolized Language Model.

A deliberately over-engineered, SOTA decoder-only model over a catalog/product
graph. See ``docs/architecture.md`` for the intended model stack and
``docs/protocol-spec.md`` for the (WIP) protocol.
"""

from __future__ import annotations

__version__ = "0.1.0"

__all__ = ["__version__"]
