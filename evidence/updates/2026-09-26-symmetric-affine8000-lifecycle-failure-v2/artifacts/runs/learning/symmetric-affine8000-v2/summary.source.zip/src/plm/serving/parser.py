"""Protocol state machine and constrained-output helpers."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import Any

from plm.protocol.tokenizer import CLASS_DIMENSION, CLASS_ENTITY, CLASS_MODE, Vocabulary

__all__ = [
    "ProtocolParseError",
    "ProtocolResponse",
    "allowed_token_ids",
    "constrain_logits",
    "parse_generated",
    "prompt_ids",
]


class ProtocolParseError(ValueError):
    """Raised when generated IDs violate the versioned protocol grammar."""


@dataclass(frozen=True)
class ProtocolResponse:
    subject: str
    dimension: str
    mode: str
    targets: tuple[str, ...]


def _tokens(values: Iterable[int | str], vocabulary: Vocabulary) -> list[str]:
    values_list = list(values)
    if any(
        isinstance(value, bool)
        or not isinstance(value, (int, str))
        or (isinstance(value, int) and not 0 <= value < len(vocabulary))
        for value in values_list
    ):
        raise ProtocolParseError("token IDs must be in-range integers or token strings")
    return [
        vocabulary.token_of(value) if isinstance(value, int) else value for value in values_list
    ]


def parse_generated(values: Iterable[int | str], vocabulary: Vocabulary) -> ProtocolResponse:
    """Parse and validate ``BOS SUBJECT DIM SAME ANSWER TARGET+ EOS``."""

    tokens = _tokens(values, vocabulary)
    if len(tokens) < 7:
        raise ProtocolParseError("generated response is shorter than the protocol grammar")
    if tokens[0] != "BOS":
        raise ProtocolParseError("response must start with BOS")
    if vocabulary.class_of(tokens[1]) != CLASS_ENTITY:
        raise ProtocolParseError("subject must be an entity token")
    if vocabulary.class_of(tokens[2]) != CLASS_DIMENSION:
        raise ProtocolParseError("dimension must be a protocol dimension token")
    if tokens[3] != "SAME" or vocabulary.class_of(tokens[3]) != CLASS_MODE:
        raise ProtocolParseError("v1 response mode must be SAME")
    if tokens[4] != "ANSWER":
        raise ProtocolParseError("ANSWER is the required completion delimiter")
    if tokens[-1] != "EOS":
        raise ProtocolParseError("response must terminate with EOS")
    targets = tokens[5:-1]
    if not targets or any(vocabulary.class_of(token) != CLASS_ENTITY for token in targets):
        raise ProtocolParseError("response must contain one or more entity targets")
    return ProtocolResponse(tokens[1], tokens[2], tokens[3], tuple(targets))


def prompt_ids(subject: str, dimension: str, vocabulary: Vocabulary) -> tuple[int, ...]:
    """Encode the prompt prefix through ``ANSWER`` for next-token generation."""

    return tuple(vocabulary.encode(["BOS", subject, dimension, "SAME", "ANSWER"]))


def allowed_token_ids(prefix: Sequence[int | str], vocabulary: Vocabulary) -> tuple[int, ...]:
    """Return the legal next-token IDs for a partial generated response."""

    try:
        tokens = _tokens(prefix, vocabulary)
        return _allowed_tokens(tokens, vocabulary)
    except (KeyError, ProtocolParseError):
        return ()


def _allowed_tokens(tokens: list[str], vocabulary: Vocabulary) -> tuple[int, ...]:
    # Validate the entire prefix, and enumerate steering classes only while
    # selecting them. Answer generation must not rescan all vocabulary classes.
    if not tokens:
        return (vocabulary.bos_id,)
    if tokens[0] != "BOS":
        return ()
    if len(tokens) == 1:
        return tuple(vocabulary.entity_ids())
    if vocabulary.class_of(tokens[1]) != CLASS_ENTITY:
        return ()
    if len(tokens) == 2:
        return tuple(i for i in range(len(vocabulary)) if vocabulary.class_of(i) == CLASS_DIMENSION)
    if vocabulary.class_of(tokens[2]) != CLASS_DIMENSION:
        return ()
    if len(tokens) == 3:
        return (vocabulary.id_of("SAME"),)
    if tokens[3] != "SAME" or vocabulary.class_of(tokens[3]) != CLASS_MODE:
        return ()
    if len(tokens) == 4:
        return (vocabulary.answer_id,)
    if tokens[4] != "ANSWER":
        return ()
    if len(tokens) == 5:
        return tuple(vocabulary.entity_ids())
    if all(vocabulary.class_of(token) == CLASS_ENTITY for token in tokens[5:]):
        return (*vocabulary.entity_ids(), vocabulary.eos_id)
    return ()


def constrain_logits(logits: Any, prefix: Sequence[int | str], vocabulary: Vocabulary) -> Any:
    """Mask a next-token logits vector/batch using the protocol state machine."""

    import torch

    legal = allowed_token_ids(prefix, vocabulary)
    if not legal:
        raise ProtocolParseError("no legal next token for the generated prefix")
    if logits.shape[-1] != len(vocabulary):
        raise ValueError("logits vocabulary dimension does not match vocabulary")
    mask = torch.full_like(logits, -float("inf"))
    mask[..., list(legal)] = logits[..., list(legal)]
    return mask
