"""Direct token->ID vocabulary.

The PLM tokenizer is a direct, bijective map — one protocol token (or product
SKU) is exactly one integer ID. There is no subword segmentation and no trained
tokenizer: SKUs are opaque atoms, and every protocol word is a fixed symbol.

IDs are laid out in **append-only reserved bands** so the numbering is stable as
the vocabulary grows across versions. The number line carries no meaning on its
own — the class of every token is recorded explicitly (``classes``) so callers
look up a token's role instead of doing arithmetic on its ID.

    band        ids          contents
    ----------- ------------ -------------------------------------------------
    core        0   .. 31    specials + control (PAD=0, BOS, EOS, UNK, SEP, ANSWER)
    steering    32  .. 127   dimensions + modes (TYPE, COLOR, SAME, ...)
    reserved    128 .. 1023  future content classes (visible labels, taxonomy)
    entity      1024 ..      product SKUs (PKM_*), pure append, sorted per build

Entities are pinned at ``ENTITY_BASE`` so growth of the small control plane can
never renumber them — entity IDs, which appear in every corpus record, are the
ones that must stay put. Reserved gaps are materialized as ``<reserved_N>``
placeholder tokens so the serialized vocab stays a dense list (index == ID) and
the content hash stays simple.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable, Sequence
from pathlib import Path

__all__ = [
    "CLASS_DIMENSION",
    "CLASS_ENTITY",
    "CLASS_MODE",
    "CLASS_RESERVED",
    "CLASS_SPECIAL",
    "CORE_BAND_END",
    "DEFAULT_DIMENSIONS",
    "DEFAULT_MODES",
    "DEFAULT_SPECIALS",
    "DEFAULT_VERSION",
    "ENTITY_BASE",
    "STEERING_BAND_END",
    "UnknownTokenError",
    "Vocabulary",
]

# -- band boundaries (append-only; do not shrink or reorder) -----------------
CORE_BAND_END = 32  # ids 0..31   specials + control
STEERING_BAND_END = 128  # ids 32..127 dimensions + modes
ENTITY_BASE = 1024  # ids 1024..  entities; 128..1023 reserved for future labels

# -- token classes (the manifest, not the arithmetic) -----------------------
CLASS_SPECIAL = "special"
CLASS_DIMENSION = "dimension"
CLASS_MODE = "mode"
CLASS_ENTITY = "entity"
CLASS_RESERVED = "reserved"

# Order is significant: specials occupy the lowest, permanently-fixed IDs.
# PAD must be id 0; UNK is a serve-time safety token (never emitted at compile).
DEFAULT_SPECIALS: tuple[str, ...] = ("PAD", "BOS", "EOS", "UNK", "SEP", "ANSWER")

# v1 protocol token sets. TEMP home — these move to a versioned protocol config
# (configs/protocol/pokemon_v1.*) when the protocol layer lands.
DEFAULT_DIMENSIONS: tuple[str, ...] = ("TYPE", "COLOR")
DEFAULT_MODES: tuple[str, ...] = ("SAME",)

DEFAULT_VERSION = "pokemon-v1"

_FILE_SCHEMA_VERSION = 2
_REQUIRED_SPECIALS = ("PAD", "BOS", "EOS", "UNK", "ANSWER")


class UnknownTokenError(KeyError):
    """Raised when encoding a token absent from the vocabulary (fail-closed)."""


def _dedup_preserve(items: Iterable[str]) -> list[str]:
    """Deduplicate while preserving first-seen order (append-only friendly)."""
    return list(dict.fromkeys(items))


def _fill_reserved(tokens: list[str], classes: list[str], upto: int) -> None:
    """Pad ``tokens``/``classes`` with ``<reserved_N>`` placeholders up to ``upto``."""
    while len(tokens) < upto:
        tokens.append(f"<reserved_{len(tokens)}>")
        classes.append(CLASS_RESERVED)


class Vocabulary:
    """A frozen, order-stable token<->ID mapping with per-token class metadata."""

    def __init__(
        self,
        tokens: Sequence[str],
        classes: Sequence[str],
        *,
        version: str = DEFAULT_VERSION,
    ) -> None:
        if len(tokens) != len(classes):
            raise ValueError("tokens and classes must have equal length")
        seen: dict[str, int] = {}
        for tok in tokens:
            if tok in seen:
                raise ValueError(f"duplicate token in vocabulary: {tok!r}")
            seen[tok] = len(seen)
        self._token_to_id: dict[str, int] = seen
        self._id_to_token: list[str] = list(tokens)
        self._classes: list[str] = list(classes)
        self._version = version

        for req in _REQUIRED_SPECIALS:
            if req not in seen:
                raise ValueError(f"vocabulary missing required special: {req!r}")
        if self._id_to_token[0] != "PAD":
            raise ValueError("PAD must be token id 0")

    # -- construction --------------------------------------------------------
    @classmethod
    def build(
        cls,
        entities: Iterable[str],
        *,
        dimensions: Sequence[str] = DEFAULT_DIMENSIONS,
        modes: Sequence[str] = DEFAULT_MODES,
        specials: Sequence[str] = DEFAULT_SPECIALS,
        version: str = DEFAULT_VERSION,
    ) -> Vocabulary:
        """Backward-compatible alias for :meth:`build_fresh`."""

        return cls.build_fresh(
            entities,
            dimensions=dimensions,
            modes=modes,
            specials=specials,
            version=version,
        )

    @classmethod
    def build_fresh(
        cls,
        entities: Iterable[str],
        *,
        dimensions: Sequence[str] = DEFAULT_DIMENSIONS,
        modes: Sequence[str] = DEFAULT_MODES,
        specials: Sequence[str] = DEFAULT_SPECIALS,
        version: str = DEFAULT_VERSION,
    ) -> Vocabulary:
        """Build a banded vocabulary.

        ``entities`` are sorted (a fixed set yields a fixed hash); ``dimensions``
        and ``modes`` keep their given order (their order is part of the protocol
        definition). Predicates are intentionally NOT accepted — they are
        graph-internal and never model-visible.
        """
        specials = tuple(specials)
        dims = _dedup_preserve(dimensions)
        mds = _dedup_preserve(modes)
        ents = sorted(dict.fromkeys(entities))

        if len(specials) > CORE_BAND_END:
            raise ValueError(f"too many specials for the core band (max {CORE_BAND_END})")
        steering_capacity = STEERING_BAND_END - CORE_BAND_END
        if len(dims) + len(mds) > steering_capacity:
            raise ValueError(
                f"too many dimensions+modes for the steering band (max {steering_capacity})"
            )
        collisions = (set(specials) | set(dims) | set(mds)) & set(ents)
        if collisions:
            raise ValueError(f"entities collide with protocol tokens: {sorted(collisions)}")

        tokens: list[str] = []
        classes: list[str] = []
        for s in specials:
            tokens.append(s)
            classes.append(CLASS_SPECIAL)
        _fill_reserved(tokens, classes, CORE_BAND_END)
        for d in dims:
            tokens.append(d)
            classes.append(CLASS_DIMENSION)
        for m in mds:
            tokens.append(m)
            classes.append(CLASS_MODE)
        _fill_reserved(tokens, classes, STEERING_BAND_END)
        _fill_reserved(tokens, classes, ENTITY_BASE)
        for e in ents:
            tokens.append(e)
            classes.append(CLASS_ENTITY)

        return cls(tokens, classes, version=version)

    def extend(
        self,
        additions: Iterable[str],
        *,
        version: str | None = None,
    ) -> Vocabulary:
        """Append new entity tokens without changing any existing ID.

        This method is intentionally separate from fresh construction: sorting
        the complete entity set would silently renumber trained checkpoints.
        Existing entities are idempotent; a token already used by the control
        plane is rejected rather than reclassified.
        """

        new_entities = sorted(dict.fromkeys(str(item) for item in additions))
        tokens = list(self._id_to_token)
        classes = list(self._classes)
        for entity in new_entities:
            existing_id = self._token_to_id.get(entity)
            if existing_id is not None:
                if self._classes[existing_id] != CLASS_ENTITY:
                    raise ValueError(f"extension collides with non-entity token: {entity!r}")
                continue
            tokens.append(entity)
            classes.append(CLASS_ENTITY)
        return Vocabulary(tokens, classes, version=self._version if version is None else version)

    # -- core map ------------------------------------------------------------
    def __len__(self) -> int:
        return len(self._id_to_token)

    def __contains__(self, token: str) -> bool:
        return token in self._token_to_id

    def id_of(self, token: str) -> int:
        """Strict lookup — raises :class:`UnknownTokenError` on an unknown token."""
        i = self._token_to_id.get(token)
        if i is None:
            raise UnknownTokenError(token)
        return i

    def token_of(self, token_id: int) -> str:
        return self._id_to_token[token_id]

    def encode(self, tokens: Iterable[str], *, strict: bool = True) -> list[int]:
        """Encode tokens to IDs. ``strict`` (default) fails closed on any unknown
        token — use it for corpus compilation. ``strict=False`` maps unknowns to
        UNK, for serve-time robustness only."""
        out: list[int] = []
        for t in tokens:
            i = self._token_to_id.get(t)
            if i is None:
                if strict:
                    raise UnknownTokenError(t)
                i = self.unk_id
            out.append(i)
        return out

    def decode(self, ids: Iterable[int]) -> list[str]:
        return [self._id_to_token[i] for i in ids]

    # -- class metadata & named IDs -----------------------------------------
    def class_of(self, token_or_id: int | str) -> str:
        idx = token_or_id if isinstance(token_or_id, int) else self.id_of(token_or_id)
        return self._classes[idx]

    def entity_ids(self) -> list[int]:
        """IDs of the emittable entity tokens (the model's legal output set)."""
        return [i for i, c in enumerate(self._classes) if c == CLASS_ENTITY]

    @property
    def unk_id(self) -> int:
        return self._token_to_id["UNK"]

    @property
    def pad_id(self) -> int:
        return self._token_to_id["PAD"]

    @property
    def bos_id(self) -> int:
        return self._token_to_id["BOS"]

    @property
    def eos_id(self) -> int:
        return self._token_to_id["EOS"]

    @property
    def sep_id(self) -> int:
        return self._token_to_id["SEP"]

    @property
    def answer_id(self) -> int:
        return self._token_to_id["ANSWER"]

    @property
    def version(self) -> str:
        return self._version

    # -- persistence & identity ---------------------------------------------
    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": _FILE_SCHEMA_VERSION,
            "version": self._version,
            "tokens": self._id_to_token,
            "classes": self._classes,
        }

    def content_hash(self) -> str:
        """Stable SHA-256 over the canonical (version, tokens, classes)."""
        payload = json.dumps(self.to_dict(), ensure_ascii=True, sort_keys=True)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def save(self, path: str | Path) -> str:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps(self.to_dict(), ensure_ascii=True, indent=2),
            encoding="utf-8",
        )
        return self.content_hash()

    @classmethod
    def load(cls, path: str | Path) -> Vocabulary:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        version = data.get("schema_version")
        if version != _FILE_SCHEMA_VERSION:
            raise ValueError(f"unsupported vocabulary schema_version: {version!r}")
        tokens = data["tokens"]
        classes = data["classes"]
        if not isinstance(tokens, list) or not isinstance(classes, list):
            raise ValueError("malformed vocabulary: 'tokens'/'classes' must be lists")
        return cls(
            [str(t) for t in tokens],
            [str(c) for c in classes],
            version=str(data.get("version", DEFAULT_VERSION)),
        )
