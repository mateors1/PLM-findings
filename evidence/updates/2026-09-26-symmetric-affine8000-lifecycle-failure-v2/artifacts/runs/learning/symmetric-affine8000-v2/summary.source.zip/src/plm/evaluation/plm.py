"""PLM scorer adapter and split-aware ranking evaluators."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Any

from plm.corpus.compiler import CorpusRecord
from plm.evaluation.ranking import RankingMetrics, Scorer, evaluate_ranking
from plm.experimentation.firewall import assert_candidate_split, assert_final_test_split
from plm.experimentation.measurement import MeasurementSummary, summarize_measurements
from plm.protocol.tokenizer import Vocabulary

__all__ = [
    "PLMScorer",
    "RepeatedEvaluation",
    "evaluate_final_test",
    "evaluate_plm",
    "evaluate_repeated",
    "evaluate_validation",
]


@dataclass(frozen=True)
class PLMEvaluation:
    split: str
    metrics: RankingMetrics
    query_count: int
    candidate_count: int
    protocol_valid: bool | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "split": self.split,
            "query_count": self.query_count,
            "candidate_count": self.candidate_count,
            "protocol_valid": self.protocol_valid,
            "metrics": {
                "mrr": self.metrics.mrr,
                "hits_at": self.metrics.hits_at,
                "map": self.metrics.map,
            },
        }


@dataclass(frozen=True)
class RepeatedEvaluation:
    evaluations: tuple[PLMEvaluation, ...]
    mrr: MeasurementSummary
    map: MeasurementSummary

    def to_dict(self) -> dict[str, object]:
        return {
            "repetitions": len(self.evaluations),
            "evaluations": [evaluation.to_dict() for evaluation in self.evaluations],
            "mrr": self.mrr.to_dict(),
            "map": self.map.to_dict(),
        }


class PLMScorer:
    """Rank candidates by the next-token logit after a protocol prompt."""

    def __init__(self, model: Any, vocabulary: Vocabulary, *, device: str | Any = "cpu") -> None:
        try:
            import torch
        except ImportError as exc:
            raise ImportError("PLM scoring requires the optional torch dependency") from exc
        self.torch = torch
        self.model = model.to(device)
        self.device = device
        self.vocabulary = vocabulary
        self.model.eval()
        self._cached_query: tuple[str, str] | None = None
        self._cached_logits: list[float] = []

    def score(self, query: CorpusRecord, candidate: str) -> float:
        candidate_id = self.vocabulary.id_of(candidate)
        key = (query.subject, query.dimension)
        if key == self._cached_query:
            return self._cached_logits[candidate_id]
        prefix = ["BOS", query.subject, query.dimension, "SAME", "ANSWER"]
        input_ids = self.torch.tensor(
            [self.vocabulary.encode(prefix)], dtype=self.torch.long, device=self.device
        )
        with self.torch.no_grad():
            output = self.model(input_ids)
            logits = output.logits if hasattr(output, "logits") else output
        self._cached_logits = logits[0, -1].detach().float().cpu().tolist()
        self._cached_query = key
        return self._cached_logits[candidate_id]


def evaluate_plm(
    records: Sequence[CorpusRecord],
    candidates: Sequence[str],
    scorer: Scorer,
    *,
    split: str,
) -> PLMEvaluation:
    """Evaluate with the same multi-positive ranking semantics as baselines."""

    metrics = evaluate_ranking(records, candidates, scorer)
    return PLMEvaluation(split, metrics, len(records), len(candidates))


def evaluate_validation(
    records: Sequence[CorpusRecord],
    candidates: Sequence[str],
    scorer: Scorer,
) -> PLMEvaluation:
    """Adaptive-search-visible validation evaluation."""

    split = assert_candidate_split("validation")
    return evaluate_plm(records, candidates, scorer, split=split)


def evaluate_final_test(
    records: Sequence[CorpusRecord],
    candidates: Sequence[str],
    scorer: Scorer,
) -> PLMEvaluation:
    """Explicit finalization evaluation on the protected test split."""

    split = assert_final_test_split("test")
    return evaluate_plm(records, candidates, scorer, split=split)


def evaluate_repeated(
    records: Sequence[CorpusRecord],
    candidates: Sequence[str],
    scorer_factory: Callable[[int], Scorer],
    *,
    seeds: Sequence[int],
    split: str = "validation",
) -> RepeatedEvaluation:
    """Run repeated validation scorers and expose variance, not only a peak."""

    assert_candidate_split(split)
    if not seeds:
        raise ValueError("repeated evaluation requires at least one seed")
    evaluations = tuple(
        evaluate_plm(records, candidates, scorer_factory(seed), split=split) for seed in seeds
    )
    return RepeatedEvaluation(
        evaluations,
        summarize_measurements(evaluation.metrics.mrr for evaluation in evaluations),
        summarize_measurements(evaluation.metrics.map for evaluation in evaluations),
    )
