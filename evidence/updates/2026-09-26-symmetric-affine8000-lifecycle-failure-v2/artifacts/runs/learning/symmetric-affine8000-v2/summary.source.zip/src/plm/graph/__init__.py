"""Product graph: SQLite schema, repository, and validation.

Nodes are catalog products (keyed by SKU), edges are typed relations between
them. The schema is protocol-agnostic — the relation *semantics* live in the
protocol; here we only store structure and enforce integrity.
"""

from __future__ import annotations

from plm.graph.importers import POKEAPI_SOURCE_REVISION
from plm.graph.repository import GraphRepository
from plm.graph.schema import SCHEMA_VERSION, ValidationReport, init_graph, validate_graph

__all__ = [
    "POKEAPI_SOURCE_REVISION",
    "SCHEMA_VERSION",
    "GraphRepository",
    "ValidationReport",
    "init_graph",
    "validate_graph",
]
