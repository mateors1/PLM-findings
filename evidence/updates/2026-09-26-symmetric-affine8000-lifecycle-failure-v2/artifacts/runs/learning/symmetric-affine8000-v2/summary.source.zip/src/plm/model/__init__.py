"""The over-engineered decoder-only PLM (Phase C reference path).

The architecture is intentionally maximalist — see ``docs/architecture.md`` and
:class:`plm.config.ModelConfig` for the full knob surface. This package holds no
top-level torch import so the core/Phase-A environment stays torch-free; the
the Torch-backed implementation is loaded through the optional ``training`` group.
"""

from __future__ import annotations

from plm.model.architecture import build_model
from plm.model.interfaces import DecodeOutput, KVCache, ModelInput, ModelOutput
from plm.model.synthetic import SyntheticOverfitReport, run_synthetic_overfit

__all__ = [
    "DecodeOutput",
    "KVCache",
    "ModelInput",
    "ModelOutput",
    "SyntheticOverfitReport",
    "build_model",
    "run_synthetic_overfit",
]
