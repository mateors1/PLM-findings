"""Explicit split visibility rules for adaptive and final evaluations."""

from __future__ import annotations

from typing import Literal

__all__ = ["TestFirewallError", "assert_candidate_split", "assert_final_test_split"]


class TestFirewallError(ValueError):
    """Raised when a candidate-selection path tries to observe final test data."""

    __test__ = False


def assert_candidate_split(split: str) -> Literal["train", "validation"]:
    normalized = split.strip().lower()
    if normalized == "test":
        raise TestFirewallError("test split is unavailable to candidate-selection evaluations")
    if normalized not in {"train", "validation"}:
        raise ValueError("candidate evaluations must use train or validation")
    return normalized  # type: ignore[return-value]


def assert_final_test_split(split: str) -> Literal["test"]:
    if split.strip().lower() != "test":
        raise ValueError("finalization evaluations must use the protected test split")
    return "test"
