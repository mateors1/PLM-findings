"""Deterministic graph/heuristic baselines for held-out relation ranking.

Phase B. The baseline must be *apples-to-apples* with the PLM's task: a
knowledge-graph link-prediction model (e.g. ComplEx/RotatE) or a sequential
item recommender (SASRec-style), not a text/heuristic strawman. On a small
graph these are strong; the PLM's value is the protocol/serving story as much
as raw ranking.
"""

from __future__ import annotations

from plm.baselines.complex import ComplExScorer
from plm.baselines.oracle import OracleScorer
from plm.baselines.popularity import PopularityScorer

__all__ = ["ComplExScorer", "OracleScorer", "PopularityScorer"]
