"""Measure complete generated responses independently of first-token ranking."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import asdict, dataclass

from plm.corpus.compiler import CorpusRecord
from plm.serving.generation import GenerationResult

__all__ = ["GenerationMetrics", "evaluate_generation"]


@dataclass(frozen=True)
class GenerationMetrics:
    query_count: int
    precision: float
    recall: float
    f1: float
    exact_set_accuracy: float
    exact_sequence_accuracy: float
    protocol_valid_rate: float
    termination_rate: float
    duplicate_query_rate: float
    self_return_rate: float
    mean_target_count: float

    def to_dict(self) -> dict[str, float | int]:
        return asdict(self)


def evaluate_generation(
    records: Sequence[CorpusRecord],
    generate: Callable[[CorpusRecord], GenerationResult],
) -> GenerationMetrics:
    """Macro-average per-query metrics; never infer validity from the scorer.

    Duplicates count in the precision denominator but only distinct matches
    receive credit. Exact set/sequence require valid syntax and termination.
    """
    if not records:
        raise ValueError("generation evaluation requires at least one query")
    totals = [0.0] * 10
    for record in records:
        expected = set(record.targets)
        if not expected:
            raise ValueError("generation evaluation requires nonempty oracle targets")
        result = generate(record)
        predicted = set(result.targets)
        matches = len(expected & predicted)
        precision = matches / len(result.targets) if result.targets else 0.0
        recall = matches / len(expected)
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        unique = len(predicted) == len(result.targets)
        complete = result.protocol_valid and result.terminated
        values = (
            precision,
            recall,
            f1,
            float(complete and unique and predicted == expected),
            float(complete and result.targets == record.targets),
            float(result.protocol_valid),
            float(result.terminated),
            float(not unique),
            float(record.subject in predicted),
            float(len(result.targets)),
        )
        totals = [total + value for total, value in zip(totals, values, strict=True)]
    return GenerationMetrics(len(records), *(value / len(records) for value in totals))
