"""Protocol grammar, parser, and the direct token→ID tokenizer.

The protocol serialization is WIP (see ``docs/protocol-spec.md``). What is
stable regardless of the final grammar is the tokenizer contract: a *direct*,
bijective token↔ID mapping (no subword/BPE), because product SKUs are opaque
atoms with no linguistic content.
"""

from __future__ import annotations

from plm.protocol.config import ProtocolSpec, UnsupportedProtocolError, load_protocol
from plm.protocol.tokenizer import (
    DEFAULT_DIMENSIONS,
    DEFAULT_MODES,
    DEFAULT_SPECIALS,
    ENTITY_BASE,
    UnknownTokenError,
    Vocabulary,
)

__all__ = [
    "DEFAULT_DIMENSIONS",
    "DEFAULT_MODES",
    "DEFAULT_SPECIALS",
    "ENTITY_BASE",
    "ProtocolSpec",
    "UnknownTokenError",
    "UnsupportedProtocolError",
    "Vocabulary",
    "load_protocol",
]
