"""Typed configuration schema (Pydantic v2).

Configuration controls every experiment; Python code provides behavior, never
hidden experiment parameters. The ``model`` block is intentionally maximalist —
the PLM is over-engineered by design, so every SOTA knob has a validated home.
The Phase-C reference implements a deliberately smaller subset and rejects
unsupported enabled switches at the model boundary.

Hydra YAML under ``configs/`` is the committed source of truth; it is resolved
to a plain dict and validated through :func:`validate_config`.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

__all__ = [
    "AttentionConfig",
    "BaselineConfig",
    "ComplExConfig",
    "DataConfig",
    "EvalConfig",
    "MoEConfig",
    "ModelConfig",
    "OptimizerConfig",
    "PathsConfig",
    "RoPEConfig",
    "RootConfig",
    "SchedulerConfig",
    "TrainConfig",
    "validate_config",
]


class _Strict(BaseModel):
    """Base model that forbids unknown keys (typo protection for configs)."""

    model_config = ConfigDict(extra="forbid")


class PathsConfig(_Strict):
    data_root: str = "data"
    run_root: str = "runs"


class RoPEConfig(_Strict):
    theta: float = 10_000.0
    scaling_type: Literal["none", "linear", "ntk", "yarn"] = "none"
    scaling_factor: float = 1.0
    original_max_seq_len: int | None = None


class MoEConfig(_Strict):
    enabled: bool = False
    num_experts: int = Field(default=8, gt=0)
    experts_per_token: int = Field(default=2, gt=0)
    aux_loss_weight: float = Field(default=0.01, ge=0)
    shared_experts: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def _check_topk(self) -> MoEConfig:
        if self.enabled and not (1 <= self.experts_per_token <= self.num_experts):
            raise ValueError("experts_per_token must be in [1, num_experts]")
        return self


class AttentionConfig(_Strict):
    backend: Literal["sdpa", "flash", "eager"] = "sdpa"
    qk_norm: bool = True
    causal: bool = True
    sliding_window: int | None = None
    logit_soft_cap: float | None = None
    dropout: float = 0.0


class ModelConfig(_Strict):
    """The over-engineered decoder-only stack (RMSNorm + RoPE + SwiGLU + GQA)."""

    name: str = "tiny_decoder"

    # Vocab & context
    vocab_size: int = Field(default=1024, gt=0)
    max_seq_len: int = Field(default=512, gt=0)

    # Shape
    dim: int = Field(default=256, gt=0)
    n_layers: int = Field(default=8, gt=0)
    n_heads: int = Field(default=8, gt=0)
    n_kv_heads: int = Field(default=2, gt=0)  # GQA: ==n_heads → MHA, ==1 → MQA
    head_dim: int | None = None  # defaults to dim // n_heads

    # Normalization
    norm: Literal["rmsnorm", "layernorm"] = "rmsnorm"
    norm_eps: float = 1.0e-5

    # Feed-forward (SwiGLU): hidden ≈ dim * multiple, rounded to `multiple_of`
    activation: Literal["swiglu", "geglu", "gelu"] = "swiglu"
    ffn_multiple: float = 8.0 / 3.0
    ffn_multiple_of: int = 256

    # Position
    rope: RoPEConfig = Field(default_factory=RoPEConfig)

    # Attention
    attention: AttentionConfig = Field(default_factory=AttentionConfig)

    # Mixture of Experts (optional)
    moe: MoEConfig = Field(default_factory=MoEConfig)

    # Regularization / tying / init
    resid_dropout: float = 0.0
    embed_dropout: float = 0.0
    tie_embeddings: bool = True
    init_std: float = 0.02
    use_mup: bool = False  # muParametrization for width transfer

    # Numerics / memory
    dtype: Literal["bf16", "fp16", "fp32"] = "bf16"  # bf16 native on Blackwell
    gradient_checkpointing: bool = False
    z_loss_weight: float = 0.0  # output logit z-loss for stability
    first_target_loss_weight: float = Field(default=1.0, gt=0.0, allow_inf_nan=False)
    prompt_set_loss_weight: float = Field(default=0.0, ge=0.0, allow_inf_nan=False)
    symmetric_relation_loss_weight: float = Field(default=0.0, ge=0.0, allow_inf_nan=False)
    continuation_set_loss_weight: float = Field(
        default=0.0, ge=0.0, allow_inf_nan=False, strict=True
    )

    @field_validator("n_heads", "n_kv_heads")
    @classmethod
    def _positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("head counts must be positive")
        return v

    @model_validator(mode="after")
    def _check_shapes(self) -> ModelConfig:
        if self.n_heads % self.n_kv_heads != 0:
            raise ValueError(
                f"n_heads ({self.n_heads}) must be divisible by "
                f"n_kv_heads ({self.n_kv_heads}) for GQA"
            )
        if self.head_dim is None and self.dim % self.n_heads != 0:
            raise ValueError(
                f"dim ({self.dim}) must be divisible by n_heads ({self.n_heads}) "
                "when head_dim is not set explicitly"
            )
        if self.attention.sliding_window is not None and self.attention.sliding_window <= 0:
            raise ValueError("sliding_window must be positive when set")
        if self.continuation_set_loss_weight and not self.prompt_set_loss_weight:
            raise ValueError("continuation set supervision requires prompt_set_loss_weight > 0")
        return self

    @property
    def kv_groups(self) -> int:
        return self.n_heads // self.n_kv_heads

    @property
    def resolved_head_dim(self) -> int:
        return self.head_dim if self.head_dim is not None else self.dim // self.n_heads

    @property
    def ffn_hidden_dim(self) -> int:
        raw = int(self.dim * self.ffn_multiple)
        m = self.ffn_multiple_of
        return ((raw + m - 1) // m) * m


class OptimizerConfig(_Strict):
    name: Literal["adamw", "adamw_fused", "lion"] = "adamw_fused"
    lr: float = 3.0e-4
    weight_decay: float = 0.1
    betas: tuple[float, float] = (0.9, 0.95)
    eps: float = 1.0e-8
    # Exclude norm/bias/embedding params from weight decay.
    decay_excludes_norm_and_bias: bool = True


class ComplExConfig(_Strict):
    """Explicit knobs for the optional knowledge-graph baseline."""

    dimension: int = Field(default=32, gt=0)
    epochs: int = Field(default=100, gt=0)
    learning_rate: float = Field(default=0.01, gt=0.0)
    negative_samples: int = Field(default=1, gt=0)
    regularization: float = Field(default=0.0, ge=0.0)
    batch_size: int = Field(default=32, gt=0)


class BaselineConfig(_Strict):
    complex: ComplExConfig = Field(default_factory=ComplExConfig)


class SchedulerConfig(_Strict):
    name: Literal["cosine", "linear", "constant", "wsd"] = "cosine"
    warmup_steps: int = 200
    min_lr_ratio: float = 0.1


class TrainConfig(_Strict):
    name: str = "local_cuda"
    precision: Literal["bf16", "fp16", "fp32"] = "bf16"

    max_steps: int = 2_000
    batch_size: int = 32
    seq_len: int = 512
    grad_accum_steps: int = 1
    grad_clip_norm: float | None = 1.0

    optimizer: OptimizerConfig = Field(default_factory=OptimizerConfig)
    scheduler: SchedulerConfig = Field(default_factory=SchedulerConfig)

    # SOTA switches
    compile: bool = False  # deferred until a compiled-checkpoint contract exists
    ema_decay: float | None = None

    # DataLoader
    num_workers: int = 4
    pin_memory: bool = True

    # Cadence
    eval_every: int = 200
    checkpoint_every: int = 500

    @model_validator(mode="after")
    def _check(self) -> TrainConfig:
        if self.grad_accum_steps < 1:
            raise ValueError("grad_accum_steps must be >= 1")
        if not 0.0 <= self.scheduler.min_lr_ratio <= 1.0:
            raise ValueError("min_lr_ratio must be in [0, 1]")
        return self


class DataConfig(_Strict):
    name: str = "pokemon_v1"
    # Explicit versions travel with every corpus manifest and checkpoint.
    protocol_version: str = "0.0.0-dev"
    tokenizer_version: str = "0.0.0-dev"

    graph_db: str = "data/sqlite/pokemon.db"
    corpus_manifest: str | None = None

    validation_query_fraction: float = 0.1
    test_query_fraction: float = 0.1
    # Accepted only as a migration bridge for Phase-B callers. New configs
    # must declare validation and test fractions independently.
    held_out_query_fraction: float | None = None
    split_seed: int = 1729

    @field_validator("validation_query_fraction", "test_query_fraction")
    @classmethod
    def _fraction(cls, v: float) -> float:
        if not 0.0 <= v < 1.0:
            raise ValueError("query fractions must be in [0, 1)")
        return v

    @field_validator("held_out_query_fraction")
    @classmethod
    def _legacy_fraction(cls, v: float | None) -> float | None:
        if v is not None and not 0.0 <= v < 1.0:
            raise ValueError("held_out_query_fraction must be in [0, 1)")
        return v

    @model_validator(mode="after")
    def _check_split(self) -> DataConfig:
        if self.held_out_query_fraction is not None:
            if self.validation_query_fraction != 0.1 or self.test_query_fraction != 0.1:
                raise ValueError(
                    "held_out_query_fraction cannot be combined with explicit query fractions"
                )
            half = self.held_out_query_fraction / 2.0
            object.__setattr__(self, "validation_query_fraction", half)
            object.__setattr__(self, "test_query_fraction", half)
        if self.validation_query_fraction + self.test_query_fraction >= 1.0:
            raise ValueError("validation_query_fraction + test_query_fraction must be less than 1")
        return self


def _default_metrics() -> list[Literal["mrr", "hits", "map"]]:
    return ["mrr", "hits"]


class EvalConfig(_Strict):
    name: str = "ranking"
    metrics: list[Literal["mrr", "hits", "map"]] = Field(default_factory=_default_metrics)
    hits_at: list[int] = Field(default_factory=lambda: [1, 3, 10])
    filtered: bool = True  # filtered ranking (exclude known-true from candidates)
    max_new_tokens: int = Field(default=507, gt=0)
    constrained_decoding: bool = True
    use_kv_cache: bool = False
    prevent_repeated_targets: bool = False
    generation_batch_size: int = Field(default=1, gt=0, strict=True)
    first_target_guidance_alpha: float = Field(default=0.0, ge=0, allow_inf_nan=False, strict=True)
    symmetric_set_reranking: bool = Field(default=False, strict=True)
    pair_set_composition: bool = Field(default=False, strict=True)
    device: Literal["auto", "cpu", "cuda"] = "auto"

    @model_validator(mode="after")
    def _check_decoding(self) -> EvalConfig:
        if self.pair_set_composition and not self.symmetric_set_reranking:
            raise ValueError("pair set composition requires symmetric_set_reranking")
        if self.symmetric_set_reranking and not (
            self.use_kv_cache and self.constrained_decoding and self.prevent_repeated_targets
        ):
            raise ValueError(
                "symmetric set reranking requires constrained_decoding, use_kv_cache "
                "and prevent_repeated_targets"
            )
        if self.prevent_repeated_targets and not self.constrained_decoding:
            raise ValueError("prevent_repeated_targets requires constrained_decoding")
        if self.generation_batch_size > 1 and not (self.use_kv_cache and self.constrained_decoding):
            raise ValueError("generation batches require constrained_decoding and use_kv_cache")
        if self.first_target_guidance_alpha > 0 and not (
            self.use_kv_cache and self.constrained_decoding
        ):
            raise ValueError("first-target guidance requires constrained_decoding and use_kv_cache")
        return self


class RootConfig(_Strict):
    seed: int = 1729
    deterministic: bool = False
    run_name: str = "${data.name}_${model.name}"
    paths: PathsConfig = Field(default_factory=PathsConfig)
    data: DataConfig = Field(default_factory=DataConfig)
    model: ModelConfig = Field(default_factory=ModelConfig)
    train: TrainConfig = Field(default_factory=TrainConfig)
    eval: EvalConfig = Field(default_factory=EvalConfig)
    baseline: BaselineConfig = Field(default_factory=BaselineConfig)


def validate_config(raw: dict[str, object]) -> RootConfig:
    """Validate a resolved (Hydra/OmegaConf → dict) config into a RootConfig."""
    return RootConfig.model_validate(raw)
