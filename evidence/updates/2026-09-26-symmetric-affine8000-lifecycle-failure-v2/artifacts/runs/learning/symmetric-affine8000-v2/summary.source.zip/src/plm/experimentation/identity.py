"""Immutable identity for reproducible PLM experiments.

The identity is deliberately data-oriented.  It does not discover git, CUDA,
or corpus state implicitly; callers must provide those values so a receipt can
never look more reproducible than the evidence actually recorded.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType

__all__ = ["ExperimentIdentity"]


@dataclass(frozen=True)
class ExperimentIdentity:
    """Content identity shared by candidates, checkpoints, and receipts."""

    source_commit: str
    resolved_config_hash: str
    protocol_version: str
    graph_hash: str
    records_hash: str
    vocabulary_hash: str
    split_hash: str
    evaluator_version: str
    environment: Mapping[str, str] = field(default_factory=dict)
    seeds: tuple[int, ...] = ()
    repetitions: int = 1
    checkpoint_hash: str | None = None

    def __post_init__(self) -> None:
        required = {
            "source_commit": self.source_commit,
            "resolved_config_hash": self.resolved_config_hash,
            "protocol_version": self.protocol_version,
            "graph_hash": self.graph_hash,
            "records_hash": self.records_hash,
            "vocabulary_hash": self.vocabulary_hash,
            "split_hash": self.split_hash,
            "evaluator_version": self.evaluator_version,
        }
        invalid = [
            name for name, value in required.items() if not isinstance(value, str) or not value
        ]
        if invalid:
            raise ValueError(
                "experiment identity requires non-empty string fields: " + ", ".join(invalid)
            )
        if self.checkpoint_hash is not None and (
            not isinstance(self.checkpoint_hash, str) or not self.checkpoint_hash
        ):
            raise ValueError("experiment identity checkpoint_hash must be a non-empty string")
        if not isinstance(self.environment, Mapping) or not all(
            isinstance(key, str) and isinstance(value, str)
            for key, value in self.environment.items()
        ):
            raise ValueError("experiment identity environment must be a string mapping")
        if (
            not isinstance(self.seeds, (list, tuple))
            or not self.seeds
            or not all(isinstance(seed, int) and not isinstance(seed, bool) for seed in self.seeds)
        ):
            raise ValueError("experiment identity requires at least one integer seed")
        if not isinstance(self.repetitions, int) or isinstance(self.repetitions, bool):
            raise ValueError("experiment identity repetitions must be an integer")
        if self.repetitions < 1:
            raise ValueError("experiment identity repetitions must be positive")

        object.__setattr__(
            self,
            "environment",
            MappingProxyType(dict(sorted(self.environment.items()))),
        )
        object.__setattr__(self, "seeds", tuple(self.seeds))

        missing = [name for name, value in required.items() if not value]
        if missing:
            # This is unreachable after the strict validation above, but keeps
            # the error invariant explicit if the required-field set changes.
            raise ValueError(f"experiment identity requires non-empty fields: {', '.join(missing)}")

    def to_dict(self) -> dict[str, object]:
        """Return a canonical JSON-compatible representation."""

        return {
            "source_commit": self.source_commit,
            "resolved_config_hash": self.resolved_config_hash,
            "protocol_version": self.protocol_version,
            "graph_hash": self.graph_hash,
            "records_hash": self.records_hash,
            "vocabulary_hash": self.vocabulary_hash,
            "split_hash": self.split_hash,
            "checkpoint_hash": self.checkpoint_hash,
            "evaluator_version": self.evaluator_version,
            "environment": dict(sorted(self.environment.items())),
            "seeds": list(self.seeds),
            "repetitions": self.repetitions,
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> ExperimentIdentity:
        """Rehydrate an identity from a receipt or manifest."""

        if not isinstance(raw, Mapping):
            raise ValueError("experiment identity must be a mapping")

        def required_text(name: str) -> str:
            value = raw.get(name)
            if not isinstance(value, str) or not value:
                raise ValueError(f"experiment identity field {name} must be a non-empty string")
            return value

        environment = raw.get("environment", {})
        seeds = raw.get("seeds", ())
        if not isinstance(environment, Mapping) or not all(
            isinstance(key, str) and isinstance(value, str) for key, value in environment.items()
        ):
            raise ValueError("experiment identity environment must be a string mapping")
        if not isinstance(seeds, (list, tuple)) or not all(
            isinstance(seed, int) and not isinstance(seed, bool) for seed in seeds
        ):
            raise ValueError("experiment identity seeds must be integers")
        repetitions = raw.get("repetitions", 1)
        if not isinstance(repetitions, int) or isinstance(repetitions, bool):
            raise ValueError("experiment identity repetitions must be an integer")
        checkpoint_hash = raw.get("checkpoint_hash")
        if checkpoint_hash is not None and not isinstance(checkpoint_hash, str):
            raise ValueError("experiment identity checkpoint_hash must be a string or null")
        return cls(
            source_commit=required_text("source_commit"),
            resolved_config_hash=required_text("resolved_config_hash"),
            protocol_version=required_text("protocol_version"),
            graph_hash=required_text("graph_hash"),
            records_hash=required_text("records_hash"),
            vocabulary_hash=required_text("vocabulary_hash"),
            split_hash=required_text("split_hash"),
            checkpoint_hash=checkpoint_hash,
            evaluator_version=required_text("evaluator_version"),
            environment=dict(environment),
            seeds=tuple(seeds),
            repetitions=repetitions,
        )

    def content_hash(self) -> str:
        """Hash every identity field except no implicit process metadata."""

        payload = json.dumps(
            self.to_dict(), ensure_ascii=True, sort_keys=True, separators=(",", ":")
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()
