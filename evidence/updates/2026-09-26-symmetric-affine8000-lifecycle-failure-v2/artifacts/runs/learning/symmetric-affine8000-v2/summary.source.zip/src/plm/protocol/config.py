"""Versioned protocol configuration.

The graph remains protocol-agnostic: this file maps model-visible dimensions to
graph-internal predicates. Keeping that mapping in a committed config makes a
compiled corpus reproducible from a graph snapshot and protocol version.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar

import yaml

__all__ = ["ProtocolSpec", "UnsupportedProtocolError", "load_protocol"]


class UnsupportedProtocolError(ValueError):
    """Raised when a protocol asks the compiler for unimplemented semantics."""


@dataclass(frozen=True)
class ProtocolSpec:
    """Model-visible protocol tokens and their graph derivation rules."""

    version: str
    dimensions: dict[str, str]
    modes: tuple[str, ...]
    target_order: tuple[str, ...]

    DEFAULT_TARGET_ORDER: ClassVar[tuple[str, ...]] = (
        "shared_attribute_count_desc",
        "confidence_desc",
        "product_key_asc",
    )
    SUPPORTED_TARGET_ORDER: ClassVar[frozenset[str]] = frozenset(
        {
            "shared_attribute_count_desc",
            "shared_attribute_count_asc",
            "confidence_desc",
            "confidence_asc",
            "product_key_asc",
            "product_key_desc",
        }
    )

    def validate_for_compilation(self) -> None:
        """Fail closed before compiling unsupported protocol semantics."""

        if not self.version:
            raise ValueError("protocol version must be non-empty")
        if not self.dimensions or not all(self.dimensions):
            raise ValueError("protocol dimensions must be non-empty")
        modes = self.modes or ("SAME",)
        unsupported_modes = tuple(mode for mode in modes if mode != "SAME")
        if unsupported_modes:
            raise UnsupportedProtocolError(
                f"unsupported protocol mode(s): {', '.join(unsupported_modes)}"
            )
        unknown_order = tuple(
            item for item in self.effective_target_order if item not in self.SUPPORTED_TARGET_ORDER
        )
        if unknown_order:
            raise UnsupportedProtocolError(
                f"unsupported target_order key(s): {', '.join(unknown_order)}"
            )

    @property
    def effective_modes(self) -> tuple[str, ...]:
        """Return the supported mode set, preserving old direct constructors."""

        return self.modes or ("SAME",)

    @property
    def effective_target_order(self) -> tuple[str, ...]:
        """Use the v1 order when an older direct constructor omitted it."""

        return self.target_order or self.DEFAULT_TARGET_ORDER


def load_protocol(path: str | Path) -> ProtocolSpec:
    """Load and validate a versioned protocol YAML file."""
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("protocol config must be a mapping")

    version = raw.get("version")
    dimensions = raw.get("dimensions")
    modes = raw.get("modes")
    target_order = raw.get("target_order")
    if not isinstance(version, str) or not version:
        raise ValueError("protocol config requires a non-empty 'version'")
    if not isinstance(dimensions, dict) or not dimensions:
        raise ValueError("protocol config requires non-empty 'dimensions'")
    if not all(
        isinstance(key, str) and isinstance(value, str) for key, value in dimensions.items()
    ):
        raise ValueError("protocol dimensions must map strings to relation names")
    if not isinstance(modes, list) or not all(isinstance(mode, str) for mode in modes):
        raise ValueError("protocol config requires a string list 'modes'")
    if "SAME" not in modes:
        raise ValueError("v1 protocol requires SAME mode")
    if not isinstance(target_order, list) or not all(
        isinstance(item, str) for item in target_order
    ):
        raise ValueError("protocol config requires a string list 'target_order'")
    return ProtocolSpec(
        version=version,
        dimensions=dict(dimensions),
        modes=tuple(modes),
        target_order=tuple(target_order),
    )
