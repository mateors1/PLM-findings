"""Thin repository over the SQLite product graph.

Minimal, typed CRUD used by the corpus compiler and tests. Import logic
(bulk loading from source dumps) lands in Phase B.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from types import TracebackType

from plm.graph.schema import connect, init_graph

__all__ = ["GraphRepository"]


class GraphRepository:
    """Context-managed access to a product graph database."""

    def __init__(self, db_path: str | Path, *, create: bool = False) -> None:
        self._path = Path(db_path)
        if create:
            init_graph(self._path)
        self._conn: sqlite3.Connection = connect(self._path)

    def __enter__(self) -> GraphRepository:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        self._conn.close()

    # -- writes --------------------------------------------------------------
    def add_provenance(
        self,
        source_type: str,
        *,
        citation: str | None = None,
        license: str | None = None,
        notes: str | None = None,
    ) -> int:
        """Insert a lineage row and return its id. ``source_type`` is one of
        ``'canon' | 'synthetic' | 'curated'``."""
        cur = self._conn.execute(
            "INSERT INTO provenance(source_type, citation, license, notes) VALUES (?, ?, ?, ?)",
            (source_type, citation, license, notes),
        )
        self._conn.commit()
        rowid = cur.lastrowid
        assert rowid is not None  # a plain INSERT always sets lastrowid
        return rowid

    def add_node(
        self,
        key: str,
        *,
        kind: str = "product",
        label: str | None = None,
        namespace: str = "PKM",
        status: str = "active",
        provenance_id: int | None = None,
    ) -> int:
        """Upsert a node. Re-adding a key overwrites its attributes with the
        provided (or default) values; ``provenance_id`` is preserved if omitted."""
        cur = self._conn.execute(
            "INSERT INTO nodes(key, namespace, kind, label, status, provenance_id) "
            "VALUES (?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(key) DO UPDATE SET "
            "  namespace=excluded.namespace, kind=excluded.kind, label=excluded.label, "
            "  status=excluded.status, "
            "  provenance_id=COALESCE(excluded.provenance_id, nodes.provenance_id)",
            (key, namespace, kind, label, status, provenance_id),
        )
        self._conn.commit()
        if cur.lastrowid:
            return int(cur.lastrowid)
        return self.node_id(key)

    def add_relation_type(self, name: str, *, category: str | None = None) -> int:
        self._conn.execute(
            "INSERT INTO relation_types(name, category) VALUES (?, ?) "
            "ON CONFLICT(name) DO UPDATE SET "
            "  category=COALESCE(excluded.category, relation_types.category)",
            (name, category),
        )
        self._conn.commit()
        row = self._conn.execute("SELECT id FROM relation_types WHERE name = ?", (name,)).fetchone()
        return int(row[0])

    def add_edge(
        self,
        src_key: str,
        dst_key: str,
        relation: str,
        *,
        weight: float = 1.0,
        confidence: float = 1.0,
        is_canonical: bool = True,
        provenance_id: int | None = None,
    ) -> None:
        src = self.node_id(src_key)
        dst = self.node_id(dst_key)
        rel = self.add_relation_type(relation)
        self._conn.execute(
            "INSERT INTO edges(src, dst, rel, weight, confidence, is_canonical, provenance_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(src, dst, rel) DO UPDATE SET "
            "  weight=excluded.weight, confidence=excluded.confidence, "
            "  is_canonical=excluded.is_canonical, "
            "  provenance_id=COALESCE(excluded.provenance_id, edges.provenance_id)",
            (src, dst, rel, weight, confidence, int(is_canonical), provenance_id),
        )
        self._conn.commit()

    def add_alias(self, node_key: str, alias: str, *, locale: str = "", priority: int = 0) -> None:
        """Attach a localized alias to a node (deferred use in v1)."""
        node_id = self.node_id(node_key)
        self._conn.execute(
            "INSERT INTO aliases(node_id, alias, locale, priority) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(alias, locale) DO UPDATE SET "
            "  node_id=excluded.node_id, priority=excluded.priority",
            (node_id, alias, locale, priority),
        )
        self._conn.commit()

    def replace_edges(
        self,
        src_key: str,
        relation: str,
        dst_keys: list[str],
        *,
        provenance_id: int | None = None,
    ) -> None:
        """Replace every outgoing edge of one relation for a source node.

        Used by the curated labeling UI: a label is a complete bucket
        assignment, so stale facts must be removed rather than accumulated.
        """
        if not dst_keys:
            raise ValueError("a replacement relation needs at least one destination")
        src_id = self.node_id(src_key)
        relation_id = self.add_relation_type(relation)
        dst_ids = [self.node_id(key) for key in dst_keys]
        with self._conn:
            self._conn.execute("DELETE FROM edges WHERE src = ? AND rel = ?", (src_id, relation_id))
            self._conn.executemany(
                "INSERT INTO edges(src, dst, rel, provenance_id, is_canonical) "
                "VALUES (?, ?, ?, ?, 0)",
                [(src_id, dst_id, relation_id, provenance_id) for dst_id in dst_ids],
            )

    # -- reads ---------------------------------------------------------------
    def node_id(self, key: str) -> int:
        row = self._conn.execute("SELECT id FROM nodes WHERE key = ?", (key,)).fetchone()
        if row is None:
            raise KeyError(f"unknown node key: {key!r}")
        return int(row[0])

    def node_keys(self, *, kind: str | None = None) -> list[str]:
        """Return node keys sorted by key (deterministic). Filter by ``kind``
        (e.g. ``'product'`` for the emittable/tokenizable set)."""
        if kind is None:
            rows = self._conn.execute("SELECT key FROM nodes ORDER BY key").fetchall()
        else:
            rows = self._conn.execute(
                "SELECT key FROM nodes WHERE kind = ? ORDER BY key", (kind,)
            ).fetchall()
        return [str(r[0]) for r in rows]

    def node_label(self, key: str) -> str:
        """Return a hydration label, falling back to the stable node key."""
        row = self._conn.execute(
            "SELECT COALESCE(label, key) FROM nodes WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown node key: {key!r}")
        return str(row[0])

    def attribute_keys(self, relation: str) -> list[str]:
        """Return the sorted hidden attribute keys used by a relation."""
        rows = self._conn.execute(
            "SELECT DISTINCT attribute.key FROM edges "
            "JOIN relation_types ON relation_types.id = edges.rel "
            "JOIN nodes AS attribute ON attribute.id = edges.dst "
            "WHERE relation_types.name = ? ORDER BY attribute.key",
            (relation,),
        ).fetchall()
        return [str(row[0]) for row in rows]

    def relation_targets(self, src_key: str, relation: str) -> list[str]:
        """Return sorted outgoing attribute keys for one graph predicate."""
        rows = self._conn.execute(
            "SELECT attribute.key FROM edges "
            "JOIN relation_types ON relation_types.id = edges.rel "
            "JOIN nodes AS attribute ON attribute.id = edges.dst "
            "WHERE edges.src = ? AND relation_types.name = ? ORDER BY attribute.key",
            (self.node_id(src_key), relation),
        ).fetchall()
        return [str(row[0]) for row in rows]

    def counts(self) -> tuple[int, int, int]:
        """Return ``(nodes, edges, relation_types)``."""
        n = self._conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
        e = self._conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
        r = self._conn.execute("SELECT COUNT(*) FROM relation_types").fetchone()[0]
        return int(n), int(e), int(r)
