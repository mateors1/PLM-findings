"""Deterministic continuous-vs-resumed training equivalence gate."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from plm.reproducibility import seed_everything
from plm.training.checkpoint import load_checkpoint, save_checkpoint

__all__ = ["ResumeEquivalenceResult", "evaluate_resume_equivalence"]


@dataclass(frozen=True)
class ResumeEquivalenceResult:
    steps: int
    checkpoint_step: int
    max_parameter_difference: float
    continuous_loss: float
    resumed_loss: float
    tolerance: float

    @property
    def passed(self) -> bool:
        return self.max_parameter_difference <= self.tolerance


def evaluate_resume_equivalence(
    model_factory: Callable[[], Any],
    input_ids: Any,
    labels: Any,
    *,
    steps: int,
    checkpoint_step: int,
    checkpoint_path: str | Path,
    seed: int = 1729,
    learning_rate: float = 1.0e-3,
    tolerance: float = 1.0e-6,
) -> ResumeEquivalenceResult:
    """Compare a continuous run with a save/reload/resume run."""

    import torch

    if steps < 2:
        raise ValueError("steps must be at least two")
    if not 1 <= checkpoint_step < steps:
        raise ValueError("checkpoint_step must be between 1 and steps - 1")
    if learning_rate <= 0.0:
        raise ValueError("learning_rate must be positive")
    if tolerance < 0.0:
        raise ValueError("tolerance must be non-negative")

    def advance(model: Any, optimizer: Any, start: int, stop: int) -> float:
        model.train()
        loss_value = 0.0
        for _ in range(start, stop):
            output = model(input_ids, labels=labels)
            if output.loss is None:
                raise RuntimeError("model did not return a loss")
            optimizer.zero_grad(set_to_none=True)
            output.loss.backward()
            optimizer.step()
            loss_value = float(output.loss.detach().cpu())
        return loss_value

    seed_everything(seed, deterministic=True)
    continuous = model_factory()
    continuous_optimizer = torch.optim.AdamW(continuous.parameters(), lr=learning_rate)
    continuous_loss = advance(continuous, continuous_optimizer, 0, steps)

    seed_everything(seed, deterministic=True)
    resumed = model_factory()
    resumed_optimizer = torch.optim.AdamW(resumed.parameters(), lr=learning_rate)
    advance(resumed, resumed_optimizer, 0, checkpoint_step)
    save_checkpoint(
        checkpoint_path,
        resumed,
        optimizer=resumed_optimizer,
        global_step=checkpoint_step,
    )
    load_checkpoint(checkpoint_path, resumed, optimizer=resumed_optimizer, restore_rng=True)
    resumed_loss = advance(resumed, resumed_optimizer, checkpoint_step, steps)

    differences = [
        (continuous_state - resumed_state).abs().max().item()
        for continuous_state, resumed_state in zip(
            continuous.state_dict().values(), resumed.state_dict().values(), strict=True
        )
    ]
    return ResumeEquivalenceResult(
        steps,
        checkpoint_step,
        max(differences, default=0.0),
        continuous_loss,
        resumed_loss,
        tolerance,
    )
