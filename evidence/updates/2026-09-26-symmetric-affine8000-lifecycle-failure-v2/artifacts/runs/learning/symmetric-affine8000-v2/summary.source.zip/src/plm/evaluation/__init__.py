"""Ranking metrics for held-out relation prediction (Phase B/C).

Filtered MRR and Hits@{1,3,10} over candidate products, comparing the PLM
against the Phase B baselines on identical splits.
"""

from __future__ import annotations

from plm.evaluation.plm import (
    PLMEvaluation,
    PLMScorer,
    RepeatedEvaluation,
    evaluate_final_test,
    evaluate_plm,
    evaluate_repeated,
    evaluate_validation,
)
from plm.evaluation.ranking import RankingMetrics, Scorer, evaluate_ranking
from plm.evaluation.split import QuerySplit, split_queries

__all__ = [
    "PLMEvaluation",
    "PLMScorer",
    "QuerySplit",
    "RankingMetrics",
    "RepeatedEvaluation",
    "Scorer",
    "evaluate_final_test",
    "evaluate_plm",
    "evaluate_ranking",
    "evaluate_repeated",
    "evaluate_validation",
    "split_queries",
]
